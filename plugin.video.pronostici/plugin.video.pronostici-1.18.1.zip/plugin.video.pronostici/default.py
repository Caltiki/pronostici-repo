# -*- coding: utf-8 -*-
import os
import re
import sys
import json
import base64
import difflib
import time
import unicodedata
import urllib.request
import urllib.parse
import urllib.error

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]

ADDON_PATH = ADDON.getAddonInfo("path")
ICON = os.path.join(ADDON_PATH, "resources", "icon.png")


def icona_sito(nome):
    """L'insegna del sito per la voce di menu, o None se non ce l'ha.

    Stanno dentro il plugin e non nel pacchetto dei loghi: sono sette file
    per 170 KB in tutto, cambiano quando cambia il menu - cioe' insieme al
    codice - e tenerli qui evita di far dipendere l'aspetto del menu da un
    aggiornamento da 12 MB.

    Consensus e Ratingbet non ce l'hanno: restano con la sigla fra
    parentesi quadre, che e' il ripiego e non un errore."""
    p = os.path.join(ADDON_PATH, "resources", "siti", nome + ".png")
    return p if os.path.exists(p) else None

# I DATI STANNO IN UN REPOSITORY PUBBLICO: nessun token, nessuna
# configurazione. L'addon funziona appena installato, come qualunque altro
# addon di terze parti.
#
# Come ci siamo arrivati: fino alla 1.3.9 i JSON stavano nel repository
# privato degli scraper, e per leggerli serviva un token GitHub che andava
# distribuito a mano a ogni persona. Ora il workflow pubblica i soli JSON
# giornalieri su questo repository pubblico, mentre scraper e codice
# restano privati.
DEFAULT_REPO = "Caltiki/pronostici-repo"
DEFAULT_BRANCH = "gh-data"

# Un repository pubblico si legge da raw.githubusercontent.com senza
# autenticazione. L'API di GitHub servirebbe solo per quelli privati, ha un
# limite di 60 richieste l'ora agli anonimi e restituisce i file in base64:
# per il nostro caso e' solo peso in piu'.
RAW_BASE = "https://raw.githubusercontent.com/{repo}/{branch}/{path}"

# NESSUN TOKEN, NE' NEL PACCHETTO NE' DA DIGITARE.
#
# Tre tappe, per capire perche' il codice qui sotto ha questa forma:
#   - fino alla 1.2.49 il token stava scritto in chiaro nel file
#     (FALLBACK_TOKEN), per non doverne digitare 93 caratteri col
#     telecomando. Reggeva solo perche' lo ZIP girava a mano;
#   - dalla 1.3.0 l'addon si aggiorna da un repository pubblico: un token
#     scritto qui sarebbe stato leggibile da chiunque, quindi e' passato
#     nelle impostazioni, da inserire una volta per installazione;
#   - da questa 1.4.0 i dati stessi sono pubblici, e il token non serve
#     piu' a nessuno. Le impostazioni lo leggono ancora, ma solo per chi
#     punta l'addon a un repository privato suo.
_TOKEN_CACHE = None

PRON_ICONS = {
    "1": "[1]", "X": "[X]", "2": "[2]",
    "1X": "[1X]", "X2": "[X2]", "12": "[12]",
    "GG": "[GG]", "NG": "[NG]",
    "OVER": "[OV]", "UNDER": "[UN]",
}

# Tipi WebPronostici: slug -> etichetta menu
WP_TIPI = [
    ("1x2",   "1X2"),
    ("misti", "Misti"),
    ("ou",    "Under / Over"),
    ("ggng",  "Gol / NoGol"),
]

# Sorgenti valide. AsianOdds ha il suo JSON (asianodds_<data>.json), quindi
# la sezione funziona anche nei giorni in cui il consensus e' vuoto: prima
# i dati AsianOdds si vedevano solo dentro le righe del consensus, cioe'
# solo per le partite che Statarea e WebPronostici avevano in comune.
SORGENTI = ("consensus", "consensusmedio", "prezzi", "poisson", "statarea",
            "webpronostici",
            "asianodds", "fpnet", "xgaura", "sportytrader", "soccersite",
            "ratingbet", "betimate", "footymetrics")

# Mercati della sezione Betimate: slug, etichetta, campo da cui si capisce
# se la riga ha quel mercato, descrizione.
#
# QUI IL SOTTOMENU FUNZIONA AL CONTRARIO DEGLI ALTRI. SoccerSite e
# Ratingbet pubblicano la stessa partita una volta per mercato, e il
# sottomenu SERVE a non vedere ogni giornata moltiplicata. Betimate invece
# mette tutto su UNA riga: 1X2, Under/Over e Gol/NoGol della stessa
# partita stanno insieme. Il sottomenu quindi non filtra righe, sceglie
# QUALI NUMERI mostrare - le partite sono sempre le stesse.
#
# Il campo serve solo a togliere le partite che quel mercato non ce
# l'hanno: il sito non pubblica Under/Over e Gol/NoGol dappertutto, e una
# riga con la sola etichetta e nessun numero e' peggio che assente.
BT_MERCATI = [
    ("1x2",  "1X2",            "P1",
     "Esito finale, col risultato esatto previsto e la media gol"),
    ("ou",   "Under / Over",   "P_Over",
     "Sopra o sotto la linea, che il sito cambia partita per partita"),
    ("ggng", "Gol / NoGol",    "BTTS_Si",
     "Segnano entrambe le squadre, oppure no"),
    ("tutti", "Tutto insieme", "",
     "Tutti i mercati della partita in una riga sola"),
]

# Mercati della sezione FootyMetrics: slug, etichetta, campo che prova che
# il mercato c'e', descrizione.
#
# Come Betimate, il sottomenu NON divide la stessa partita in piu' righe:
# qui una riga porta tutti i mercati, e il tipo sceglie quali numeri
# scrivere. Si scartano solo le partite su cui quel mercato manca.
#
# I CORNER NON SONO FRA QUESTI di proposito. Sono l'unico dato che
# nessun'altra fonte pubblica, ma restano di contorno: un sottomenu
# dedicato farebbe pensare che siano il motivo della sezione. Stanno nel
# dettaglio di ogni riga, tutte e quattro le linee su una riga sola.
FM_MERCATI = [
    ("1x2",   "1X2",              "P1",
     "Esito finale, col confronto fra il modello e le quote del sito"),
    ("ou25",  "Under / Over 2.5", "P_O25",
     "Sopra o sotto i due gol e mezzo"),
    ("ou15",  "Under / Over 1.5", "P_O15",
     "Sopra o sotto il gol e mezzo, che nessun'altra fonte pubblica"),
    ("ggng",  "Gol / NoGol",      "P_GG",
     "Segnano entrambe le squadre, oppure no"),
    ("primo", "Primo gol",        "P_Primo_Casa",
     "Chi segna per primo, o se la partita finisce senza reti"),
    ("best",  "Best AI Tip",      "Best_Prob",
     "Il consiglio del sito, che quasi sempre e' un Over/Under e non un 1X2"),
    ("tutti", "Tutto insieme",    "",
     "Tutti i mercati della partita in una riga sola, corner e arbitro compresi"),
]

# Mercati della sezione xGaura: slug, etichetta, valori del campo Mercato.
#
# Il sottomenu divide per MERCATO e non per confidenza. La confidenza che
# il sito pubblica e' un numero che si da' da solo: non e' una probabilita'
# calibrata, non e' verificabile, e non risulta che il sito pubblichi mai
# lo storico delle chiusure. Usarla come filtro vorrebbe dire lasciare a
# loro la decisione su cosa vale la pena guardare. Resta scritta nella
# riga, accanto alla probabilita' implicita nella quota, che invece e' un
# numero che non si sono inventati: cosi' lo scarto fra le due si vede.
#
# Serve comunque un filtro, perche' i tip sono centinaia al giorno (233
# oggi e 435 domani, contati il 03/09) e scorrerli tutti col telecomando
# non ha senso. Dividere per mercato e' navigazione e basta, senza
# giudizio: e' lo stesso schema dei tipi di WebPronostici.
XG_MERCATI = [
    ("1x2",  "1X2",            ("1X2",),
     "Esito finale: 1, X o 2"),
    ("ou",   "Under / Over",   ("OU",),
     "Sopra o sotto la soglia di gol"),
    ("btts", "Gol / NoGol",    ("BTTS",),
     "Segnano entrambe le squadre, oppure no"),
    ("dc",   "Doppia chance",  ("DC",),
     "1X, X2, 12"),
    ("tutti", "Tutti i mercati", (),
     "Tutti i tip del giorno, compresi primo tempo e voci non classificate"),
]


# Sezioni di Sportytrader: slug, etichetta, valori del campo Tipo.
#
# La divisione e' quella che fa il sito stesso - i pronostici "diretti"
# della prima pagina e la lista 1X2 - non una classificazione mia. Il sito
# e' italiano, quindi qui date e orari sono gia' ora nostra: non c'e'
# nessuna conversione di fuso in mezzo, al contrario di xGaura.
ST_TIPI = [
    ("diretti", "Pronostici diretti", ("A",),
     "I pronostici in evidenza sulla prima pagina"),
    ("1x2",     "Pronostici 1X2",     ("B",),
     "La lista 1X2, con la probabilita' dichiarata dal sito"),
    ("tutti",   "Tutti",              (),
     "Le due liste insieme"),
]


# Mercati della sezione SoccerSite: slug, etichetta, valori del campo
# Mercato, descrizione.
#
# Qui la divisione per mercato non e' una comodita' ma una necessita': il
# sito pubblica la STESSA partita quattro volte, una per mercato, e senza
# il sottomenu ogni giornata comparirebbe quadruplicata.
#
# COSA AGGIUNGE QUESTA FONTE rispetto alle altre gia' presenti: le
# percentuali su Under/Over e Gol/NoGol. Statarea e WebPronostici danno
# l'1X2, AsianOdds pure, xGaura da' i mercati ma come tip singoli. Questa
# e' la prima che mette una percentuale dichiarata accanto a Over/Under e
# Gol/NoGol per tutte le partite del giorno.
SS_MERCATI = [
    ("1x2",  "1X2",            ("1X2",),
     "Esito finale, con le tre percentuali"),
    ("ou",   "Under / Over 2.5", ("OU2.5",),
     "Sopra o sotto i 2,5 gol"),
    ("ggng", "Gol / NoGol",    ("BTTS",),
     "Segnano entrambe le squadre, oppure no"),
    ("dc",   "Doppia chance",  ("DC",),
     "1X, X2, 12 - la percentuale e' la somma dei due esiti"),
    ("tutti", "Tutti i mercati", (),
     "Tutte le righe del giorno, ogni partita una volta per mercato"),
]


# Sezioni di Ratingbet: slug, etichetta, valori del campo Sezione.
#
# QUATTRO MERCATI PIU' UNO, e il piu' uno e' quello che conta. Le prime
# quattro voci sono le pagine di mercato del sito. "Previsioni
# matematiche" e' un'altra cosa: non riassume le altre, e' un modello a
# se' che sceglie UN mercato per partita fra tutti quelli che tratta.
# Misurato il 30/09 su Lituania-Andorra: la pagina Under/Over da' 62% a
# Under 2.5, la pagina matematica da' 88% allo stesso esito. Due numeri
# diversi sulla stessa cosa, e li si tiene separati invece di sceglierne
# uno.
RB_SEZIONI = [
    ("1x2",  "1X2",            ("1X2",),
     "Esito finale, con le tre quote e le tre percentuali"),
    ("ou",   "Under / Over",   ("OU",),
     "Sopra o sotto la linea, che il sito cambia partita per partita"),
    ("ggng", "Gol / NoGol",    ("BTTS",),
     "Segnano entrambe le squadre, oppure no"),
    ("dc",   "Doppia chance",  ("DC",),
     "1/X, 1/2, X/2 con la percentuale di ciascuna"),
    ("math", "Previsioni matematiche", ("MATH",),
     "Il modello del sito: un solo esito per partita, scelto fra tutti i "
     "mercati"),
    ("tutte", "Tutte",         (),
     "Tutte le righe del giorno, ogni partita una volta per mercato"),
]


# Filtri della sezione AsianOdds: slug -> (etichetta, descrizione)
AO_FILTRI = [
    ("aff",   "Affidabili",
     "Margine basso e i due de-vig concordi: le probabilita' piu' attendibili"),
    ("mov",   "Movimenti",
     "Solo le partite dove il mercato si e' mosso davvero"),
    ("tutte", "Tutte",
     "Tutte le partite delle prossime 24h"),
]

# Filtri della sezione Consensus medio.
#
# PERCHE' SERVONO, E PERCHE' IN QUEST'ORDINE. Il file di una giornata porta
# tutte le partite su cui almeno una fonte si esprime: 2.546 il 24 ottobre.
# Ma le due cose che quella sezione ha da dire - lo scarto dal mercato e la
# media vera - stanno su poche centinaia di righe. Misurato sugli archivi:
# su 7.604 partite finite con almeno un pronostico, 7.300 ne avevano UNA
# SOLA (il 96%), perche' Betimate copre 8.794 partite da solo e le altre
# quattro insieme meno di 1.700, quasi tutte altrove.
#
# Quindi "Tutte" sta per ultima: e' il mucchio, non la vista utile. Il
# filtro e' solo lato addon, il file scaricato e' sempre lo stesso.
# Viste della sezione Prezzi equi.
#
# IL PREZZO EQUO NON E' UN PRONOSTICO, E' UN METRO. Dice quanto vale una
# selezione secondo il mercato: se il bookmaker paga di piu' stai
# prendendo valore, se paga di meno stai pagando margine. Non dice che
# convenga giocarla - viene dal prezzo stesso, quindi per costruzione non
# contiene nessun vantaggio.
#
# "Solo prezzo stretto" sta per prima perche' e' l'unica vista che risponde
# alla domanda giusta. Il margine mediano di AsianOdds e' il 10.7%: su una
# partita quotata larga la probabilita' de-viggata balla di parecchio, e
# una lista ordinata per probabilita' metterebbe in cima proprio quelle,
# gonfie. Sotto il 2% il prezzo e' stretto e il numero regge.
PE_FILTRI = [
    ("schedina", "Schedina",
     "Una riga per partita, solo campionati che Sisal e Lottomatica "
     "offrono, fascia 55-85%: quote fra 1.18 e 1.82, quelle con cui una "
     "multipla da tre o quattro ha senso"),
    ("stretto", "Solo prezzo stretto",
     "Margine sotto il 2%: le partite dove il prezzo e' affidabile e la "
     "probabilita' calcolata regge. Sono poche, ed e' il punto"),
    ("combo",   "Esito + Gol",
     "Le combinate segno + Under/Over, con la probabilita' congiunta vera "
     "e non il prodotto delle due: esito e gol sono correlati"),
    ("btts",    "Gol / NoGol",
     "Il mercato che il modello ha azzeccato meglio: nella fascia 55-65%, "
     "su 238 partite finite, previsto 60.0% e uscito 60.1%"),
    ("ou",      "Under / Over",
     "Sopra o sotto la soglia. Attenzione: su 563 partite il modello ha "
     "sottostimato gli Over di 4.6 punti, quindi qui i numeri sono bassi"),
    ("1x2",     "1X2",
     "Il de-vig di AsianOdds senza passare dal modello: e' gia' una "
     "probabilita', ed e' la stima migliore che abbiamo"),
    ("tutte",   "Tutto",
     "Tutte le selezioni della giornata, ordinate per probabilita'"),
]

CM_FILTRI = [
    ("mercato", "Con lo scarto dal mercato",
     "Solo dove AsianOdds ha la partita: si vede di quanto le fonti si "
     "discostano dal prezzo. E' l'unica cosa che la media aggiunge"),
    ("multi",   "Due fonti o piu'",
     "Solo dove la media e' davvero una media. Sul resto del calendario "
     "c'e' una fonte sola, e allora e' quella fonte"),
    ("tutte",   "Tutte",
     "Tutte le partite su cui almeno una fonte si esprime"),
]

# Il filtro "Movimenti" NON si ricalcola qui: asianodds_ci.py scrive nel JSON
# un campo "Notevole" gia' deciso, e l'addon si limita a leggerlo. Cosi' la
# regola vive in un posto solo e non puo' divergere - in 1.3.2-1.3.4 la
# soglia era scritta in due file e, quando le misure sul primo file vero
# hanno mostrato che 4 punti erano troppo pochi, correggerne uno solo avrebbe
# fatto mostrare a Kodi partite diverse da quelle dell'Excel.
#
# La soglia qui sotto serve solo a due cose: mostrare l'etichetta [mov N] in
# elenco, e filtrare i JSON prodotti prima che il campo esistesse.
AO_SOGLIA_MOV = 8.0


def get_setting(name, default=""):
    try:
        value = ADDON.getSetting(name)
        return value.strip() if value else default
    except Exception:
        return default


def get_url(**kwargs):
    return "{}?{}".format(BASE_URL, urllib.parse.urlencode(kwargs))


def get_github_token():
    """Token GitHub: ORMAI FACOLTATIVO.

    Con il repository dei dati pubblico non serve a nulla, e infatti non
    viene piu' chiesto all'avvio. Resta letto dalle impostazioni per chi
    punta l'addon a un repository privato suo: in quel caso si passa
    dall'API di GitHub invece che da raw."""
    global _TOKEN_CACHE
    if _TOKEN_CACHE is not None:
        return _TOKEN_CACHE
    _TOKEN_CACHE = get_setting("gh_token", "")
    return _TOKEN_CACHE


_REPO_CACHE = None


def get_repo():
    """Repository dei dati. Il default e' quello pubblico: nessuno deve
    configurare niente. Resta modificabile per chi vuole puntare altrove."""
    global _REPO_CACHE
    if _REPO_CACHE is not None:
        return _REPO_CACHE
    _REPO_CACHE = get_setting("gh_repo", DEFAULT_REPO) or DEFAULT_REPO
    return _REPO_CACHE


def get_branch():
    return get_setting("gh_branch", DEFAULT_BRANCH) or DEFAULT_BRANCH


def migra_da_privato():
    """Migrazione 1.3.x -> 1.4.0, una volta sola.

    Il problema che risolve: le impostazioni vivono in userdata/addon_data/
    e un aggiornamento dell'addon NON le tocca. Quindi chi arriva dalla
    1.3.x si ritrova con il vecchio repository privato e il vecchio token
    ancora scritti, e il codice nuovo li rispetterebbe: continuerebbe a
    interrogare l'API di GitHub con un token che prima o poi scade, invece
    del repository pubblico che ora funziona da solo.

    Perche' svuotarle d'ufficio e' lecito: prima della 1.4.0 quei due campi
    non erano una scelta, erano l'unico modo di far funzionare l'addon. Un
    valore salvato la' dentro e' per forza il vecchio default, non una
    preferenza. Dalla 1.4.0 in poi lo sono, e il segnaposto impedisce alla
    migrazione di rigirare e cancellare una scelta vera."""
    if get_setting("migrato_140", "") == "true":
        return

    global _TOKEN_CACHE, _REPO_CACHE
    repo = get_setting("gh_repo", "")
    token = get_setting("gh_token", "")
    try:
        if repo and repo != DEFAULT_REPO:
            ADDON.setSetting("gh_repo", "")
            _REPO_CACHE = None
        if token:
            ADDON.setSetting("gh_token", "")
            _TOKEN_CACHE = None
        ADDON.setSetting("migrato_140", "true")
    except Exception:
        # Se la scrittura non riesce, il peggio e' ritentare al prossimo
        # avvio: non e' un motivo per non mostrare i pronostici.
        return

    if repo or token:
        xbmcgui.Dialog().notification(
            "Pronostici",
            "Dati ora su repository pubblico: token non piu' necessario",
            ICON, 6000)


def notify_error(message):
    xbmcgui.Dialog().notification(
        "Pronostici", str(message)[:180],
        xbmcgui.NOTIFICATION_ERROR, 5000
    )


def _scarica_json(url, headers, silent_404, da_api):
    """Scarica e interpreta un JSON. None su qualunque errore, dopo averlo
    riferito all'utente in modo leggibile."""
    try:
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=20) as response:
            grezzo = response.read().decode("utf-8-sig")

        if not da_api:
            return json.loads(grezzo)

        # L'API restituisce i metadati del file e il contenuto in base64.
        payload = json.loads(grezzo)
        if not isinstance(payload, dict) or "content" not in payload:
            if not silent_404:
                notify_error("GitHub: contenuto file non disponibile")
            return None
        return json.loads(base64.b64decode(payload["content"]).decode("utf-8-sig"))

    except urllib.error.HTTPError as e:
        if e.code == 404:
            if not silent_404:
                notify_error("Dati non trovati (404): il file per quella data "
                             "non e' ancora stato pubblicato.")
        elif e.code == 401:
            # Ci si arriva solo con un token salvato a mano nel pannello:
            # senza token si passa da raw, che non autentica niente. Quindi
            # il consiglio giusto e' tornare al pubblico svuotando i campi,
            # non correggere il token.
            notify_error("Token non valido o scaduto (401). Svuota i campi "
                         "in Impostazioni per tornare ai valori predefiniti.")
        elif e.code == 403:
            notify_error("Accesso negato o limite richieste (403)")
        else:
            notify_error("Errore HTTP {}".format(e.code))
    except urllib.error.URLError as e:
        notify_error("Connessione: {}".format(e.reason))
    except ValueError:
        notify_error("Il file scaricato non e' un JSON valido")
    except Exception as e:
        notify_error("Errore: {}".format(e))
    return None


def github_request(path, silent_404=False):
    """Scarica un JSON dei dati.

    DUE STRADE, scelte in base alla presenza del token:

      - senza token (il caso normale): raw.githubusercontent.com, che serve
        i file dei repository PUBBLICI senza autenticazione e senza limiti
        stretti. E' cio' che permette all'addon di funzionare appena
        installato, senza chiedere niente a chi lo usa.

      - con token: l'API di GitHub, l'unica che legge i repository privati.
        Serve solo a chi punta l'addon a un repository suo.
    """
    repo = get_repo()
    branch = get_branch()
    if "/" not in repo:
        notify_error("Repository non valido: serve la forma utente/nome-repo")
        return None

    path = path.lstrip("/")
    token = get_github_token()
    headers = {"User-Agent": "Kodi-21-Pronostici/1.7.2"}

    if token:
        url = "https://api.github.com/repos/{}/contents/{}?ref={}".format(
            repo, path, urllib.parse.quote(branch, safe=""))
        headers["Accept"] = "application/vnd.github+json"
        headers["Authorization"] = "Bearer {}".format(token)
        return _scarica_json(url, headers, silent_404, da_api=True)

    url = RAW_BASE.format(repo=repo, branch=urllib.parse.quote(branch, safe=""),
                          path=urllib.parse.quote(path))
    return _scarica_json(url, headers, silent_404, da_api=False)


# ---------------------------------------------------------------- loghi

# I loghi vivono in un addon separato, resource.images.pronostici: 877 PNG
# per 16 MB che cambiano raramente, mentre questo file cambia spesso. Tenerli
# qui dentro voleva dire riscaricare 16 MB per ogni correzione al codice.
ID_RISORSA_LOGHI = "resource.images.pronostici"

_MAPPA_LOGHI = None
_AMBIGUE = None
_SENZA_APPROSSIMARE = None
_CACHE_LOGHI = {}
_BASE_LOGHI = None          # (cartella_png, file_json) risolta una volta

# INDICI DERIVATI DALLA MAPPA, calcolati una volta sola.
#
# PERCHE' ESISTONO. I tentativi per somiglianza hanno bisogno della mappa
# riscritta in altre grafie: senza punteggiatura, e senza accenti. Fino
# alla 1.10.0 quei dizionari venivano ricostruiti DENTRO la ricerca, cioe'
# una volta per ogni squadra non trovata, rinormalizzando ogni volta tutti
# i nomi della mappa.
#
# Con 4.383 nomi si notava appena. Con 10.385 no: misurato, una squadra
# senza stemma passava da 57 a 144 millisecondi, e una lista da 193 righe
# ne ha due per riga. Da qui la lentezza comparsa dopo l'aggiornamento
# degli stemmi - non era il peso delle immagini, era questo.
#
# Si svuotano quando la mappa viene ricaricata, insieme a _CACHE_LOGHI.
_INDICI = {}


def _svuota_indici():
    _INDICI.clear()
    _CACHE_LOGHI.clear()


def _indice(nome, costruisci):
    """L'indice richiesto, calcolato al primo uso e poi riusato."""
    if nome not in _INDICI:
        _INDICI[nome] = costruisci()
    return _INDICI[nome]


def _percorso_addon(addon_id):
    """Cartella di un altro addon installato, o None se assente.
    xbmcaddon.Addon() solleva se l'id non esiste: qui l'assenza e' un caso
    previsto, non un errore."""
    try:
        return xbmcaddon.Addon(addon_id).getAddonInfo("path")
    except Exception:
        return None


def _base_loghi():
    """Dove stanno i loghi: prima l'addon risorsa, poi la copia interna.

    Il ripiego sulla copia interna serve a chi arriva da una versione <= 1.2.49
    che aveva i PNG dentro il plugin: se per qualche motivo la risorsa non
    c'e', i loghi gia' presenti continuano a funzionare invece di sparire
    tutti insieme."""
    global _BASE_LOGHI
    if _BASE_LOGHI is not None:
        return _BASE_LOGHI

    candidati = []
    base_risorsa = _percorso_addon(ID_RISORSA_LOGHI)
    if base_risorsa:
        candidati.append((os.path.join(base_risorsa, "resources", "loghi"),
                          os.path.join(base_risorsa, "resources", "loghi.json")))
    candidati.append((os.path.join(ADDON_PATH, "resources", "loghi"),
                      os.path.join(ADDON_PATH, "resources", "loghi.json")))

    for dir_png, file_json in candidati:
        if os.path.exists(file_json):
            _BASE_LOGHI = (dir_png, file_json)
            return _BASE_LOGHI

    _BASE_LOGHI = (None, None)
    return _BASE_LOGHI

_RE_SPAZI = re.compile(r"\s+")
_SUFFISSI_SQ = ["fc", "ac", "as", "ss", "us", "cf", "sc", "afc", "fk", "sk",
                "bk", "if"]
_RE_SUFF_SQ = [re.compile(r"\b" + w + r"\b") for w in _SUFFISSI_SQ]


# Punteggiatura che separa parole ma che la normalizzazione base non tocca.
# "Le Puy-en-Velay" diventa 'le puy-en-velay', che non e' la chiave
# 'le puy en velay' e nemmeno le somiglia abbastanza (0.867, sotto la
# soglia 0.88): il logo non si trovava per un trattino.
_RE_PUNTEGGIATURA = re.compile(r"[-‐-―_.,'’/]+")


def normalizza_squadra(nome, separa_punteggiatura=False):
    """Stesso algoritmo di consensus.py e prepara_loghi.py.
    Se le tre divergono, i loghi smettono di essere trovati.

    separa_punteggiatura=True e' una variante usata SOLO come secondo
    tentativo in logo_per_squadra(): non cambia le chiavi della mappa, che
    restano quelle prodotte dalla normalizzazione base. Serve a far
    incontrare grafie che differiscono per soli trattini o punti."""
    n = str(nome).lower().strip()
    if separa_punteggiatura:
        n = _RE_PUNTEGGIATURA.sub(" ", n)
    n = _RE_SPAZI.sub(" ", n)
    for rx in _RE_SUFF_SQ:
        n = rx.sub("", n)
    return _RE_SPAZI.sub(" ", n).strip()


# Lettere che NFKD non scompone, perche' non sono una base piu' un segno:
# sono caratteri a se'. Vanno tradotte a mano, o Bodo/Glimt e Stabaek non
# incontrano mai bodø-glimt e stabæk.
_TRADUZIONE_LETTERE = {
    "ø": "o", "æ": "ae", "å": "a", "ð": "d", "þ": "th", "ß": "ss",
    "đ": "d", "ł": "l", "ı": "i", "œ": "oe", "ħ": "h", "ż": "z", "ġ": "g",
}


def _senza_accenti(testo):
    """Versione ASCII di una stringa: 'tromsø' -> 'tromso'.

    Serve perche' i nomi dei file dei loghi arrivano quasi sempre senza
    accenti, mentre le fonti scrivono i nomi per esteso. Senza questo,
    'Hafnarfjörður' e 'hafnarfjordur' restano due cose diverse e lo stemma
    non si trova - a meno di curare a mano un alias per ogni squadra, che e'
    esattamente il lavoro che questa funzione toglie di mezzo.

    Si applica a ENTRAMBI i lati del confronto, quindi non puo' far
    incontrare squadre che gia' non si somigliavano."""
    testo = "".join(_TRADUZIONE_LETTERE.get(c, c) for c in testo)
    scomposto = unicodedata.normalize("NFKD", testo)
    return "".join(c for c in scomposto if not unicodedata.combining(c))


# LA MAPPA DEI NOMI E' UN DATO, NON CODICE.
#
# Fino alla 1.4.4 viveva solo dentro il pacchetto dei loghi: correggere un
# alias - "Valenzana" e' la "Valenzanese", "Club Leon" in Serie D non e' il
# messicano - voleva dire ricostruire un pacchetto da 11 MB, caricarlo, e
# poi convincere Kodi ad accorgersene, cosa che richiede fino a un giorno
# perche' Kodi tiene in cache l'elenco delle versioni di ogni repository.
#
# Le IMMAGINI restano nel pacchetto: sono binari, cambiano di rado. I NOMI
# no: si scaricano da un file solo, che l'addon tiene in copia locale e
# ricontrolla ogni mezz'ora con una richiesta condizionale - se il file non
# e' cambiato il server risponde 304 e non trasferisce nulla.
URL_MAPPA = "https://raw.githubusercontent.com/{repo}/main/loghi.json"
ETA_MAPPA = 1800          # mezz'ora, poi si ricontrolla (non si riscarica)

# Entrando nel menu principale la mappa si ricontrolla SEMPRE, scadenza o
# no. Costa una richiesta condizionale per sessione - qualche centinaio di
# byte se il file non e' cambiato - e in cambio una correzione pubblicata
# adesso si vede riaprendo l'addon, senza aspettare la scadenza. Dentro le
# liste invece vale la scadenza normale: navigare non deve costare rete.
_RICONTROLLA_SUBITO = False


def _cartella_dati():
    """userdata/addon_data/plugin.video.pronostici, creata se manca.
    Sopravvive agli aggiornamenti dell'addon."""
    try:
        base = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
    except Exception:
        return None
    try:
        if not os.path.isdir(base):
            os.makedirs(base)
    except Exception:
        return None
    return base


def _scarica_mappa(percorso_cache):
    """Scarica la mappa aggiornata, o conferma quella che c'e'.

    Restituisce True se la copia locale e' utilizzabile. Qualunque errore
    di rete non e' un problema: si continua con quello che si ha, e in
    ultima istanza con la copia dentro il pacchetto."""
    repo = get_repo()
    if "/" not in repo:
        return False
    url = URL_MAPPA.format(repo=repo)
    testa = {"User-Agent": "Kodi-21-Pronostici/1.7.2"}

    # Richiesta condizionale: se il file non e' cambiato dall'ultima volta,
    # GitHub risponde 304 e il trasferimento e' di poche centinaia di byte.
    marchio = None
    try:
        with open(percorso_cache + ".etag", "r") as f:
            marchio = f.read().strip()
    except Exception:
        pass
    if marchio and os.path.exists(percorso_cache):
        testa["If-None-Match"] = marchio

    try:
        req = urllib.request.Request(url, headers=testa)
        with urllib.request.urlopen(req, timeout=15) as risposta:
            grezzo = risposta.read().decode("utf-8-sig")
            nuovo_marchio = risposta.headers.get("ETag", "")
        dati = json.loads(grezzo)           # si scrive solo se e' JSON valido
        if not isinstance(dati.get("mappa"), dict) or not dati["mappa"]:
            return os.path.exists(percorso_cache)
        with open(percorso_cache, "w") as f:
            json.dump(dati, f, ensure_ascii=False)
        if nuovo_marchio:
            with open(percorso_cache + ".etag", "w") as f:
                f.write(nuovo_marchio)
        return True
    except urllib.error.HTTPError as e:
        if e.code == 304:                    # non e' cambiata: tocco la data
            try:
                os.utime(percorso_cache, None)
            except Exception:
                pass
            return True
        return os.path.exists(percorso_cache)
    except Exception:
        return os.path.exists(percorso_cache)


def _carica_mappa_loghi():
    global _MAPPA_LOGHI, _AMBIGUE, _SENZA_APPROSSIMARE
    if _MAPPA_LOGHI is not None:
        return _MAPPA_LOGHI

    candidati = []
    cartella = _cartella_dati()
    if cartella:
        cache = os.path.join(cartella, "loghi.json")
        eta = None
        try:
            eta = time.time() - os.path.getmtime(cache)
        except Exception:
            pass
        if eta is None or eta > ETA_MAPPA or _RICONTROLLA_SUBITO:
            _scarica_mappa(cache)
        if os.path.exists(cache):
            candidati.append(cache)

    # Ultima rete di sicurezza: la copia dentro il pacchetto dei loghi.
    _, file_json = _base_loghi()
    if file_json:
        candidati.append(file_json)

    for percorso in candidati:
        try:
            with open(percorso, "r") as f:
                dati = json.load(f)
            mappa = dati.get("mappa")
            if isinstance(mappa, dict) and mappa:
                _MAPPA_LOGHI = mappa
                _AMBIGUE = dati.get("ambigue", {})
                _SENZA_APPROSSIMARE = set(dati.get("senza", []))
                _svuota_indici()
                return _MAPPA_LOGHI
        except Exception:
            continue

    _MAPPA_LOGHI = {}
    _AMBIGUE = {}
    _SENZA_APPROSSIMARE = set()
    _svuota_indici()
    return _MAPPA_LOGHI


def _carica_ambigue():
    """Tabella delle omonimie, che vive nello stesso file della mappa.
    Formato: {"leon": [["italy", "leon-ssd.png"], ["mexic", "club-leon.png"]]}
    Il primo indizio che compare nel campionato vince, quindi l'ordine
    conta: il piu' specifico va messo per primo."""
    global _AMBIGUE
    if _AMBIGUE is None:
        _carica_mappa_loghi()          # riempie anche _AMBIGUE
        if _AMBIGUE is None:
            _AMBIGUE = {}
    return _AMBIGUE


def _carica_senza_approssimare():
    """Nomi ai quali e' VIETATO arrivare per somiglianza.

    Nascono da un controllo fatto a vista su tutte le squadre risolte non
    per via esatta. Ogni riga e' un caso in cui il fuzzy, sopra la sua
    soglia, aggancia un club diverso perche' in archivio manca lo stemma di
    quello giusto:
      'reggina'        -> reggiana.png     (Reggio Calabria contro Reggio Emilia, 0.93)
      'lara deportiva' -> lorca-deportiva.png (Venezuela contro Spagna)

    La lista si spegne da sola: il controllo scatta SOLO dopo che la
    ricerca esatta e' fallita, quindi il giorno che arriva reggina.png e
    la sua chiave entra in mappa, la riga qui dentro smette di contare
    senza che nessuno debba ricordarsi di toglierla."""
    global _SENZA_APPROSSIMARE
    if _SENZA_APPROSSIMARE is None:
        _carica_mappa_loghi()
        if _SENZA_APPROSSIMARE is None:
            _SENZA_APPROSSIMARE = set()
    return _SENZA_APPROSSIMARE


# Suffissi che indicano una squadra riserve/giovanile: "Real Sociedad B"
# NON deve mai ereditare il logo di "Real Sociedad" (prima squadra), ma
# il punteggio fuzzy da solo non basta - "real sociedad b" vs "real
# sociedad" tocca 0.929, sopra la soglia 0.88 usata qui. Stesso bug e
# stessa correzione gia' applicata a xg_per_squadra() in consensus.py.
# ATTENZIONE - "c" e "iii" sono qui per la stessa ragione di "b" e "ii": in
# Spagna le terze squadre giocano in Tercera Federacion e si chiamano
# "Villarreal C", "Real Sociedad C". Senza, il fuzzy le aggancerebbe alla
# prima squadra ('sevilla c' e 'sevilla' si somigliano al 93%) e mostrerebbe
# lo stemma sbagliato. Questo NON impedisce alle squadre C presenti in mappa
# di avere il loro logo: la ricerca esatta viene prima della guardia.
_SUFFISSI_RISERVE_LOGO = {"b", "c", "ii", "iii", "2", "u21", "u23", "u19",
                          "reserve", "reserves", "riserve", "youth",
                          "primavera"}


def _e_squadra_riserve_logo(nome_normalizzato):
    parole = nome_normalizzato.split()
    return bool(parole) and parole[-1] in _SUFFISSI_RISERVE_LOGO


# Marcatori di VARIANTE: pezzi di nome che non indicano un club diverso, ma
# un'altra squadra dello stesso club - la femminile, la seconda, l'under.
# Tutte usano lo stemma della prima squadra, e le nazionali giovanili usano
# la bandiera: "Arsenal (w)", "Osasuna B", "Francia U21", "Inter U23".
#
# La lista delle riserve e' la stessa della guardia qui sopra, piu' l'arco
# completo degli under: le due cose sono facce della stessa moneta, la
# guardia VIETA il fuzzy a questi nomi e questa regola concede loro lo
# stemma del club per via esatta.
_MARCATORI_FEMMINILE = {
    "w", "wom", "women", "womens", "ladies", "femminile", "femenino",
    "femenil", "feminino", "feminin", "feminina", "frauen", "damen",
    "dames", "kvinner", "naiset", "kobiet", "zeny",
}
_MARCATORI_VARIANTE = (_MARCATORI_FEMMINILE | _SUFFISSI_RISERVE_LOGO |
                       {"u16", "u17", "u18", "u20", "u22"})

# Le parentesi non sono punteggiatura "che separa parole" per la
# normalizzazione base, ma qui servono aperte: la fonte scrive "Arsenal (w)".
_RE_PARENTESI = re.compile(r"[()\[\]{}]+")


def _nome_senza_marcatori(chiave_punteggiata):
    """Toglie i marcatori di variante dalla CODA del nome, o None se non ce
    ne sono.

    Solo dalla coda, e solo finche' ce ne sono: "Atletico Madrid Femenino
    (w)" perde due pezzi e diventa 'atletico madrid'. Se non resta niente
    (un nome fatto di soli marcatori, tipo "Juniors") restituisce None,
    perche' un nome vuoto si aggancerebbe a qualunque cosa."""
    parole = _RE_PARENTESI.sub(" ", chiave_punteggiata).split()
    tolto = False
    while parole and parole[-1] in _MARCATORI_VARIANTE:
        parole.pop()
        tolto = True
    if not tolto or not parole:
        return None
    return " ".join(parole)


_RE_NON_PAROLA = re.compile(r"[^a-z0-9]+")
_MARCATORI_UNDER = {"u16", "u17", "u18", "u19", "u20", "u21", "u22", "u23"}
# L'eta' scritta in tutti i modi in cui la scrivono le fonti: "U21",
# "-21", "Under 21". Serve sul nome del CAMPIONATO, dove spesso l'eta'
# c'e' anche quando nel nome della squadra non c'e': Sportytrader scrive
# "Repubblica Ceca -21 vs Bulgaria" - la seconda squadra senza niente - ma
# il campionato lo chiama "Europei Under 21".
_RE_ETA = re.compile(r"\b(?:u|under\s*|-)(1[6-9]|2[0-3])\b")


def _parole_chiave(testo):
    return set(_RE_NON_PAROLA.split(str(testo or "").lower()))


def _variante(casa, ospite, dove):
    """Che tipo di squadra e': femminile, giovanile, riserve o prima.

    SERVE SOLO ALLA CHIAVE DI AGGANCIO fra fonti. La regola dei marcatori
    (1.4.7) manda di proposito le femminili e le seconde squadre sullo
    stemma del CLUB, perche' uno stemma proprio non ce l'hanno. Ottimo per
    mostrare l'immagine, pessimo per riconoscere la partita: "Paris FC (w)
    - Arsenal Women" e "Paris FC - Arsenal" arrivano ai due stessi file,
    quindi con la sola coppia di stemmi sarebbero la STESSA partita. Nelle
    finestre delle nazionali la nazionale maggiore e la sua Under 21
    giocano spesso lo stesso accoppiamento lo stesso giorno, e li' il
    rischio e' concreto.

    IL CAMPIONATO SI GUARDA IN MODO DIVERSO a seconda del marcatore, e non
    e' una svista:
    - femminile: si legge anche dal campionato, che le fonti scrivono in
      chiaro ("Champions League Femminile", "Women's League Cup"). Le
      cinque fonti sono risultate concordi su questo, quindi il marcatore
      e' affidabile.
    - eta': si legge dal campionato solo nella forma U21 / -21 / Under 21,
      che non si confonde con altro.
    - riserve: dal campionato NON si legge affatto. I nomi dei campionati
      sono pieni di "2" e di "B" ("Liga 2", "National League B", "Serie
      B") e diventerebbero marcatori falsi.

    Chi usa questo valore deve comunque essere tollerante, perche' le
    fonti l'eta' la scrivono a volte e a volte no: vedi _riga_mercato.
    """
    nomi = _parole_chiave(casa) | _parole_chiave(ospite)
    testo_lega = str(dove or "").lower()
    if (nomi | _parole_chiave(dove)) & _MARCATORI_FEMMINILE:
        return "f"
    under = nomi & _MARCATORI_UNDER
    if under:
        return sorted(under)[0]
    m = _RE_ETA.search(testo_lega) or _RE_ETA.search(
        "{} {}".format(casa or "", ospite or "").lower())
    if m:
        return "u" + m.group(1)
    if nomi & _SUFFISSI_RISERVE_LOGO:
        return "r"
    return ""


# SIGLE SOCIALI ITALIANE. Non sono parte del nome: le fonti le mettono o
# le tolgono a caso - "Imperia", "ASD Imperia", "Asd Imperia 1923" sono la
# stessa squadra, e tutte e tre si sono viste su gh-data lo stesso giorno.
#
# Si tolgono dalla TESTA. In coda si tolgono "calcio" e l'anno di
# fondazione, che le fonti italiane appiccicano volentieri.
_SIGLE_TESTA = {"asd", "ssd", "usd", "acd", "ad", "ac", "as", "us", "ss",
                "fc", "sc", "gs", "cs", "pol", "polisportiva", "ath",
                "calcio", "societa", "unione sportiva"}
_SIGLE_CODA = {"calcio", "fc", "ssd", "asd"}
_RE_ANNO = re.compile(r"^(1[89]\d\d|20\d\d)$")


def _nome_senza_sigla(chiave):
    """Il nome senza sigla sociale, o None se non c'era niente da togliere.

    PERCHE' SOLO CON RICERCA ESATTA, come per i marcatori di variante: un
    nome accorciato somiglia a troppe cose. Misurato il 30/09, prima di
    questa regola: "Calcio Giulianova" finiva sul Giugliano e "Calcio
    Pavia" sul Padova, tutti e due per somiglianza. Togliendo la sigla e
    cercando SOLO la corrispondenza esatta, o si trova la squadra giusta o
    non si trova niente.

    Non si tocca nulla se resta meno di una parola: "Calcio" da solo non e'
    una squadra."""
    parole = chiave.split()
    tolto = False

    # Le sigle puntate arrivano spezzate in lettere singole: "U.S.
    # Alessandria" diventa 'u s alessandria'. Si rimettono insieme, e si
    # tolgono SOLO se quello che ne esce e' una sigla conosciuta - cosi'
    # una squadra che cominciasse per davvero con una lettera sola resta
    # intatta.
    # Si prova dalla sigla piu' lunga alla piu' corta: in "A.S.D. L'Aquila"
    # le lettere singole di fila sono quattro - a, s, d, l - ma la sigla e'
    # solo "asd" e la quarta lettera e' la squadra.
    n = 0
    while n < len(parole) - 1 and len(parole[n]) == 1:
        n += 1
    while n >= 2:
        if "".join(parole[:n]) in _SIGLE_TESTA:
            parole = parole[n:]
            tolto = True
            break
        n -= 1

    # Puo' esserci sia la sigla sia l'anno: "Asd Imperia 1923".
    for _ in range(3):
        if len(parole) > 1 and parole[0] in _SIGLE_TESTA:
            parole.pop(0)
            tolto = True
            continue
        if len(parole) > 1 and (parole[-1] in _SIGLE_CODA
                                or _RE_ANNO.match(parole[-1])):
            parole.pop()
            tolto = True
            continue
        break
    if not tolto or not parole:
        return None
    return " ".join(parole)


def _campi_riga(row):
    """Il campionato o il paese della partita, come lo scrive la fonte.

    Ogni sorgente lo chiama a modo suo: AsianOdds 'Lega', Statarea 'Paese' e
    'Competizione', WebPronostici 'Campionato'. Il consensus non lo porta
    affatto, ed e' il motivo per cui li' le squadre ambigue restano senza
    stemma."""
    pezzi = []
    for c in ("Lega", "Paese", "Competizione", "Campionato"):
        v = row.get(c)
        if v:
            pezzi.append(str(v))
    return " ".join(pezzi)


def _scioglie_omonimia(chiave, dove):
    """Sceglie fra due club che si chiamano allo stesso modo, guardando in
    che campionato si gioca la partita.

    Serve perche' esistono nomi che NESSUNA chiave puo' distinguere. Il caso
    che ha fatto nascere questa funzione: 'Leon'. AsianOdds lo usa per la
    Serie D italiana, Statarea per il Liga MX messicano, WebPronostici
    scrive 'Club Leon' intendendo di nuovo l'italiano. Stessa stringa, tre
    convenzioni, e l'unica cosa che li separa e' il campionato - che nel
    dato c'e' sempre stato, e finora buttavamo via.

    Senza contesto (il consensus non lo porta) restituisce None: meglio
    nessuno stemma che quello dell'altro club."""
    tabella = _carica_ambigue()
    voci = tabella.get(chiave)
    if not voci:
        return False, None            # non e' un nome ambiguo: prosegui
    contesto = _senza_accenti(str(dove or "").lower())
    for indizio, fname in voci:
        if indizio in contesto:
            return True, fname
    return True, None                 # ambiguo e senza indizi: nessun logo


def logo_per_squadra(nome, dove=""):
    """Percorso del logo, o None. Prima esatto, poi fuzzy stretto."""
    if not nome:
        return None
    chiave = normalizza_squadra(nome)

    # La cache tiene conto del contesto: la stessa squadra in due campionati
    # diversi puo' legittimamente dare due stemmi diversi.
    in_cache = (chiave, str(dove or "")[:40])
    if in_cache in _CACHE_LOGHI:
        return _CACHE_LOGHI[in_cache]

    mappa = _carica_mappa_loghi()

    ambiguo, scelto = _scioglie_omonimia(chiave, dove)
    if ambiguo:
        percorso = None
        dir_png, _ = _base_loghi()
        if scelto and dir_png:
            cand = os.path.join(dir_png, scelto)
            if os.path.exists(cand):
                percorso = cand
        _CACHE_LOGHI[in_cache] = percorso
        return percorso

    fname = mappa.get(chiave)

    # Trovata per via esatta: nessun dubbio. Altrimenti, se il nome e' in
    # lista nera, ci si ferma qui invece di tentare le approssimazioni.
    if not fname and chiave in _carica_senza_approssimare():
        _CACHE_LOGHI[in_cache] = None
        return None

    # Chiave sulla quale si e' andati a finire per somiglianza, che NON e'
    # quella di partenza: serve piu' sotto per ripassare dalla tabella delle
    # omonimie. Senza, il fuzzy la scavalca - "Fortaleza W" somiglia a
    # 'fortaleza' al 90%, prendeva il Fortaleza brasiliano e la decisione
    # per campionato non veniva nemmeno consultata.
    trovata = None

    # PRIMA del fuzzy, non dopo: la sigla sociale e' rumore noto, e
    # lasciarla passare al fuzzy produce agganci sbagliati - "Calcio
    # Giulianova" sul Giugliano. Solo ricerca esatta: vedi _nome_senza_sigla.
    if not fname and mappa:
        # Due grafie: quella normale e quella con i punti trattati come
        # spazi. Serve per le sigle puntate - "Pol. Angelana" resta
        # 'pol. angelana' nella prima e diventa 'pol angelana' nella
        # seconda, e solo li' la sigla si riconosce.
        for k in (chiave, normalizza_squadra(nome, separa_punteggiatura=True)):
            spoglia = _nome_senza_sigla(k)
            if spoglia and spoglia in mappa:
                trovata = spoglia
                fname = mappa[spoglia]
                break

    if not fname and mappa and not _e_squadra_riserve_logo(chiave):
        # soglia alta: meglio nessun logo che il logo della squadra sbagliata
        candidati = _indice("candidati", lambda: [
            k for k in mappa.keys() if not _e_squadra_riserve_logo(k)])
        vicini = difflib.get_close_matches(chiave, candidati,
                                           n=1, cutoff=0.88)
        if vicini:
            trovata = vicini[0]
            fname = mappa[trovata]

        # Secondo tentativo, con trattini e punti trattati come spazi da
        # entrambe le parti. La soglia resta 0.88: si allineano le grafie,
        # non si abbassa il livello di prudenza.
        if not fname:
            chiave2 = normalizza_squadra(nome, separa_punteggiatura=True)
            if chiave2 != chiave:
                def _costruisci_punt():
                    d = {}
                    for k in candidati:
                        d.setdefault(
                            normalizza_squadra(k, separa_punteggiatura=True), k)
                    return d
                equiv = _indice("punteggiatura", _costruisci_punt)
                if chiave2 in equiv:
                    trovata = equiv[chiave2]
                    fname = mappa[trovata]
                else:
                    vicini = difflib.get_close_matches(chiave2, list(equiv),
                                                       n=1, cutoff=0.88)
                    if vicini:
                        trovata = equiv[vicini[0]]
                        fname = mappa[trovata]

        # Terzo tentativo, senza accenti da entrambe le parti. I nomi dei
        # file dei loghi sono quasi sempre in ASCII ('bodo-glimt'), mentre le
        # fonti scrivono 'Bodø/Glimt': senza questo passaggio servirebbe un
        # alias curato a mano per ogni squadra nordica, slava o baltica.
        # La soglia resta 0.88 e il confronto e' simmetrico, quindi non
        # avvicina squadre che gia' non si somigliavano.
        if not fname:
            chiave3 = _senza_accenti(
                normalizza_squadra(nome, separa_punteggiatura=True))
            def _costruisci_accenti():
                d = {}
                for k in candidati:
                    d.setdefault(
                        _senza_accenti(normalizza_squadra(
                            k, separa_punteggiatura=True)), k)
                return d
            equiv = _indice("accenti", _costruisci_accenti)
            if chiave3 in equiv:
                trovata = equiv[chiave3]
                fname = mappa[trovata]
            else:
                vicini = difflib.get_close_matches(chiave3, list(equiv),
                                                   n=1, cutoff=0.88)
                if vicini:
                    trovata = equiv[vicini[0]]
                    fname = mappa[trovata]

    # Quarto tentativo: togliere i marcatori di variante e cercare il club.
    #
    # Sta FUORI dal blocco qui sopra perche' deve valere anche per le
    # riserve, che quel blocco esclude apposta. E non usa il fuzzy: cerca
    # SOLO in modo esatto. E' questa la differenza che lo rende sicuro.
    # Misurato sui nomi veri di gh-data: recupera 51 squadre (tutte le
    # femminili di WSL, Liga F e Serie A, le seconde squadre spagnole e
    # ceche, le nazionali giovanili) e non ne sbaglia nessuna, perche'
    # "Orlando Pride (w)" diventa 'orlando pride', che non e' una chiave, e
    # quindi resta senza stemma invece di prendersi quello dell'Orlando City.
    # Con il fuzzy al posto della ricerca esatta, invece, se lo prenderebbe.
    if not fname and mappa:
        base = _nome_senza_marcatori(
            normalizza_squadra(nome, separa_punteggiatura=True))
        if base:
            # Se la variante e' a sua volta ambigua (una "Rangers II"),
            # decide il campionato, esattamente come per il nome intero.
            ambiguo, scelto = _scioglie_omonimia(base, dove)
            if ambiguo:
                fname = scelto
            else:
                def _costruisci_tutte():
                    d = {}
                    for k in mappa:
                        d.setdefault(
                            _senza_accenti(normalizza_squadra(
                                k, separa_punteggiatura=True)), k)
                    return d
                equiv = _indice("accenti_tutte", _costruisci_tutte)
                k = equiv.get(_senza_accenti(base))
                if k:
                    fname = mappa[k]

    # Ultimo controllo: se ci si e' arrivati per somiglianza, la tabella
    # delle omonimie ha comunque l'ultima parola sulla chiave di ARRIVO.
    if trovata and trovata != chiave:
        ambiguo, scelto = _scioglie_omonimia(trovata, dove)
        if ambiguo:
            fname = scelto

    percorso = None
    dir_png, _ = _base_loghi()
    if fname and dir_png:
        cand = os.path.join(dir_png, fname)
        if os.path.exists(cand):
            percorso = cand

    _CACHE_LOGHI[in_cache] = percorso
    return percorso


# ---------------------------------------------------------------- voci

def add_item(label, plot, url, is_folder, casa=None, ospite=None, dove="",
             icona=None):
    li = xbmcgui.ListItem(label=label)
    li.setInfo("video", {"title": label, "plot": plot})

    # Una ListItem ha UNA sola thumb: due squadre non ci stanno.
    # thumb = casa, fanart = ospite (la fanart compare come sfondo alla
    # selezione, ma la resa dipende dallo skin).
    logo_casa = logo_per_squadra(casa, dove) if casa else None
    logo_osp = logo_per_squadra(ospite, dove) if ospite else None

    # icona esplicita: serve alle voci del menu, che non sono partite e
    # quindi non hanno uno stemma da cui ricavarla.
    art = {"icon": icona or logo_casa or ICON,
           "thumb": icona or logo_casa or ICON}
    if logo_osp:
        art["fanart"] = logo_osp
    li.setArt(art)

    xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=is_folder)


# ---------------------------------------------------------------- menu

def main_menu():
    # Si entra da qui a ogni apertura dell'addon: e' il momento giusto per
    # verificare se la mappa dei nomi e' cambiata.
    global _RICONTROLLA_SUBITO
    _RICONTROLLA_SUBITO = True
    try:
        _carica_mappa_loghi()
    except Exception:
        pass

    # La sigla fra parentesi quadre resta nell'etichetta anche dove c'e'
    # l'insegna: su alcuni skin le icone della lista sono piccole o
    # spente, e il nome deve restare leggibile da solo.
    add_item("[*] Consensus", "Partite dove Statarea e WebPronostici concordano",
             get_url(action="dates", source="consensus"), True)
    # Seconda voce e non sostituto della prima. Il Consensus per accordo
    # copre poche partite ma dice un segno; questa copre tutto il
    # calendario e dice una probabilita' media che, misurata sulle partite
    # finite, PERDE contro il mercato (t = +2.71 su 230 partite). Sta qui
    # per leggere lo scarto fra quello che pensano i siti e quello che
    # pensa il book, non per giocarci sopra.
    add_item("[~] Consensus medio",
             "La media delle probabilita' di tutte le fonti, con lo scarto "
             "dal mercato. Lettura, non pronostico: contro il book perde.",
             get_url(action="cm_filtri"), True)
    # QUESTA NON E' UNA FONTE: e' un metro. Le altre voci del menu dicono
    # cosa pensa qualcuno della partita, questa dice quanto vale una
    # giocata secondo il prezzo - il numero con cui confrontare la quota
    # del bookmaker PRIMA di giocare invece che dopo.
    add_item("[E] Prezzi equi",
             "Quanto vale ogni selezione secondo il mercato: se il "
             "bookmaker paga di piu' prendi valore, se paga di meno paghi "
             "margine. Non e' un pronostico, e' il metro per giudicarlo.",
             get_url(action="pe_filtri"), True)
    # L'UNICA VOCE CHE NON GUARDA LE QUOTE. Tutte le altre leggono il
    # prezzo o lo riscrivono; qui i lambda nascono dagli xG di Understat,
    # e il mercato compare solo come termine di paragone. E' la prima
    # stima del sistema che puo' essere in disaccordo col book avendo una
    # ragione invece che per rumore.
    add_item("[P] Poisson xG",
             "Lambda calcolati dagli xG di Understat, senza guardare le "
             "quote. Solo partite complete di tutti i dati, primi cinque "
             "campionati europei.",
             get_url(action="dates", source="poisson"), True)
    add_item("[S] Statarea", "Pronostici Statarea con percentuali",
             get_url(action="dates", source="statarea"), True,
             icona=icona_sito("statarea"))
    add_item("[W] WebPronostici", "1X2, Misti, Under/Over, Gol/NoGol",
             get_url(action="wp_tipi"), True,
             icona=icona_sito("webpronostici"))
    add_item("[A] AsianOdds", "Quote 1xBet, movimenti ed Elo - solo informativo, "
                              "non e' un pronostico",
             get_url(action="ao_filtri"), True,
             icona=icona_sito("asianodds"))
    add_item("[F] FootballPredictions", "Le Sure Bets del giorno con il "
                                        "pronostico del sito",
             get_url(action="dates", source="fpnet"), True,
             icona=icona_sito("fpnet"))
    add_item("[X] xGaura", "Tip divisi per mercato, con la quota migliore "
                           "fra i bookmaker e quanta probabilita' implica",
             get_url(action="xg_mercati"), True,
             icona=icona_sito("xgaura"))
    add_item("[T] Sportytrader", "Pronostici diretti e lista 1X2, con quota "
                                 "e probabilita' dichiarata",
             get_url(action="st_tipi"), True,
             icona=icona_sito("sportytrader"))
    add_item("[C] SoccerSite", "1X2, Under/Over, Gol/NoGol e doppia chance, "
                               "con percentuale, quota e risultato previsto",
             get_url(action="ss_mercati"), True,
             icona=icona_sito("soccersite"))
    add_item("[R] Ratingbet", "Quattro mercati con quota e percentuale per "
                              "ogni esito, piu' le previsioni matematiche",
             get_url(action="rb_sezioni"), True,
             icona=icona_sito("ratingbet"))
    add_item("[B] Betimate", "1X2, Under/Over e Gol/NoGol con il risultato "
                             "esatto previsto e la media gol",
             get_url(action="bt_mercati"), True,
             icona=icona_sito("betimate"))
    add_item("[FM] FootyMetrics", "Sei mercati per partita, piu' i corner "
                                  "e le medie dell'arbitro",
             get_url(action="fm_mercati"), True,
             icona=icona_sito("footymetrics"))
    # ULTIMA VOCE, e non per modestia: e' l'unica che guarda indietro
    # invece che avanti, e chi apre l'addon vuole le partite di oggi.
    add_item("[%] Come vanno le fonti",
             "Quante ne prende davvero ogni fonte, misurato sulle partite "
             "gia' finite. Non e' un pronostico: e' il consuntivo.",
             get_url(action="classifica"), True)
    xbmcplugin.endOfDirectory(HANDLE)


def show_bt_mercati():
    """I mercati della sezione Betimate."""
    for slug, label, _campo, descr in BT_MERCATI:
        add_item(label, descr,
                 get_url(action="dates", source="betimate", tipo=slug), True,
                 icona=icona_sito("betimate"))
    xbmcplugin.endOfDirectory(HANDLE)


def show_fm_mercati():
    """I mercati della sezione FootyMetrics."""
    for slug, label, _campo, descr in FM_MERCATI:
        add_item(label, descr,
                 get_url(action="dates", source="footymetrics", tipo=slug), True,
                 icona=icona_sito("footymetrics"))
    xbmcplugin.endOfDirectory(HANDLE)


def show_rb_sezioni():
    """Le sezioni di Ratingbet."""
    for slug, label, _sezioni, descr in RB_SEZIONI:
        add_item(label, descr,
                 get_url(action="dates", source="ratingbet", tipo=slug), True,
                 icona=icona_sito("ratingbet"))
    xbmcplugin.endOfDirectory(HANDLE)


def show_ss_mercati():
    """I mercati della sezione SoccerSite."""
    for slug, label, _mercati, descr in SS_MERCATI:
        add_item(label, descr,
                 get_url(action="dates", source="soccersite", tipo=slug), True,
                 icona=icona_sito("soccersite"))
    xbmcplugin.endOfDirectory(HANDLE)


def show_st_tipi():
    """Le due liste di Sportytrader, piu' la voce che le unisce."""
    for slug, label, _tipi, descr in ST_TIPI:
        add_item(label, descr,
                 get_url(action="dates", source="sportytrader", tipo=slug), True,
                 icona=icona_sito("sportytrader"))
    xbmcplugin.endOfDirectory(HANDLE)


def show_xg_mercati():
    """I mercati della sezione xGaura."""
    for slug, label, _mercati, descr in XG_MERCATI:
        add_item(label, descr,
                 get_url(action="dates", source="xgaura", tipo=slug), True,
                 icona=icona_sito("xgaura"))
    xbmcplugin.endOfDirectory(HANDLE)


def show_ao_filtri():
    """Due modi di entrare nella sezione AsianOdds.

    'Movimenti' per primo di proposito: il feed contiene ~600 partite delle
    prossime 24h, in gran parte di campionati minori, e scorrerle tutte col
    telecomando non serve a niente. Il filtro e' solo lato addon, il file
    scaricato e' lo stesso."""
    for slug, label, descr in AO_FILTRI:
        add_item(label, descr,
                 get_url(action="dates", source="asianodds", tipo=slug), True,
                 icona=icona_sito("asianodds"))
    xbmcplugin.endOfDirectory(HANDLE)


def show_pe_filtri():
    """Le viste dei prezzi equi. Il file del giorno e' uno solo."""
    for slug, label, descr in PE_FILTRI:
        add_item(label, descr,
                 get_url(action="dates", source="prezzi", tipo=slug), True)
    xbmcplugin.endOfDirectory(HANDLE)


def show_cm_filtri():
    """Tre modi di entrare nel Consensus medio.

    Il filtro vive QUI e non a monte perche' su gh-data il file di una
    giornata e' uno solo, con dentro tutte le partite. Stessa scelta fatta
    per AsianOdds e per i mercati di SoccerSite: una vista non e' un file
    in piu' da pubblicare."""
    for slug, label, descr in CM_FILTRI:
        add_item(label, descr,
                 get_url(action="dates", source="consensusmedio", tipo=slug),
                 True)
    xbmcplugin.endOfDirectory(HANDLE)


def show_wp_tipi():
    """Sottocartelle WebPronostici per tipo di pronostico."""
    disponibili = github_request("webpronostici_tipi.json", silent_404=True)
    slug_ok = None
    if isinstance(disponibili, dict) and isinstance(disponibili.get("tipi"), list):
        slug_ok = set()
        for t in disponibili["tipi"]:
            if isinstance(t, dict) and t.get("slug"):
                slug_ok.add(str(t["slug"]))

    mostrati = 0
    for slug, label in WP_TIPI:
        if slug_ok is not None and slug not in slug_ok:
            continue
        add_item(label, "WebPronostici - {}".format(label),
                 get_url(action="dates", source="webpronostici", tipo=slug), True,
                 icona=icona_sito("webpronostici"))
        mostrati += 1

    if mostrati == 0:
        for slug, label in WP_TIPI:
            add_item(label, "WebPronostici - {}".format(label),
                     get_url(action="dates", source="webpronostici", tipo=slug), True,
                     icona=icona_sito("webpronostici"))

    xbmcplugin.endOfDirectory(HANDLE)


def index_name(source, tipo):
    if source == "webpronostici" and tipo:
        return "webpronostici_{}_index.json".format(tipo)
    return "{}_index.json".format(source)


def data_name(source, tipo, date):
    if source == "webpronostici" and tipo:
        return "webpronostici_{}_{}.json".format(tipo, date)
    return "{}_{}.json".format(source, date)


def show_dates(source, tipo=""):
    if source not in SORGENTI:
        notify_error("Sorgente non valida")
        xbmcplugin.endOfDirectory(HANDLE)
        return

    # Per AsianOdds il 404 e' il caso normale finche' il workflow non ha
    # pubblicato il primo indice: meglio dirlo che mandare l'utente a
    # controllare repository e token, che sono a posto.
    # Sezioni con un file proprio: finche' il workflow non ha pubblicato il
    # primo indice il 404 e' il caso NORMALE, non un guasto. Dirlo evita che
    # si vada a controllare repository e token, che sono a posto.
    e_nuova = source in ("asianodds", "fpnet", "xgaura", "sportytrader",
                         "soccersite", "ratingbet", "betimate",
                         "footymetrics", "consensusmedio", "prezzi",
                         "poisson")
    etichetta = {"asianodds": "AsianOdds",
                 "consensusmedio": "Consensus medio",
                 "prezzi": "Prezzi equi",
                 "poisson": "Poisson xG",
                 "fpnet": "FootballPredictions",
                 "xgaura": "xGaura",
                 "sportytrader": "Sportytrader",
                 "soccersite": "SoccerSite",
                 "ratingbet": "Ratingbet",
                 "betimate": "Betimate",
                 "footymetrics": "FootyMetrics"}.get(source, source)
    data = github_request(index_name(source, tipo), silent_404=e_nuova)
    if not data:
        if e_nuova:
            notify_error("{}: nessun dato ancora pubblicato su "
                         "gh-data".format(etichetta))
        xbmcplugin.endOfDirectory(HANDLE)
        return

    if isinstance(data, dict):
        dates = data.get("date") or data.get("dates") or []
        updated = data.get("updated", "")
    elif isinstance(data, list):
        dates = data
        updated = ""
    else:
        notify_error("Indice con formato non valido")
        xbmcplugin.endOfDirectory(HANDLE)
        return

    if not dates:
        notify_error("Nessuna data disponibile")

    for d in sorted([str(x) for x in dates], reverse=True):
        add_item(d, "Aggiornato: {}".format(updated),
                 get_url(action="matches", source=source, tipo=tipo, date=d), True)

    xbmcplugin.endOfDirectory(HANDLE)


# ---------------------------------------------------------------- partite

def fmt_pct(v):
    """Restituisce la percentuale senza simbolo, stringa vuota se assente."""
    s = str(v).strip()
    if not s or s.lower() == "nan":
        return ""
    return s.replace("%", "")


def row_statarea(row):
    casa = str(row.get("Casa", ""))
    ospite = str(row.get("Ospite", ""))
    ora = str(row.get("Ora", ""))
    pron = str(row.get("TIP", "")).upper()
    p1 = fmt_pct(row.get("P_1", ""))
    px = fmt_pct(row.get("P_X", ""))
    p2 = fmt_pct(row.get("P_2", ""))
    o15 = fmt_pct(row.get("Over1.5", ""))
    o25 = fmt_pct(row.get("Over2.5", ""))
    o35 = fmt_pct(row.get("Over3.5", ""))
    btts = fmt_pct(row.get("BTTS_SI", ""))
    ht1 = fmt_pct(row.get("HT1", ""))
    htx = fmt_pct(row.get("HTX", ""))
    ht2 = fmt_pct(row.get("HT2", ""))
    comp = str(row.get("Competizione", ""))
    paese = str(row.get("Paese", ""))

    perc = ""
    if p1 and px and p2:
        perc = "  1:{} X:{} 2:{}".format(p1, px, p2)

    label = "{} {} {} vs {}{}".format(
        PRON_ICONS.get(pron, "[?]"), ora, casa, ospite, perc
    )
    plot = (
        "{} - {}\n"
        "Pronostico: {}\n"
        "1X2:  1:{}%  X:{}%  2:{}%\n"
        "HT:   1:{}%  X:{}%  2:{}%\n"
        "Over: 1.5:{}%  2.5:{}%  3.5:{}%\n"
        "BTTS: {}%"
    ).format(paese, comp, pron, p1, px, p2, ht1, htx, ht2, o15, o25, o35, btts)
    return label, plot


def row_webpronostici(row):
    casa = str(row.get("Casa", ""))
    ospite = str(row.get("Ospite", ""))
    ora = str(row.get("Ora", ""))
    pron = str(row.get("Pronostico", "")).upper()
    quota = str(row.get("Quota", ""))
    camp = str(row.get("Campionato", ""))
    tipo = str(row.get("Tipo", ""))

    quota_txt = "  @{}".format(quota) if quota and quota.lower() != "nan" else ""
    ora_txt = "{} ".format(ora) if ora and ora.lower() != "nan" else ""

    label = "{} {}{} vs {}{}".format(
        PRON_ICONS.get(pron, "[" + pron + "]"), ora_txt, casa, ospite, quota_txt
    )
    plot = "Campionato: {}\nTipo: {}\nPronostico: {}\nQuota: {}".format(
        camp, tipo, pron, quota
    )
    return label, plot


# I campi AsianOdds dentro il consensus, e come si chiamano nel file
# AsianOdds vero. Servono a rinfrescarli: vedi _ao_aggiornato.
_AO_DA_VIVO = {
    "AO Drift 1": "Drift 1", "AO Drift X": "Drift X", "AO Drift 2": "Drift 2",
    "AO AH Open": "AH Apre", "AO AH": "AH",
    "AO OU Open": "OU Apre", "AO OU": "OU",
    "AO Elo Casa": "Elo Casa", "AO Elo Osp": "Elo Osp",
}


def _ao_aggiornato(row, vivo):
    """La riga di consensus con i numeri AsianOdds dell'ultimo giro.

    PERCHE' SERVE. Il consensus si costruisce una volta a notte e si porta
    dentro uno SCATTO delle quote di quel momento; AsianOdds invece si
    rinfresca ogni tre ore. Risultato: la stessa partita mostrava due
    movimenti diversi nelle due sezioni dell'addon, senza che si capisse
    quale fosse il piu' recente. Misurato il 30/09 su Sporting Lagos -
    Ikorodu City: il consensus, scattato alle 00:36, diceva 1 +17.5%; il
    file AsianOdds delle 02:36 diceva +9.6%, perche' nel frattempo la
    quota era tornata da 2.69 a 2.51. Nessuno dei due era sbagliato, ma
    uno dei due era vecchio di due ore.

    Dove AsianOdds non arriva - copre le prossime 24 ore, il consensus
    anche i giorni dopo - resta lo scatto del consensus, che e' meglio di
    niente."""
    if not isinstance(vivo, dict):
        return row, False
    nuovo = dict(row)
    cambiato = False
    for k_cons, k_vivo in _AO_DA_VIVO.items():
        v = vivo.get(k_vivo)
        if v is None or v == "":
            continue
        if nuovo.get(k_cons) != v:
            cambiato = True
        nuovo[k_cons] = v
    return nuovo, cambiato


def row_consensus(row, mercato=None, stima=None):
    casa = str(row.get("Casa", ""))
    ospite = str(row.get("Ospite", ""))
    ora = str(row.get("Ora", ""))
    pron = str(row.get("Pron Combinato", "")).upper()
    psa = str(row.get("Pron Statarea", ""))
    pwp = str(row.get("Pron WebPron", ""))
    p1 = fmt_pct(row.get("P_1 %", ""))
    px = fmt_pct(row.get("P_X %", ""))
    p2 = fmt_pct(row.get("P_2 %", ""))
    o15 = fmt_pct(row.get("Over1.5 %", ""))
    o25 = fmt_pct(row.get("Over2.5 %", ""))
    btts = fmt_pct(row.get("BTTS %", ""))
    quota = str(row.get("Quota WP", ""))
    xg_casa = row.get("xG Casa", "")
    xg_ospite = row.get("xG Ospite", "")

    perc = ""
    if p1 and px and p2:
        perc = "  1:{} X:{} 2:{}".format(p1, px, p2)

    # xG solo se ALMENO una delle due squadre ce l'ha (top-5 leghe europee
    # via Understat). Sulle altre leghe questo campo resta assente: non e'
    # un guasto, e' un limite della fonte - vedi consensus.py v4.
    xg_riga = ""
    if xg_casa != "" or xg_ospite != "":
        xg_riga = "\nxG:  {} - {}".format(
            xg_casa if xg_casa != "" else "-",
            xg_ospite if xg_ospite != "" else "-")

    label = "{} {} {} vs {}{}".format(
        PRON_ICONS.get(pron, "[?]"), ora, casa, ospite, perc
    )
    # "Quota WP:" senza niente dietro sembrava un dato mancante per errore.
    # WebPronostici la quota non la pubblica per tutte le partite (8 righe
    # su 55, contate sul 30/09): dove non c'e', la riga sparisce.
    riga_quota = "\nQuota WP: {}".format(quota) if quota.strip() else ""
    plot = (
        "Pronostico combinato: {}\n"
        "Statarea: {}   WebPronostici: {}\n"
        "1X2:  1:{}%  X:{}%  2:{}%\n"
        "Over: 1.5:{}%  2.5:{}%\n"
        "BTTS: {}%"
        "{}{}"
    ).format(pron, psa, pwp, p1, px, p2, o15, o25, btts, riga_quota, xg_riga)

    # Il ripiego di Ratingbet. Qui il confronto e' con la percentuale che
    # il consensus stesso da' al pronostico combinato: sulle doppie - 1X,
    # 12, X2 - e' la somma di due dei tre esiti, da tutte e due le parti,
    # quindi i due numeri sono confrontabili.
    extra = []
    _CAMPI_CONS = {"1": ("P_1 %",), "X": ("P_X %",), "2": ("P_2 %",),
                   "1X": ("P_1 %", "P_X %"), "12": ("P_1 %", "P_2 %"),
                   "X2": ("P_X %", "P_2 %")}
    valori = [_num(fmt_pct(row.get(c)))
              for c in _CAMPI_CONS.get(pron, ())]
    p_sito = sum(valori) if valori and not any(v is None for v in valori) else None
    _righe_stima(extra, pron, _chiave_incontro(row), stima, p_sito)

    riga_ao, aggiornato = _ao_aggiornato(
        row, _riga_mercato_consensus(mercato, row))
    if extra:
        plot += "\n" + "\n".join(extra)
    return label, plot + righe_asianodds(riga_ao, aggiornato)


def _vuoto(v):
    return v is None or v == ""


def righe_asianodds(row, aggiornato=False):
    """Righe AsianOdds per il riquadro dettagli - solo informative.

    Quote 1xBet (soft book): NON sono un voto e non entrano nel pronostico.
    Il drift e' la variazione % della quota da apertura a ora:
    negativo = quota scesa = il mercato ci crede di piu' su quell'esito.
    Ogni riga compare solo se il dato c'e' (piano free: solo prossime 24h).
    Si usano solo caratteri ASCII per non dipendere dal font dello skin."""
    righe = []

    d1, dx, d2 = row.get("AO Drift 1"), row.get("AO Drift X"), row.get("AO Drift 2")
    if not (_vuoto(d1) and _vuoto(dx) and _vuoto(d2)):
        def fd(v):
            try:
                return "{:+.1f}%".format(float(v))
            except (TypeError, ValueError):
                return "-"
        # L'ETICHETTA DICE COSA SONO, e non e' pedanteria: scritta "1xBet:
        # 1 +17.5%" sembrava la quota, e una quota del genere non esiste.
        # Sono di quanto la quota si e' MOSSA dall'apertura.
        righe.append("Movimento quote 1xBet dall'apertura:  1 {}   X {}   "
                     "2 {}".format(fd(d1), fd(dx), fd(d2)))
        righe.append("  (meno = quota scesa = il mercato ci crede di piu')")
        if aggiornato:
            righe.append("  (numeri dell'ultimo giro AsianOdds, non dello "
                         "scatto notturno del consensus)")

    parti = []
    ah_o, ah = row.get("AO AH Open"), row.get("AO AH")
    if not _vuoto(ah_o) and not _vuoto(ah):
        try:
            parti.append("AH {:+.2f}->{:+.2f}".format(float(ah_o), float(ah)))
        except (TypeError, ValueError):
            pass
    ou_o, ou = row.get("AO OU Open"), row.get("AO OU")
    if not _vuoto(ou_o) and not _vuoto(ou):
        try:
            parti.append("O/U {:.2f}->{:.2f}".format(float(ou_o), float(ou)))
        except (TypeError, ValueError):
            pass
    if parti:
        righe.append("  ".join(parti))

    ec, eo = row.get("AO Elo Casa"), row.get("AO Elo Osp")
    if not _vuoto(ec) and not _vuoto(eo):
        try:
            righe.append("Elo: {} - {}".format(int(float(ec)), int(float(eo))))
        except (TypeError, ValueError):
            pass

    return ("\n" + "\n".join(righe)) if righe else ""


def _num(v):
    """Valore numerico, o None se assente/non numerico."""
    if v is None or v == "":
        return None
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def _e_notevole(row):
    """Vale il filtro "Movimenti"? Decide asianodds_ci.py, qui si legge.

    Il campo "Notevole" tiene conto sia del movimento sia del margine del
    bookmaker: un movimento piccolo su un mercato quotato con cura (margine
    basso) conta piu' di uno grande su una lega minore, dove le quote di
    apertura sono approssimative e il movimento e' spesso solo la loro
    correzione.

    Se il campo manca - JSON prodotti prima della sua introduzione - si
    ripiega sulla sola soglia in punti, cosi' la sezione continua a
    funzionare invece di svuotarsi."""
    if "Notevole" in row:
        return bool(row.get("Notevole"))
    mov = _num(row.get("Mov"))
    return mov is not None and mov >= AO_SOGLIA_MOV


def _e_affidabile(row):
    """La probabilita' e' una stima attendibile? Decide asianodds_ci.py.

    Attendibile non vuol dire conveniente: sono le stime migliori del
    mercato, quindi il prezzo le incorpora gia'. Servono come metro, non
    come pronostico."""
    return bool(row.get("Affidabile"))


def _xg_mercati(tipo):
    """I valori del campo Mercato della voce scelta.

    Tupla vuota = nessun filtro, cioe' la voce "Tutti". None = slug non
    riconosciuto, e anche li' si mostra tutto invece di una lista vuota."""
    for slug, _label, mercati, _descr in XG_MERCATI:
        if slug == tipo:
            return mercati
    return ()


def _prob_implicita(quota):
    """Probabilita' implicita in una quota decimale, o None.

    ATTENZIONE a come va letta. La quota e' dichiarata dal sito come la
    MIGLIORE fra piu' bookmaker, non quella di un libro solo. La quota piu'
    alta e' anche quella con la probabilita' implicita piu' BASSA, quindi
    questo numero e' una stima per DIFETTO della probabilita' vera: il
    margine del bookmaker, che di solito la gonfia del 5-8%, qui e' in gran
    parte gia' tolto dalla concorrenza fra operatori. Serve come metro di
    paragone con quello che dichiara il sito, non come probabilita' esatta.
    """
    q = _num(quota)
    if q is None or q < 1.01:
        return None
    return 1.0 / q


def _st_tipi(tipo):
    """I valori del campo Tipo della voce scelta, o tupla vuota = tutto."""
    for slug, _label, tipi, _descr in ST_TIPI:
        if slug == tipo:
            return tipi
    return ()


def _chiave_incontro(row):
    """Chiave con cui riconoscere lo STESSO incontro fra due fonti diverse.

    Non i nomi: Sportytrader scrive in italiano ("Repubblica Ceca") e
    AsianOdds in inglese ("Czech Republic"), e un confronto fra stringhe
    aggancia 15 righe su 101. Si usano invece i due file di stemma, che la
    mappa dei nomi sa gia' ricavare da 4290 grafie diverse: due squadre che
    prendono lo stesso stemma sono la stessa squadra. Misurato, si passa da
    15 a 20 righe su 101.

    None quando uno dei due stemmi non si trova: senza, due partite diverse
    entrambe senza logo diventerebbero la stessa.
    """
    dove = _campi_riga(row)
    casa = logo_per_squadra(row.get("Casa"), dove)
    ospite = logo_per_squadra(row.get("Ospite"), dove)
    if not casa or not ospite:
        return None
    # Il terzo pezzo separa femminile, giovanili e riserve dalla prima
    # squadra: senza, prendono lo stesso stemma e diventano la stessa
    # partita. Vedi _variante.
    return (os.path.basename(casa), os.path.basename(ospite),
            _variante(row.get("Casa"), row.get("Ospite"), dove))


def carica_mercato(date):
    """Le probabilita' di mercato AsianOdds del giorno, per incontro.

    SERVE A UNA COSA SOLA: dare un metro di paragone de-viggato davvero.
    La percentuale ricavata da una quota singola (1/quota) contiene ancora
    il margine del bookmaker e quindi sovrastima; il margine pero' si
    misura solo sull'insieme completo degli esiti, e Sportytrader pubblica
    solo la quota dell'esito consigliato. AsianOdds invece pubblica la
    terna 1X2 e asianodds_ci.py ne ricava P1/PX/P2 gia' senza margine.

    COPERTURA PARZIALE E VOLUTA: AsianOdds copre le prossime 24 ore,
    Sportytrader sei giorni. Misurato sul 29/09: 20 righe su 101 oggi, 2 su
    99 domani, zero dopo. Dove non arriva, la riga non mostra niente -
    meglio il silenzio di un numero inventato.
    """
    dati = github_request("asianodds_{}.json".format(date), silent_404=True)
    if isinstance(dati, dict):
        for k in ("matches", "data", "results", "rows"):
            if isinstance(dati.get(k), list):
                dati = dati[k]
                break
    if not isinstance(dati, list):
        return {}
    # DUE INDICI sugli stessi dati.
    #
    # "logo": coppia di stemmi -> variante -> riga. E' quello che serve fra
    # fonti in lingue diverse, dove i nomi non si somigliano affatto.
    #
    # "ora": (orario, nome normalizzato) -> riga. Serve SOLO al consensus,
    # che con AsianOdds condivide la lingua ma non la grafia: il consensus
    # tiene i nomi di Statarea - "ASD Imperia", "Sarpsborg 08 FF",
    # "Shooting Stars", "Sestao River" - dove AsianOdds scrive "Imperia",
    # "Sarpsborg 08", "Shooting", "Sestao". Vedi _riga_mercato_consensus.
    per_logo = {}
    per_ora = {}
    for r in dati:
        if not isinstance(r, dict):
            continue
        k = _chiave_incontro(r)
        if k:
            per_logo.setdefault(k[:2], {}).setdefault(k[2], r)
        ora = str(r.get("Ora", "")).strip()
        if ora:
            for nome in (r.get("Casa"), r.get("Ospite")):
                n = normalizza_squadra(nome)
                if n:
                    per_ora.setdefault((ora, n), r)
    return {"logo": per_logo, "ora": per_ora}


def _riga_mercato(indice, chiave):
    """La riga di mercato per questa partita, o None.

    DUE PASSAGGI, e servono entrambi - misurato il 30/09 su gh-data.

    1. Variante identica. E' il caso normale e l'unico che distingue la
       nazionale maggiore dalla sua Under 21 quando ci sono entrambe.

    2. Se la variante non combacia ma per quei due stemmi il mercato ha UNA
       SOLA partita, si prende quella. Le fonti l'eta' la scrivono a
       intermittenza: AsianOdds scrive "Uzbekistan U23 vs Japan U23",
       Sportytrader la stessa partita "Uzbekistan vs Giappone" e l'eta' non
       la mette da nessuna parte, nemmeno nel campionato ("Giochi
       Asiatici"). Con la sola regola 1 si perdevano 2 agganci su 16.

    Quando per quegli stemmi il mercato ha PIU' di una partita e nessuna
    ha la variante giusta, non si aggancia niente: e' il caso in cui
    sbagliare significherebbe mettere accanto a una partita la probabilita'
    di un'altra, e il silenzio e' meglio.
    """
    if not indice or not chiave:
        return None
    per_variante = (indice.get("logo") or {}).get(chiave[:2])
    if not per_variante:
        return None
    if chiave[2] in per_variante:
        return per_variante[chiave[2]]
    if len(per_variante) == 1:
        return list(per_variante.values())[0]
    return None


def _compatibili(a, b):
    """Due grafie della stessa squadra? Solo se una contiene l'altra.

    'sestao' dentro 'sestao river', 'imperia' dentro 'asd imperia'. Non e'
    somiglianza: e' contenimento, che su nomi brevi sbaglia molto meno.
    Si chiede almeno 4 caratteri sul piu' corto, altrimenti 'as' starebbe
    dentro mezzo campionato."""
    if not a or not b:
        return False
    if a == b:
        return True
    corto, lungo = (a, b) if len(a) <= len(b) else (b, a)
    return len(corto) >= 4 and corto in lungo


def _riga_mercato_consensus(indice, row):
    """La riga AsianOdds per una partita del consensus.

    TRE PASSAGGI. Il primo e' quello degli stemmi, buono ma qui debole:
    sul 30/09 agganciava 1 riga su 10, perche' le squadre di Serie D, di
    coppa norvegese e della Npfl nigeriana lo stemma spesso non ce l'hanno.

    Gli altri due sfruttano una cosa che vale SOLO qui: il consensus e
    AsianOdds parlano la stessa lingua. Prima i due nomi identici; poi -
    ed e' il caso piu' frequente - stesso ORARIO, un nome identico e
    l'altro che contiene o e' contenuto nell'altro. Un orario e una
    squadra identificano una partita: due partite della stessa squadra
    alla stessa ora non esistono.

    Si rifiuta l'aggancio se le due squadre portano a partite DIVERSE:
    li' una delle due e' un omonimo, e sbagliare vorrebbe dire mostrare il
    movimento di un'altra partita."""
    riga = _riga_mercato(indice, _chiave_incontro(row))
    if riga is not None or not indice:
        return riga

    per_ora = indice.get("ora") or {}
    ora = str(row.get("Ora", "")).strip()
    if not ora or not per_ora:
        return None
    casa = normalizza_squadra(row.get("Casa"))
    ospite = normalizza_squadra(row.get("Ospite"))
    da_casa = per_ora.get((ora, casa)) if casa else None
    da_ospite = per_ora.get((ora, ospite)) if ospite else None

    if da_casa is not None and da_ospite is not None:
        return da_casa if da_casa is da_ospite else None

    trovata = da_casa if da_casa is not None else da_ospite
    if trovata is None:
        return None
    # Conferma sull'altra squadra: il nome che NON ha fatto da chiave deve
    # comunque assomigliare a quello della partita trovata.
    if da_casa is not None:
        return trovata if _compatibili(
            ospite, normalizza_squadra(trovata.get("Ospite"))) else None
    return trovata if _compatibili(
        casa, normalizza_squadra(trovata.get("Casa"))) else None


# Il pronostico di Sportytrader -> le colonne della terna AsianOdds.
# Solo 1X2: per Under/Over e Gol/NoGol servirebbe far combaciare anche la
# LINEA, e una probabilita' dell'Over 2.5 messa accanto a un tip sull'Over
# 3.5 sarebbe un confronto sbagliato presentato bene.
_XG_ESITI = {"1": ("P1 Shin", "P1"), "X": ("PX Shin", "PX"),
             "2": ("P2 Shin", "P2")}


def carica_stima(date):
    """Le probabilita' 1X2 di Ratingbet del giorno, per incontro.

    SERVE DOVE ASIANODDS NON ARRIVA. Il mercato copre le prossime 24 ore;
    oltre, il confronto de-viggato sparisce proprio quando servirebbe -
    misurato il 30/09 sulla giornata di domani: AsianOdds dava un metro a
    2 partite di SoccerSite su 24, Ratingbet a 21.

    PERCHE' PROPRIO RATINGBET e non un'altra fonte: le sue tre
    percentuali sommano a 100 esatti - e' una distribuzione vera, gia'
    senza margine - e messe accanto al mercato de-viggato di AsianOdds
    coincidono quasi: su 48 esiti, scarto assoluto medio 2,0 punti,
    correlazione 0,994, favorito diverso in 1 partita su 16.

    IL LIMITE, che va detto ogni volta che si mostra il numero: quelle 16
    partite sono quelle che AsianOdds copre, cioe' le piu' liquide. Dove
    il ripiego serve davvero - Canadian Premier League, Serie D, Npfl -
    la corrispondenza non l'ha verificata nessuno. Resta il modello di un
    sito, e nell'addon si chiama cosi'.
    """
    dati = github_request("ratingbet_{}.json".format(date), silent_404=True)
    if not isinstance(dati, list):
        return {}
    per_logo = {}
    for r in dati:
        if not isinstance(r, dict) or str(r.get("Sezione")) != "1X2":
            continue
        k = _chiave_incontro(r)
        if k:
            per_logo.setdefault(k[:2], {}).setdefault(k[2], r)
    return {"logo": per_logo, "ora": {}}


# Il pronostico -> i campi della terna Ratingbet.
#
# ATTENZIONE ai nomi: nel file di Ratingbet le colonne sono POSIZIONALI -
# P1, P2, P3 sono il primo, il secondo e il terzo blocco di mercato, che
# sull'1X2 sono 1, X e 2. Quindi la X sta in "P2" e il 2 in "P3". Leggerli
# come P1/PX/P2 scambierebbe pareggio e vittoria ospite senza che niente
# se ne accorga.
_STIMA_CAMPI = {"1": ("P1",), "X": ("P2",), "2": ("P3",),
                "1X": ("P1", "P2"), "12": ("P1", "P3"), "X2": ("P2", "P3")}


def _stima_ratingbet(pronostico, riga_rb):
    """La probabilita' che Ratingbet da' a quel pronostico, 0-100, o None.

    Sulle doppie chance e' la somma di due esiti: aritmetica, non una
    stima in piu' - la terna somma a 100 per costruzione."""
    campi = _STIMA_CAMPI.get(str(pronostico or "").strip().upper())
    if not campi or not isinstance(riga_rb, dict):
        return None
    valori = [_num(riga_rb.get(c)) for c in campi]
    if any(v is None for v in valori):
        return None
    return sum(valori)


def _righe_stima(righe, pronostico, chiave, stima, prob_sito):
    """Aggiunge le due righe del ripiego, se c'e' qualcosa da aggiungere.

    Restituisce True se ha scritto qualcosa, cosi' chi chiama sa se deve
    ripiegare ancora sull'avviso del margine."""
    p = _stima_ratingbet(pronostico, _riga_mercato(stima, chiave))
    if p is None:
        return False
    righe.append("Stima Ratingbet: {:.0f}%   (loro modello, non un "
                 "mercato)".format(p))
    if prob_sito is not None:
        righe.append("Scarto sito-Ratingbet: {} punti".format(
            _punti(prob_sito - p)))
    return True


def _punti(scarto):
    """Lo scarto in punti, formattato. Evita il "-0".

    Uno scarto di -0.3 punti arrotondato diventa "-0 punti", che si legge
    come un numero negativo mentre e' zero. A quel punto tanto vale
    scrivere che le due cifre coincidono."""
    if abs(scarto) < 0.5:
        return "0"
    return "{:+.0f}".format(scarto)


def _prob_mercato(pronostico, riga_ao):
    """(probabilita' 0-1, margine) dal mercato AsianOdds, o (None, None).

    Shin quando c'e', proporzionale come ripiego: e' lo stesso ordine di
    preferenza del Sistema. Shin carica piu' margine sugli esiti lunghi,
    come fanno i bookmaker davvero, mentre il proporzionale lo toglie in
    parti uguali."""
    campi = _XG_ESITI.get(str(pronostico or "").strip().upper())
    if not campi or not isinstance(riga_ao, dict):
        return None, None
    for c in campi:
        v = _num(riga_ao.get(c))
        if v is not None:
            return v / 100.0, _num(riga_ao.get("Margine"))
    return None, None


def row_sportytrader(row, mercato=None, stima=None):
    """Riga della sezione Sportytrader.

    RUOLO: una fonte di pronostici fra le tante. Non entra nel consensus e
    non vota.

    La 'probabilita'' arriva solo dalla lista 1X2 e la dichiara il sito:
    come per xGaura, sta qui accanto a quella implicita nella quota e non
    filtra niente. Due numeri vicini, e si vede quando divergono.

    Solo caratteri ASCII: le frecce unicode dipendono dal font dello skin.
    """
    casa = str(row.get("Casa", ""))
    ospite = str(row.get("Ospite", ""))
    ora = str(row.get("Ora", ""))
    pron = str(row.get("Pronostico", "")).strip()
    quota = _num(row.get("Quota"))
    prob = _num(row.get("Prob"))

    testa = "  {}".format(pron) if pron else ""
    coda = "  @ {:.2f}".format(quota) if quota is not None else ""
    # La percentuale dichiarata dal sito anche in etichetta, come nelle
    # altre sezioni: scorrendo la lista e' il numero che si cerca, e
    # aprire i dettagli riga per riga col telecomando non e' pratico.
    perc = "  {:.0f}%".format(prob * 100) if prob is not None else ""
    label = "{} {} vs {}{}{}{}".format(ora, casa, ospite, testa, coda, perc)

    righe = []
    lega = str(row.get("Lega", "")).strip()
    if lega:
        righe.append(lega)

    implicita = _prob_implicita(quota)
    if quota is not None:
        testo = "Quota: {:.2f}".format(quota)
        if implicita is not None:
            testo += "  ->  implica il {:.0f}%".format(implicita * 100)
        righe.append(testo)
    if prob is not None:
        testo = "Il sito dichiara {:.0f}%".format(prob * 100)
        if implicita is not None:
            testo += "  ({:+.0f} punti rispetto al prezzo)".format(
                (prob - implicita) * 100)
        righe.append(testo)

    # Il mercato SENZA margine, quando AsianOdds ha la stessa partita.
    #
    # E' la sola riga qui dentro che sia una probabilita' vera: viene dalla
    # terna 1X2 completa, de-viggata col metodo di Shin. Quella ricavata
    # dalla quota singola qui sopra il margine ce l'ha ancora dentro, e
    # toglierlo da un prezzo solo non si puo': il margine e' definito sulla
    # somma dei tre esiti.
    p_mercato, margine = _prob_mercato(
        row.get("Pronostico"),
        _riga_mercato(mercato, _chiave_incontro(row)))
    if p_mercato is not None:
        testo = "Mercato senza margine: {:.0f}%".format(p_mercato * 100)
        if margine is not None:
            testo += "  (margine tolto: {:.1f}%)".format(margine)
        righe.append(testo)
        if prob is not None:
            righe.append("Scarto vero sito-mercato: {} punti".format(
                _punti((prob - p_mercato) * 100)))
    elif _righe_stima(righe, row.get("Pronostico"), _chiave_incontro(row),
                      stima, None if prob is None else prob * 100):
        # Il ripiego ha parlato: l'avviso sul margine qui sotto sarebbe
        # solo rumore, perche' un metro migliore della quota singola c'e'.
        pass
    elif implicita is not None:
        # Senza nessun metro resta la stima dalla quota singola, e va detto
        # che e' per eccesso: il margine e' dentro, quindi lo scarto che si
        # legge e' piu' BASSO del vero e il sito ne esce peggio di quanto
        # sia. E' il verso prudente.
        righe.append("La percentuale implicita comprende il margine del "
                     "bookmaker: e' una stima per eccesso.")

    return label, "\n".join(righe)


def _ss_mercati(tipo):
    """I valori del campo Mercato della voce scelta, o tupla vuota = tutto."""
    for slug, _label, mercati, _descr in SS_MERCATI:
        if slug == tipo:
            return mercati
    return ()


# Come si leggono i tre badge di percentuale, mercato per mercato.
# Il sito ne pubblica tre sull'1X2 e sulla doppia chance (sono gli stessi
# tre) e due soltanto su Under/Over e Gol/NoGol.
_SS_ETICHETTE = {
    "1X2":   ("1", "X", "2"),
    "DC":    ("1", "X", "2"),
    "OU2.5": ("Over", "Under", None),
    "BTTS":  ("Gol", "NoGol", None),
}


def row_soccersite(row, mercato=None, stima=None):
    """Riga della sezione SoccerSite.

    RUOLO: una fonte di pronostici fra le tante. Non entra nel consensus e
    non vota.

    La percentuale del pronostico NON si ricalcola qui: la decide
    soccersite_scraper.py e la scrive nel campo Prob, come il campo
    Notevole di AsianOdds. Il motivo e' che su doppia chance quella
    percentuale e' una SOMMA di due badge, e una regola del genere scritta
    in due posti prima o poi diverge: il giorno che la si corregge da una
    parte sola, Kodi mostrerebbe numeri diversi dall'Excel.

    Solo caratteri ASCII: le frecce unicode dipendono dal font dello skin.
    """
    casa = str(row.get("Casa", ""))
    ospite = str(row.get("Ospite", ""))
    ora = str(row.get("Ora", ""))
    merc = str(row.get("Mercato", "")).strip()
    tip = str(row.get("Tip", "")).strip()
    quota = _num(row.get("Quota"))
    prob = _num(row.get("Prob"))

    testa = "  {}".format(tip) if tip else ""
    coda = "  @ {:.2f}".format(quota) if quota is not None else ""
    perc = "  {:.0f}%".format(prob) if prob is not None else ""
    label = "{} {} vs {}{}{}{}".format(ora, casa, ospite, testa, coda, perc)

    righe = []
    lega = str(row.get("Lega", "")).strip()
    if lega:
        righe.append(lega)

    # I badge cosi' come li pubblica il sito, con l'etichetta giusta per
    # il mercato: su Under/Over il terzo non esiste e non va inventato.
    et = _SS_ETICHETTE.get(merc)
    if et:
        parti = []
        for nome, valore in zip(et, (row.get("PA"), row.get("PB"), row.get("PC"))):
            v = _num(valore)
            if nome and v is not None:
                parti.append("{} {:.0f}%".format(nome, v))
        if parti:
            righe.append("Il sito dichiara:  " + "   ".join(parti))

    if merc == "DC" and prob is not None:
        righe.append("Doppia chance {}: {:.0f}%, cioe' la somma dei due "
                     "esiti qui sopra.".format(tip, prob))

    implicita = _prob_implicita(quota)
    if quota is not None:
        testo = "Quota: {:.2f}".format(quota)
        if implicita is not None:
            testo += "  ->  implica il {:.0f}%".format(implicita * 100)
        righe.append(testo)

    # Il confronto de-viggato, dove AsianOdds ha la stessa partita. Vale
    # solo sull'1X2: per Under/Over servirebbe far combaciare anche la
    # linea, e qui la linea e' 2,5 mentre AsianOdds pubblica la terna 1X2.
    p_mercato, margine = (None, None)
    if merc == "1X2":
        p_mercato, margine = _prob_mercato(
            tip, _riga_mercato(mercato, _chiave_incontro(row)))
    if p_mercato is not None:
        testo = "Mercato senza margine: {:.0f}%".format(p_mercato * 100)
        if margine is not None:
            testo += "  (margine tolto: {:.1f}%)".format(margine)
        righe.append(testo)
        if prob is not None:
            righe.append("Scarto vero sito-mercato: {} punti".format(
                _punti(prob - p_mercato * 100)))
    elif _righe_stima(righe, tip, _chiave_incontro(row), stima, prob):
        pass
    elif implicita is not None:
        righe.append("La quota e' di un bookmaker solo, quindi la "
                     "percentuale implicita comprende il margine: e' una "
                     "stima per eccesso.")

    ris = str(row.get("Risultato", "")).strip()
    if ris:
        righe.append("Risultato esatto previsto dal sito: {}".format(ris))

    return label, "\n".join(righe)


def _rb_sezioni(tipo):
    """I valori del campo Sezione della voce scelta, o tupla vuota = tutto."""
    for slug, _label, sezioni, _descr in RB_SEZIONI:
        if slug == tipo:
            return sezioni
    return ()


# Come si leggono le colonne Q1/P1, Q2/P2, Q3/P3 mercato per mercato.
# Sono nell'ordine in cui il sito mette i blocchi, e cambiano significato:
# sull'1X2 sono i tre esiti, sull'Under/Over sono Over e Under, e la
# LINEA non e' fra queste - viaggia in un campo suo, perche' 2.5 non e'
# un prezzo.
_RB_ESITI = {
    "1X2":  ("1", "X", "2"),
    "DC":   ("1/X", "1/2", "X/2"),
    "OU":   ("Over", "Under", None),
    "BTTS": ("Gol", "NoGol", None),
}

# Il tip di Ratingbet -> il segno 1X2, per il confronto col mercato.
# Solo l'1X2: su Under/Over servirebbe far combaciare anche la linea, e
# AsianOdds pubblica la terna 1X2, non i totali.
_RB_SEGNO = {"W1": "1", "X": "X", "W2": "2"}


def row_ratingbet(row, mercato=None):
    """Riga della sezione Ratingbet.

    RUOLO: una fonte di pronostici fra le tante. Non entra nel consensus e
    non vota.

    L'ORARIO DI QUESTA FONTE HA UNA STORIA. Il sito serve orari diversi a
    richieste diverse - misurato su tre giri dello stesso pomeriggio: 7, 6
    e 9 ore di scarto - quindi ratingbet_ci.py il fuso non lo scrive, lo
    MISURA a ogni giro confrontando le partite con AsianOdds. Qui arriva
    gia' corretto, e accanto viaggia l'ora grezza del sito per poterlo
    ricontrollare.

    Solo caratteri ASCII: le frecce unicode dipendono dal font dello skin.
    """
    casa = str(row.get("Casa", ""))
    ospite = str(row.get("Ospite", ""))
    ora = str(row.get("Ora", ""))
    sez = str(row.get("Sezione", "")).strip()
    tip = str(row.get("Tip", "")).strip()
    quota = _num(row.get("Quota"))
    prob = _num(row.get("Prob"))
    linea = _num(row.get("Linea"))

    # Sull'Under/Over il tip da solo non dice niente: "O2.5" si legge, ma
    # quando il sito cambia linea - e la cambia - "Over" senza numero
    # sarebbe ambiguo. La linea entra in etichetta.
    testa = "  {}".format(tip) if tip else ""
    if sez == "OU" and linea is not None and tip and str(linea) not in tip:
        testa += " {:.1f}".format(linea)
    coda = "  @ {:.2f}".format(quota) if quota is not None else ""
    perc = "  {:.0f}%".format(prob) if prob is not None else ""
    label = "{} {} vs {}{}{}{}".format(ora, casa, ospite, testa, coda, perc)

    righe = []
    lega = str(row.get("Lega", "")).strip()
    if lega:
        righe.append(lega)

    if sez == "MATH":
        # Senza questa riga sembrerebbe una percentuale come le altre,
        # mentre viene da un modello diverso e sullo stesso esito da'
        # numeri diversi.
        righe.append("Previsione matematica del sito: e' un modello a se', "
                     "non il riassunto delle altre sezioni.")
    mercato_testo = str(row.get("Mercato", "")).strip()
    if mercato_testo and mercato_testo != tip:
        righe.append("Mercato: {}".format(mercato_testo))

    et = _RB_ESITI.get(sez)
    if et:
        parti = []
        for nome, q, p in zip(et, (row.get("Q1"), row.get("Q2"), row.get("Q3")),
                              (row.get("P1"), row.get("P2"), row.get("P3"))):
            if not nome:
                continue
            vq, vp = _num(q), _num(p)
            if vq is None and vp is None:
                continue
            pezzo = nome
            if vp is not None:
                pezzo += " {:.0f}%".format(vp)
            if vq is not None:
                pezzo += " @{:.2f}".format(vq)
            parti.append(pezzo)
        if parti:
            righe.append("   ".join(parti))

    implicita = _prob_implicita(quota)
    if quota is not None and implicita is not None:
        righe.append("La quota implica il {:.0f}%".format(implicita * 100))

    p_mercato, margine = (None, None)
    if sez in ("1X2", "MATH"):
        p_mercato, margine = _prob_mercato(
            _RB_SEGNO.get(tip.upper()),
            _riga_mercato(mercato, _chiave_incontro(row)))
    if p_mercato is not None:
        testo = "Mercato senza margine: {:.0f}%".format(p_mercato * 100)
        if margine is not None:
            testo += "  (margine tolto: {:.1f}%)".format(margine)
        righe.append(testo)
        if prob is not None:
            righe.append("Scarto vero sito-mercato: {} punti".format(
                _punti(prob - p_mercato * 100)))

    ora_sito = str(row.get("OraSito", "")).strip()
    if ora_sito and ora_sito != ora:
        righe.append("Orario sul sito: {} - qui convertito misurando il "
                     "fuso a ogni giro.".format(ora_sito))

    return label, "\n".join(righe)


def _bt_campo(tipo):
    """Il campo che dice se la riga ha quel mercato, "" = nessun filtro."""
    for slug, _label, campo, _descr in BT_MERCATI:
        if slug == tipo:
            return campo
    return ""


def row_betimate(row, mercato=None, stima=None):
    """Riga della sezione Betimate.

    RUOLO: informativa, NON vota. Entra come ci entro' Ratingbet - prima
    si mostra, poi si misura quanto e' correlata con le fonti che gia'
    votano, e solo allora si decide. Su Ratingbet quella misura disse di
    no: era il mercato travestito.

    UNA RIGA PORTA TUTTI I MERCATI, al contrario di SoccerSite e
    Ratingbet. Il parametro 'tipo' non toglie partite, sceglie quali
    numeri scrivere: le partite restano le stesse.

    IL RISULTATO ESATTO PREVISTO NON E' IL RISULTATO. Betimate pubblica
    tutti e due - quello che prevede e, a partita finita, quello vero - e
    scriverli vicini senza etichetta sarebbe il modo piu' rapido per
    leggere l'uno per l'altro. Qui stanno su due righe diverse, con due
    parole diverse.

    Solo caratteri ASCII: le frecce unicode dipendono dal font dello skin.
    """
    casa = str(row.get("Casa", ""))
    ospite = str(row.get("Ospite", ""))
    ora = str(row.get("Ora", ""))
    tipo = str(row.get("_tipo", "") or "tutti")

    p1, px, p2 = (_num(row.get("P1")), _num(row.get("PX")), _num(row.get("P2")))
    pron = str(row.get("Pron", "")).strip()
    uo_pron = str(row.get("UO_Pron", "")).strip()
    p_un, p_ov = _num(row.get("P_Under")), _num(row.get("P_Over"))
    linea = _num(row.get("UO_Linea"))
    gg_pron = str(row.get("BTTS_Pron", "")).strip()
    p_no, p_si = _num(row.get("BTTS_No")), _num(row.get("BTTS_Si"))

    # L'etichetta porta il pronostico del mercato che si sta guardando,
    # non sempre quello dell'1X2: nella vista Under/Over "1" non serve.
    if tipo == "ou" and uo_pron:
        nome = {"O": "Over", "U": "Under"}.get(uo_pron, uo_pron)
        testa = "  {}{}".format(nome, " {:g}".format(linea) if linea is not None else "")
        perc = p_ov if uo_pron == "O" else p_un
    elif tipo == "ggng" and gg_pron:
        testa = "  {}".format("Gol" if gg_pron == "Si" else "NoGol")
        perc = p_si if gg_pron == "Si" else p_no
    else:
        testa = "  {}".format(pron) if pron else ""
        perc = {"1": p1, "X": px, "2": p2}.get(pron)
    coda = "  {:.0f}%".format(perc) if perc is not None else ""
    label = "{} {} vs {}{}{}".format(ora, casa, ospite, testa, coda)

    righe = []
    lega = str(row.get("Lega", "")).strip()
    if lega:
        righe.append(lega)

    mostra_tutto = tipo == "tutti"
    if mostra_tutto or tipo == "1x2":
        if p1 is not None and px is not None and p2 is not None:
            righe.append("1X2:  1 {:.0f}%   X {:.0f}%   2 {:.0f}%".format(p1, px, p2))
    if mostra_tutto or tipo == "ou":
        if p_un is not None and p_ov is not None:
            et = "Under/Over {:g}".format(linea) if linea is not None else "Under/Over"
            righe.append("{}:  Under {:.0f}%   Over {:.0f}%".format(et, p_un, p_ov))
    if mostra_tutto or tipo == "ggng":
        if p_no is not None and p_si is not None:
            righe.append("Gol/NoGol:  Gol {:.0f}%   NoGol {:.0f}%".format(p_si, p_no))

    esatto = str(row.get("Pron_Esatto", "")).strip()
    media = _num(row.get("Media_Gol"))
    extra = []
    if esatto:
        extra.append("risultato esatto previsto {}".format(esatto))
    if media is not None:
        extra.append("media gol attesa {:g}".format(media))
    if extra and (mostra_tutto or tipo == "1x2"):
        righe.append("Il sito prevede: " + ", ".join(extra) + ".")

    # Il confronto de-viggato, dove AsianOdds ha la stessa partita. Solo
    # sull'1X2: per l'Under/Over servirebbe far combaciare anche la linea,
    # e AsianOdds pubblica la terna 1X2, non i totali.
    if pron and (mostra_tutto or tipo == "1x2"):
        p_mercato, margine = _prob_mercato(
            pron, _riga_mercato(mercato, _chiave_incontro(row)))
        prob_sito = {"1": p1, "X": px, "2": p2}.get(pron)
        if p_mercato is not None:
            testo = "Mercato senza margine: {:.0f}%".format(p_mercato * 100)
            if margine is not None:
                testo += "  (margine tolto: {:.1f}%)".format(margine)
            righe.append(testo)
            if prob_sito is not None:
                righe.append("Scarto vero sito-mercato: {} punti".format(
                    _punti(prob_sito - p_mercato * 100)))
        else:
            _righe_stima(righe, pron, _chiave_incontro(row), stima, prob_sito)

    meteo = str(row.get("Meteo", "")).strip()
    if meteo and mostra_tutto:
        righe.append("Meteo previsto: {}".format(meteo))

    # Il risultato VERO, tenuto lontano dal risultato PREVISTO di sopra.
    ris = str(row.get("Risultato", "")).strip()
    if ris:
        esito = str(row.get("Esito", "")).strip()
        testo = "Finita {}".format(ris)
        if esito and pron:
            testo += " - esito {}, il sito aveva detto {}: {}".format(
                esito, pron, "preso" if esito == pron else "sbagliato")
        righe.append(testo)

    # Il campanello d'allarme dell'archivio. Se il sito ha cambiato le
    # probabilita' DOPO il calcio d'inizio, quelle qui sopra non sono
    # quelle che avresti visto prima della partita, e vanno guardate
    # sapendolo.
    if str(row.get("Prob_Cambiate", "")).strip() == "1":
        ult = [_num(row.get(c)) for c in ("P1_Ultimo", "PX_Ultimo", "P2_Ultimo")]
        testo = ("ATTENZIONE: il sito ha cambiato le probabilita' DOPO il "
                 "calcio d'inizio.")
        if all(v is not None for v in ult):
            testo += "  Adesso dice 1 {:.0f}%  X {:.0f}%  2 {:.0f}%.".format(*ult)
        testo += "  Qui sopra c'e' l'ultimo pronostico pre-partita."
        righe.append(testo)
    elif str(row.get("Vista_Pre_Match", "")).strip() == "0" and ris:
        righe.append("Partita vista solo a giocata finita: queste "
                     "percentuali non sono un pronostico verificabile.")

    ora_sito = str(row.get("Ora_Sito", "")).strip()
    if ora_sito and ora_sito != ora:
        righe.append("Orario sul sito: {} - qui convertito misurando il "
                     "fuso a ogni giro.".format(ora_sito))

    righe.append("")
    righe.append("Betimate e' informativa: non entra nel consensus.")
    return label, "\n".join(righe)


def _fm_campo(tipo):
    """Il campo che dice se la riga ha quel mercato, "" = nessun filtro."""
    for slug, _label, campo, _descr in FM_MERCATI:
        if slug == tipo:
            return campo
    return ""


def _fm_riga_mercato(righe, et, perc, quota, pron=None):
    """Una riga "Etichetta:  Nome xx%  (quota y.yy)" solo se i numeri ci sono."""
    if perc is None:
        return
    testo = "{}:  {:.0f}%".format(et, perc)
    if quota is not None:
        testo += "   quota {:.2f}".format(quota)
        # La probabilita' implicita accanto alla percentuale dichiarata: e'
        # il confronto che dice se il sito sta dicendo qualcosa di diverso
        # dal prezzo, o se lo sta solo ripetendo.
        if quota > 1:
            testo += "   (il prezzo implica {:.0f}%)".format(100.0 / quota)
    if pron:
        testo += "   {}".format(pron)
    righe.append(testo)


def row_footymetrics(row, mercato=None, stima=None):
    """Riga della sezione FootyMetrics.

    RUOLO: informativa, NON vota. Entra come ci entrarono Ratingbet e
    Betimate: prima si guarda, poi si misura quanto e' correlata con le
    fonti che gia' votano, e solo allora si decide.

    PERCHE' VALE LA PENA GUARDARLA. Misurato su una giornata vera, 188
    partite: lo scarto fra la percentuale del sito e il de-vig delle sue
    stesse quote ha mediana 6,1 punti e novantesimo percentile 13,4. Non
    e' il mercato riscritto - al contrario di Ratingbet, che alla prova
    risulto' esserlo - quindi dice qualcosa di suo. Resta da capire se
    dice qualcosa di GIUSTO, e per questo serve l'archivio.

    PERCHE' E' UNA SEZIONE PROFONDA E NON LARGA. Delle 188 partite di
    quella giornata, 171 le avevamo gia' da altre fonti: il calendario non
    si allarga. Quello che aggiunge sono MERCATI sulle stesse partite -
    Over/Under 1.5, primo marcatore, i corner su quattro linee e le medie
    dell'arbitro, che nessun'altra fonte pubblica.

    IL BEST AI TIP NON E' UN PRONOSTICO 1X2. Su 182 consigli di quella
    giornata, 144 erano Over/Under gol e 35 doppia chance: uno solo era un
    1X2. E la probabilita' dichiarata non scende mai sotto il 68%, mediana
    74. Il sito non consiglia la partita: sceglie, partita per partita, il
    mercato su cui puo' scrivere un numero alto. L'etichetta lo dice, cosi'
    nessuno lo legge come "secondo FootyMetrics vince la casa".

    UNA RIGA PORTA TUTTI I MERCATI, come Betimate e al contrario di
    SoccerSite: il parametro 'tipo' non toglie partite, sceglie quali
    numeri scrivere.

    Solo caratteri ASCII: le frecce unicode dipendono dal font dello skin.
    """
    casa = str(row.get("Casa", ""))
    ospite = str(row.get("Ospite", ""))
    ora = str(row.get("Ora", ""))
    tipo = str(row.get("_tipo", "") or "tutti")

    p1, px, p2 = _num(row.get("P1")), _num(row.get("PX")), _num(row.get("P2"))
    q1, qx, q2 = _num(row.get("Q1")), _num(row.get("QX")), _num(row.get("Q2"))
    p_o15, p_u15 = _num(row.get("P_O15")), _num(row.get("P_U15"))
    p_o25, p_u25 = _num(row.get("P_O25")), _num(row.get("P_U25"))
    p_gg, p_ng = _num(row.get("P_GG")), _num(row.get("P_NG"))

    # Il segno che il MODELLO preferisce, che non e' il Best AI Tip: quello
    # sta quasi sempre su un altro mercato.
    terna = {"1": p1, "X": px, "2": p2}
    pron = None
    if all(v is not None for v in (p1, px, p2)):
        pron = max(terna, key=lambda k: terna[k])

    best = str(row.get("Best_Scelta", "")).strip()
    best_p = _num(row.get("Best_Prob"))
    best_q = _num(row.get("Best_Quota"))
    best_es = str(row.get("Best_Esito", "")).strip()

    # ---- etichetta: il numero del mercato che si sta guardando
    if tipo == "ou15" and p_o15 is not None:
        testa = "  Over 1.5" if p_o15 >= (p_u15 or 0) else "  Under 1.5"
        perc = max(p_o15, p_u15 or 0)
    elif tipo == "ou25" and p_o25 is not None:
        testa = "  Over 2.5" if p_o25 >= (p_u25 or 0) else "  Under 2.5"
        perc = max(p_o25, p_u25 or 0)
    elif tipo == "ggng" and p_gg is not None:
        testa = "  Gol" if p_gg >= (p_ng or 0) else "  NoGol"
        perc = max(p_gg, p_ng or 0)
    elif tipo == "primo" and _num(row.get("P_Primo_Casa")) is not None:
        pc = _num(row.get("P_Primo_Casa"))
        pn = _num(row.get("P_Nessun_Gol")) or 0
        po = _num(row.get("P_Primo_Ospite")) or 0
        quale = max((pc, "casa"), (pn, "nessuno"), (po, "ospite"))
        testa = {"casa": "  Primo gol casa", "nessuno": "  Nessun gol",
                 "ospite": "  Primo gol ospite"}[quale[1]]
        perc = quale[0]
    elif tipo == "best" and best:
        testa = "  {}".format(best)
        perc = best_p
    else:
        testa = "  {}".format(pron) if pron else ""
        perc = terna.get(pron) if pron else None
    coda = "  {:.0f}%".format(perc) if perc is not None else ""
    label = "{} {} vs {}{}{}".format(ora, casa, ospite, testa, coda)

    righe = []
    paese = str(row.get("Paese", "")).strip()
    lega = str(row.get("Lega", "")).strip()
    intestazione = " - ".join(x for x in (paese, lega) if x)
    if intestazione:
        righe.append(intestazione)

    pos_c, pos_o = row.get("Pos_Casa"), row.get("Pos_Ospite")
    forma_c = str(row.get("Forma_Casa", "") or "").strip()
    forma_o = str(row.get("Forma_Ospite", "") or "").strip()
    if pos_c or pos_o or forma_c or forma_o:
        pezzi = []
        if pos_c and pos_o:
            pezzi.append("in classifica {} contro {}".format(pos_c, pos_o))
        if forma_c and forma_o:
            pezzi.append("ultime cinque {} contro {}".format(forma_c, forma_o))
        if pezzi:
            righe.append("; ".join(pezzi).capitalize())

    tutto = tipo == "tutti"

    if tutto or tipo == "1x2":
        if all(v is not None for v in (p1, px, p2)):
            righe.append("1X2 secondo il modello:  1 {:.0f}%   X {:.0f}%   "
                         "2 {:.0f}%".format(p1, px, p2))
        if all(v is not None for v in (q1, qx, q2)):
            righe.append("Quote sul sito:  1 {:.2f}   X {:.2f}   "
                         "2 {:.2f}".format(q1, qx, q2))
        d1 = _num(row.get("Devig1"))
        dx = _num(row.get("DevigX"))
        d2 = _num(row.get("Devig2"))
        ovr = _num(row.get("Overround"))
        if all(v is not None for v in (d1, dx, d2)):
            testo = ("Le sue quote senza margine:  1 {:.0f}%   X {:.0f}%   "
                     "2 {:.0f}%".format(d1, dx, d2))
            if ovr is not None:
                testo += "   (margine {:.1f}%)".format(ovr - 100)
            righe.append(testo)
            # Il confronto che dice se il modello e' una voce a se'.
            if pron and terna.get(pron) is not None:
                suo = {"1": d1, "X": dx, "2": d2}[pron]
                righe.append("Sul {}: il modello dice {:.0f}%, le sue stesse "
                             "quote {:.0f}%, scarto {} punti.".format(
                                 pron, terna[pron], suo,
                                 _punti(terna[pron] - suo)))

    if tutto or tipo == "ou15":
        _fm_riga_mercato(righe, "Over 1.5", p_o15, _num(row.get("Q_O15")))
        _fm_riga_mercato(righe, "Under 1.5", p_u15, _num(row.get("Q_U15")))
    if tutto or tipo == "ou25":
        _fm_riga_mercato(righe, "Over 2.5", p_o25, _num(row.get("Q_O25")))
        _fm_riga_mercato(righe, "Under 2.5", p_u25, _num(row.get("Q_U25")))
    if tutto or tipo == "ggng":
        _fm_riga_mercato(righe, "Gol", p_gg, _num(row.get("Q_GG")))
        _fm_riga_mercato(righe, "NoGol", p_ng, _num(row.get("Q_NG")))
    if tutto or tipo == "primo":
        _fm_riga_mercato(righe, "Primo gol casa", _num(row.get("P_Primo_Casa")),
                         _num(row.get("Q_Primo_Casa")))
        _fm_riga_mercato(righe, "Nessun gol", _num(row.get("P_Nessun_Gol")),
                         _num(row.get("Q_Nessun_Gol")))
        _fm_riga_mercato(righe, "Primo gol ospite", _num(row.get("P_Primo_Ospite")),
                         _num(row.get("Q_Primo_Ospite")))

    # I CORNER NON HANNO UN SOTTOMENU, stanno qui dentro. Sono l'unico dato
    # che nessun'altra fonte pubblica, ma restano un mercato di contorno:
    # un sottomenu suo farebbe pensare che siano il motivo della sezione.
    # Quattro linee su una riga sola, compatte.
    if tutto:
        corner = []
        for linea, cod in (("7.5", "O75C"), ("8.5", "O85C"),
                           ("9.5", "O95C"), ("10.5", "O105C")):
            pc = _num(row.get("P_" + cod))
            if pc is not None:
                corner.append("over {} {:.0f}%".format(linea, pc))
        if corner:
            righe.append("Corner totali:  " + "   ".join(corner))

    # ---- il consiglio del sito, con l'avvertenza che serve
    if best and (tutto or tipo == "best"):
        testo = "Best AI Tip: {}".format(best)
        if best_p is not None:
            testo += ", dato al {:.0f}%".format(best_p)
        if best_q is not None:
            testo += ", quota {:.2f}".format(best_q)
            if best_q > 1 and best_p is not None:
                testo += " (il prezzo implica {:.0f}%)".format(100.0 / best_q)
        righe.append(testo)
        mer = str(row.get("Best_Mercato", "")).strip()
        if mer and mer not in ("1x2",):
            righe.append("Il consiglio NON e' un 1X2: il sito sceglie partita "
                         "per partita il mercato su cui puo' dare un numero "
                         "alto, e quasi sempre sceglie i gol.")

    # ---- confronto col mercato vero, dove AsianOdds ha la stessa partita
    if pron and (tutto or tipo == "1x2"):
        p_mercato, margine = _prob_mercato(
            pron, _riga_mercato(mercato, _chiave_incontro(row)))
        prob_sito = terna.get(pron)
        if p_mercato is not None:
            testo = "Mercato senza margine: {:.0f}%".format(p_mercato * 100)
            if margine is not None:
                testo += "  (margine tolto: {:.1f}%)".format(margine)
            righe.append(testo)
            if prob_sito is not None:
                righe.append("Scarto vero sito-mercato: {} punti".format(
                    _punti(prob_sito - p_mercato * 100)))
        else:
            _righe_stima(righe, pron, _chiave_incontro(row), stima, prob_sito)

    # ---- l'arbitro, che nessun'altra fonte da'
    arb = str(row.get("Arbitro", "")).strip()
    if arb and tutto:
        gi, fa = _num(row.get("Arb_Gialli")), _num(row.get("Arb_Falli"))
        testo = "Arbitro: {}".format(arb)
        if gi is not None:
            testo += ", {:.2f} gialli".format(gi)
        if fa is not None:
            testo += " e {:.1f} falli di media".format(fa)
        righe.append(testo + ".")

    # ---- il risultato, se la partita e' finita
    stato = str(row.get("Stato", "")).strip()
    gc, go = row.get("Gol_Casa"), row.get("Gol_Ospite")
    segno = str(row.get("Segno", "")).strip()
    if stato == "FT" and gc is not None and go is not None:
        testo = "Finita {}-{}".format(gc, go)
        if segno and pron:
            testo += " - esito {}, il modello preferiva {}: {}".format(
                segno, pron, "preso" if segno == pron else "sbagliato")
        righe.append(testo)
        if best_es:
            righe.append("Il Best AI Tip e' risultato {}.".format(best_es.lower()))

    righe.append("")
    righe.append("FootyMetrics e' informativa: non entra nel consensus.")
    return label, "\n".join(righe)


def row_xgaura(row):
    """Riga della sezione xGaura.

    RUOLO: una fonte di tip fra le tante. Non entra nel consensus e non
    vota: sta qui come sezione a se', da guardare.

    LE QUOTE VANNO LETTE PER QUELLO CHE SONO. Il sito le dichiara "best
    available across major bookmakers", cioe' il meglio pescato fra piu'
    operatori: la somma delle tre probabilita' implicite puo' venire sotto
    il 100%, che per un singolo bookmaker sarebbe impossibile. Sono utili
    per sapere quanto paga il tip, NON sono un mercato coerente da cui
    ricavare probabilita'. Per questo l'etichetta dice "migliore".

    Solo caratteri ASCII: le frecce unicode dipendono dal font dello skin.
    """
    casa = str(row.get("Casa", ""))
    ospite = str(row.get("Ospite", ""))
    ora = str(row.get("Ora", ""))
    tip = str(row.get("Tip", "")).strip()
    conf = _num(row.get("Conf"))

    # In etichetta il tip e la QUOTA, non la confidenza: la quota e' il
    # numero che il sito non si e' inventato, ed e' quello che distingue
    # davvero due tip fra loro.
    # La quota del tip: sulla pagina di domani il sito la pubblica in una
    # colonna sua, su quella di oggi no - li' ci sono le tre colonne 1/X/2
    # e la quota del tip e' quella che corrisponde al segno scelto. Senza
    # questo recupero meta' delle righe resterebbe senza prezzo, che e'
    # proprio il numero su cui si vuole ragionare.
    q_tip = _num(row.get("Q tip"))
    if q_tip is None and str(row.get("Mercato", "")) == "1X2":
        q_tip = _num({"1": row.get("Q1"),
                      "X": row.get("QX"),
                      "2": row.get("Q2")}.get(str(row.get("Sel", "")).upper()))
    testa = "  {}".format(tip) if tip else ""
    coda = "  @ {:.2f}".format(q_tip) if q_tip is not None else ""
    label = "{} {} vs {}{}{}".format(ora, casa, ospite, testa, coda)

    paese = str(row.get("Paese", "")).strip()
    lega = str(row.get("Lega", "")).strip()
    dove = " - ".join(x for x in (paese, lega) if x)
    righe = [dove] if dove else []

    mercato = str(row.get("Mercato", "")).strip()
    sel = str(row.get("Sel", "")).strip()
    linea = _num(row.get("Linea"))
    if mercato:
        testo = "Mercato: {}".format(mercato)
        if sel:
            testo += "  {}".format(sel)
        if linea is not None:
            testo += " {:.1f}".format(linea)
        righe.append(testo)

    # Il confronto che conta: quanta probabilita' implica il prezzo, e
    # quanta ne dichiara il sito. Sono due numeri di natura diversa - uno
    # esce dal mercato, l'altro dal sito - e messi vicini si vede subito
    # quando il sito sta dicendo qualcosa che il prezzo non dice.
    implicita = _prob_implicita(q_tip)
    if q_tip is not None:
        testo = "Quota migliore: {:.2f}".format(q_tip)
        if implicita is not None:
            testo += "  ->  implica il {:.0f}%".format(implicita * 100)
        righe.append(testo)
    if conf is not None:
        testo = "Il sito dichiara {:.0f}%".format(conf * 100)
        if implicita is not None:
            scarto = (conf - implicita) * 100
            testo += "  ({:+.0f} punti rispetto al prezzo)".format(scarto)
        righe.append(testo)

    # La terna 1X2 c'e' solo sulla pagina di oggi: domani il sito pubblica
    # la sola quota del tip. Si mostra quello che c'e'.
    q1, qx, q2 = _num(row.get("Q1")), _num(row.get("QX")), _num(row.get("Q2"))
    if q1 is not None and qx is not None and q2 is not None:
        righe.append("Quote migliori 1X2: {:.2f} / {:.2f} / {:.2f}".format(
            q1, qx, q2))

    righe.append("Quota migliore fra piu' bookmaker, non di uno solo: la "
                 "percentuale implicita e' quindi una stima per difetto. La "
                 "confidenza la dichiara il sito e non e' verificabile.")

    return label, "\n".join(righe)


def row_fpnet(row):
    """Riga della sezione FootballPredictions.

    RUOLO: una fonte di pronostici fra le tante, con accanto la quota
    migliore che il sito ha trovato per quel mercato. Non entra nel
    consensus e non vota: sta qui come sezione a se', da guardare, esattamente
    come AsianOdds.

    Quattro mercati sulla stessa riga (1X2, Under/Over 2.5, Gol/NoGol e il
    Sure Bet) perche' il sito li da' tutti insieme nella pagina di
    dettaglio: separarli in quattro sezioni vorrebbe dire quattro liste
    quasi identiche da scorrere col telecomando.

    ATTENZIONE - queste righe non portano il campionato, perche' il sito
    nella lista non lo scrive, e senza campionato la tabella delle omonimie
    non ha indizi. Conseguenza pratica, verificata: i nomi contesi senza un
    predefinito (Leon, Barcelona, Rangers, Tigres) restano SENZA stemma,
    mentre quelli con un predefinito prendono quello - 'Inter' l'Inter,
    'Zamora' lo Zamora CF. E' il comportamento voluto: meglio nessuno
    stemma che quello dell'altro club.

    Solo caratteri ASCII: le frecce unicode dipendono dal font dello skin.
    """
    casa = str(row.get("Casa", ""))
    ospite = str(row.get("Ospite", ""))
    ora = str(row.get("Ora", ""))

    # L'asterisco marca le Sure Bets, cosi' si riconoscono scorrendo la
    # lista senza entrare nel dettaglio.
    sure = "  *" if row.get("SureBet") else ""

    # In etichetta solo il pronostico 1X2, che e' quello che si cerca
    # scorrendo; il resto sta nel riquadro dei dettagli.
    p1x2 = str(row.get("1X2", "")).strip() or str(row.get("Lista", "")).strip()
    testa = "  {}".format(p1x2) if p1x2 else ""
    label = "{} {} vs {}{}{}".format(ora, casa, ospite, testa, sure)

    righe = []

    # Il pronostico che il sito mette gia' nella pagina-lista, senza quota.
    # Vale poco accanto ai quattro mercati veri, ma quando la pagina di
    # dettaglio non si lascia leggere e' l'unica cosa che resta - meglio di
    # una riga che dice solo "nessun mercato".
    lista = str(row.get("Lista", "")).strip()
    if lista:
        righe.append("Dalla lista: {}".format(lista))

    for etichetta, kp, kq, kb in (("1X2", "1X2", "Q 1X2", "Book 1X2"),
                                  ("U/O 2.5", "OU", "Q OU", "Book OU"),
                                  ("Gol/NoGol", "BTTS", "Q BTTS", "Book BTTS"),
                                  ("Sure Bet", "Sure", "Q Sure", "Book Sure")):
        pred = str(row.get(kp, "")).strip()
        if not pred:
            continue
        testo = "{}: {}".format(etichetta, pred)
        quota = _num(row.get(kq))
        if quota is not None:
            testo += "  @ {:.2f}".format(quota)
            book = str(row.get(kb, "")).strip()
            if book:
                testo += " ({})".format(book)
        righe.append(testo)

    if not righe:
        righe.append("Nessun mercato: la pagina di dettaglio non e' stata "
                     "letta.")

    return label, "\n".join(righe)


def row_asianodds(row):
    """Riga della sezione AsianOdds.

    RUOLO: informazione, non pronostico. Le quote sono 1xBet, un soft book
    con margine medio intorno all'8-9%, e le probabilita' mostrate sono il
    de-vig proporzionale di quelle stesse quote: non sono una fonte in piu'
    accanto a Statarea e WebPronostici, sono il mercato riscritto in
    percentuale. Per questo AsianOdds non entra nel consensus e qui non
    compare nessun simbolo di pronostico.

    Il dato con valore proprio e' 'Mov': di quanti PUNTI di probabilita' si
    e' spostato il mercato dall'apertura. In punti e non in percentuale di
    quota perche' la percentuale non e' confrontabile fra partite - un +50%
    su una quota da 12.00 vale meno di un punto, un -10% su un 1.50 ne vale
    cinque.

    Solo caratteri ASCII: le frecce unicode dipendono dal font dello skin.
    """
    casa = str(row.get("Casa", ""))
    ospite = str(row.get("Ospite", ""))
    ora = str(row.get("Ora", ""))
    lega = str(row.get("Lega", ""))

    p1, px, p2 = _num(row.get("P1")), _num(row.get("PX")), _num(row.get("P2"))
    mov = _num(row.get("Mov"))
    margine = _num(row.get("Margine"))

    perc = ""
    if p1 is not None and px is not None and p2 is not None:
        perc = "  1:{:.0f} X:{:.0f} 2:{:.0f}".format(p1, px, p2)

    # Il movimento in etichetta solo quando e' significativo: su centinaia
    # di righe un "mov 0.3" ripetuto e' rumore che allunga la lista. Il
    # criterio e' lo stesso del filtro, altrimenti in "Tutte" si vedrebbero
    # partite marcate che poi in "Movimenti" non compaiono.
    mov_txt = ""
    if mov is not None and _e_notevole(row):
        mov_txt = "  [mov {:.1f}]".format(mov)

    # Un marcatore per le affidabili, cosi' si riconoscono anche scorrendo
    # "Tutte" senza entrare nel dettaglio.
    aff_txt = "  *" if _e_affidabile(row) else ""
    label = "{} {} vs {}{}{}{}".format(ora, casa, ospite, perc, mov_txt, aff_txt)

    righe = [lega] if lega else []

    # Quote: apertura -> corrente, con il drift accanto.
    for esito, ka, kq, kd in (("1", "Q1 Apre", "Q1", "Drift 1"),
                              ("X", "QX Apre", "QX", "Drift X"),
                              ("2", "Q2 Apre", "Q2", "Drift 2")):
        qa, qc, dr = _num(row.get(ka)), _num(row.get(kq)), _num(row.get(kd))
        if qc is None:
            continue
        testo = "{}: {:.2f}".format(esito, qc)
        if qa is not None and qa != qc:
            testo = "{}: {:.2f} -> {:.2f}".format(esito, qa, qc)
        if dr is not None:
            testo += "  ({:+.1f}%)".format(dr)
        righe.append(testo)

    # Due metodi di de-vig. Il proporzionale toglie il margine in parti
    # uguali; Shin ne carica di piu' sugli esiti lunghi, come fanno i
    # bookmaker davvero, ed e' il metodo che il Sistema usa come default.
    #
    # La seconda riga compare SOLO quando i due divergono di almeno un
    # punto: su gran parte delle partite coincidono (sotto 0.6 punti quando
    # non c'e' un outsider lungo) e due righe identiche sarebbero rumore.
    # Dove divergono, invece, la differenza e' il dato: significa che c'e'
    # un favorito netto e un outsider lungo, e che la percentuale
    # proporzionale dell'outsider e' gonfiata.
    s1, sx, s2 = (_num(row.get("P1 Shin")), _num(row.get("PX Shin")),
                  _num(row.get("P2 Shin")))
    if p1 is not None:
        riga = "Prob. de-vig:  1 {:.1f}%  X {:.1f}%  2 {:.1f}%".format(p1, px, p2)
        if margine is not None:
            riga += "   margine {:.1f}%".format(margine)
        righe.append(riga)
        if s1 is not None:
            scarto = max(abs(s1 - p1), abs(sx - px), abs(s2 - p2))
            if scarto >= 1.0:
                righe.append("  con Shin:    1 {:.1f}%  X {:.1f}%  2 {:.1f}%"
                             "   (scarto {:.1f} pt)".format(s1, sx, s2, scarto))
    elif s1 is not None:
        righe.append("Prob. Shin:  1 {:.1f}%  X {:.1f}%  2 {:.1f}%".format(s1, sx, s2))

    if mov is not None:
        righe.append("Movimento dall'apertura: {:.1f} punti".format(mov))

    # Linee AH e O/U: informative anche da sole, e non dipendono dalla
    # mappatura h/a delle quote over/under, che nella fonte non e'
    # confermata - per questo le quote O/U non si mostrano affatto.
    parti = []
    for etichetta, ka, kc, fmt in (("AH", "AH Apre", "AH", "{:+.2f}"),
                                   ("O/U", "OU Apre", "OU", "{:.2f}")):
        a, c = _num(row.get(ka)), _num(row.get(kc))
        if c is None:
            continue
        if a is not None and a != c:
            parti.append("{} {} -> {}".format(etichetta, fmt.format(a), fmt.format(c)))
        else:
            parti.append("{} {}".format(etichetta, fmt.format(c)))
    if parti:
        righe.append("   ".join(parti))

    ec, eo = _num(row.get("Elo Casa")), _num(row.get("Elo Osp"))
    if ec is not None and eo is not None:
        righe.append("Elo: {:.0f} - {:.0f}  (diff {:+.0f})".format(ec, eo, ec - eo))

    righe.append("")
    righe.append("Quote 1xBet, solo informative: non entrano nel pronostico.")
    return label, "\n".join(righe)


def row_consensus_medio(row):
    """
    RUOLO: una LETTURA, non un pronostico. La media delle probabilita' di
    tutte le fonti che si esprimono su quella partita - una, due o cinque.

    PERCHE' ESISTE ACCANTO AL CONSENSUS. Quello per accordo tiene una
    partita solo se due fonti dicono lo stesso segno: misurato il 13
    ottobre, su 7.604 partite finite con almeno un pronostico il 92% ne
    aveva UNA SOLA. Il consensus per accordo esiste su una frazione del
    calendario, e le partite che tiene sono quelle facili (51.9% di
    azzeccate contro il 58.2% del favorito del book, sulle stesse partite).
    La media invece copre tutto.

    PERCHE' NON E' UN SEGNALE. Sulle 230 partite finite dove c'era anche la
    linea di chiusura: Brier 0.6004 la media, 0.5755 il mercato,
    differenza +0.0249 con errore standard 0.0092, t = +2.71. Il mercato
    vince, e il margine e' fuori dal rumore. Quindi la riga non mette in
    cima la probabilita' della media: mette lo SCARTO dal mercato, che e'
    l'unica cosa che la media aggiunge - dove i siti pensano diversamente
    dal book, e di quanto.

    QUANTE FONTI, scritto sempre. Una media fatta da una fonte sola non e'
    una media: e' quella fonte. Senza il conteggio, le due cose sembrano
    uguali.
    """
    casa = str(row.get("Casa", ""))
    ospite = str(row.get("Ospite", ""))
    ora = str(row.get("Ora", ""))
    lega = str(row.get("Lega", ""))
    segno = str(row.get("Segno", "")).upper()
    elenco = str(row.get("Elenco", ""))
    try:
        fonti = int(row.get("Fonti") or 0)
    except Exception:
        fonti = 0
    p1, px, p2 = (_num(row.get("P1")), _num(row.get("PX")), _num(row.get("P2")))
    m1, mx, m2 = (_num(row.get("MP1")), _num(row.get("MPX")), _num(row.get("MP2")))
    scarto = _num(row.get("Scarto"))
    segno_m = str(row.get("Segno_Mercato", "")).upper()

    def f(v):
        return "-" if v is None else "{:.0f}".format(v)

    # SEMPRE LA PROBABILITA' DEL SEGNO, E DOVE C'E' ANCHE LO SCARTO.
    #
    # Fino alla 1.14.0 le due cose si escludevano: con il mercato si vedeva
    # solo "-7 vs mercato", senza si vedeva solo "68%". Ma i due numeri
    # dicono cose diverse e non sostituibili - 68% e' quanto ci credono le
    # fonti, -7 e' di quanto si discostano dal prezzo - e nella riga col
    # mercato spariva proprio quella che si legge per prima. Adesso ci
    # stanno tutte e due, la probabilita' davanti e lo scarto come
    # qualificatore: "68%  -7 vs mercato" si legge da solo, e il 75 del
    # mercato si ricava a mente.
    perc_segno = f(p1 if segno == "1" else px if segno == "X" else p2)
    coda = "  {}%".format(perc_segno)
    if scarto is not None:
        # Sotto il mezzo punto "+0 vs mercato" sembra un guasto e invece e'
        # il caso piu' informativo che ci sia: fonti e book d'accordo.
        coda += ("  in linea col mercato" if abs(scarto) < 0.5
                 else "  {:+.0f} vs mercato".format(scarto))
    label = "{} {} {} vs {}  [{} font{}]{}".format(
        PRON_ICONS.get(segno, "[?]"), ora, casa, ospite,
        fonti, "e" if fonti == 1 else "i", coda)

    righe = []
    if lega:
        righe.append(lega)
    righe.append("Media delle fonti:  1:{}%  X:{}%  2:{}%"
                 .format(f(p1), f(px), f(p2)))
    if fonti == 1:
        righe.append("Fonte unica: {}. Non e' una media, e' quella fonte."
                     .format(elenco))
    else:
        righe.append("Media di {} fonti: {}".format(fonti, elenco))

    if m1 is not None:
        righe.append("Mercato (Shin):     1:{}%  X:{}%  2:{}%"
                     .format(f(m1), f(mx), f(m2)))
        if segno_m and segno_m != segno:
            righe.append("Segni diversi: le fonti dicono {}, il mercato {}."
                         .format(segno, segno_m))
        if scarto is not None:
            verso = "piu'" if scarto >= 0 else "meno"
            righe.append("Sul {}: le fonti danno {:.1f} punti {} del mercato."
                         .format(segno, abs(scarto), verso))
            # La soglia e' quella che su FootyMetrics si e' vista contare:
            # sopra i 6 punti di scarto la fonte prendeva il 24.1% contro
            # il 36.2% del mercato. Non e' una regola generale provata su
            # questa media, ed e' scritto che non lo e'.
            if abs(scarto) >= 10:
                righe.append("Scarto grosso. Sulle fonti misurate finora, "
                             "quando si allontanano cosi' dal mercato hanno "
                             "torto piu' spesso, non meno.")
    # NIENTE RIGHE FISSE QUI SOTTO, e non e' un ammorbidimento.
    #
    # Fino alla 1.14.1 ogni partita chiudeva con due frasi sempre uguali:
    # l'avviso che la media perde contro il mercato, e - dove il prezzo
    # mancava - che AsianOdds copre solo 24 ore. Ripetute identiche su
    # 2.546 righe non informano, coprono: il dettaglio della partita
    # finiva sotto due frasi che il lettore smette di leggere alla terza
    # riga aperta.
    #
    # L'avvertenza resta dov'e' utile e si legge una volta: nella
    # descrizione della voce di menu ("Lettura, non pronostico: contro il
    # book perde") e in quelle dei tre filtri. E l'assenza del prezzo si
    # vede da sola - manca la riga "Mercato (Shin)" e manca lo scarto in
    # etichetta - senza bisogno di dichiararla.
    #
    # Quello che resta qui dentro e' solo roba che cambia da partita a
    # partita: i segni discordi e lo scarto, col suo avviso sopra i 10
    # punti.
    return label, "\n".join(righe)


def row_prezzo(row):
    """Una selezione col suo prezzo equo.

    IN ETICHETTA LA QUOTA EQUA, non la probabilita'. E' il numero che si
    confronta con quello che hai davanti su Sisal, e metterci la
    percentuale vorrebbe dire farla convertire a mente ogni volta. La
    probabilita' resta accanto, piu' piccola.

    L'ordine della lista e' per probabilita' e NON e' l'ordine di
    convenienza: il valore atteso e' identico su tutte le righe, perche'
    vengono tutte dallo stesso prezzo. Quello che cambia davvero fra una
    riga e l'altra e' il margine, cioe' quanto ti puoi fidare del numero.
    """
    ora = str(row.get("Ora", ""))
    part = str(row.get("Partita", ""))
    merc = str(row.get("Mercato", ""))
    sel = str(row.get("Sel", ""))
    prob = _num(row.get("Prob"))
    equa = _num(row.get("Equa"))
    marg = _num(row.get("Margine"))
    linea = row.get("Linea_OU")
    gol = _num(row.get("Gol_attesi"))
    mov = _num(row.get("Movimento"))
    camp = str(row.get("Campionato", ""))

    # LA LINEA DENTRO L'ETICHETTA. "Over" da solo non dice niente: la
    # stessa partita ha un Over 1.5 al 91% e un Over 2.5 al 76%, e dalla
    # lista non si capiva quale fosse quale. La linea c'era solo nel
    # dettaglio, e li' per giunta e' quella PRINCIPALE del book, che non
    # e' la linea della riga mostrata: su Freiburg - Bayern diceva 3.75
    # mentre la selezione era Over 1.5.
    etichetta_sel = sel
    if merc.startswith("OU ") and sel in ("Over", "Under"):
        etichetta_sel = "{} {}".format(sel, merc[3:])

    label = "{} {}  {}  @ {}  ({:.0f}%)".format(
        ora, part, etichetta_sel,
        "{:.2f}".format(equa) if equa is not None else "?",
        prob if prob is not None else 0)

    righe = []
    if camp:
        righe.append(camp)
    righe.append("Quota equa {}  -  probabilita' {:.0f}%".format(
        "{:.2f}".format(equa) if equa is not None else "?",
        prob if prob is not None else 0))
    righe.append("Sopra quella quota prendi valore, sotto paghi margine.")
    fonte = str(row.get("Fonte", ""))
    if fonte == "FootyMetrics":
        righe.append("Prezzo da FootyMetrics: AsianOdds copre solo le "
                     "prossime 24 ore. Sulle partite che hanno tutte e due, "
                     "le due fonti differiscono di 0.7 punti in mediana.")
    if marg is not None:
        if marg < 2.0:
            fid = "prezzo stretto, il numero regge"
        elif marg < 5.0:
            fid = "prezzo medio"
        else:
            fid = "prezzo largo, la probabilita' balla"
        righe.append("Margine del book: {:.1f}%  ({})".format(marg, fid))
    if linea not in (None, ""):
        righe.append("Linea principale del book {}  -  gol attesi {}".format(
            linea, "{:.2f}".format(gol) if gol is not None else "?"))
    if mov:
        righe.append("La quota si e' mossa di {:.1f} punti dall'apertura."
                     .format(mov))
    if merc.startswith("OU"):
        righe.append("Su 563 partite finite il modello ha sottostimato gli "
                     "Over di 4.6 punti: qui semmai il numero e' basso.")
    elif "1X" in sel or "X2" in sel:
        righe.append("Le doppie con la X sono le meno affidabili: Poisson "
                     "sottostima i pareggi, quindi la quota equa e' un po' "
                     "troppo generosa.")
    elif merc == "BTTS":
        righe.append("E' il mercato tarato meglio: fascia 55-65%, 238 "
                     "partite, previsto 60.0% e uscito 60.1%.")
    return label, "\n".join(righe)


def _pe_tiene(row, tipo):
    """Il filtro della vista. Torna True se la riga ci sta."""
    g = str(row.get("Gruppo", ""))
    if tipo == "schedina":
        return str(row.get("InSchedina", "")) == "si"
    if tipo == "stretto":
        m = _num(row.get("Margine"))
        return m is not None and m < 2.0
    if tipo == "combo":
        return g == "Combo"
    if tipo == "btts":
        return g == "Gol NoGol"
    if tipo == "ou":
        return g == "Under Over"
    if tipo == "1x2":
        return g == "1X2"
    return True


def row_poisson(row):
    """Una partita col Poisson calcolato dagli xG.

    QUESTA RIGA NON HA UNA QUOTA DA CONFRONTARE, e non e' una mancanza:
    non c'e' nessun prezzo dentro il calcolo. I due lambda vengono da
    quanto le due squadre creano e concedono, punto. Il mercato compare
    sotto, come termine di paragone, e la cosa interessante e' lo SCARTO
    - perche' questa e' l'unica stima del sistema che possa discostarsi
    dal book per un motivo suo.

    IN ETICHETTA I GOL ATTESI, non la probabilita' del segno: i lambda
    sono quello che il modello produce davvero, il resto ne discende.
    """
    ora = str(row.get("Ora", ""))
    casa = str(row.get("Casa", ""))
    osp = str(row.get("Ospite", ""))
    lega = str(row.get("Lega", ""))
    segno = str(row.get("Segno", "")).upper()
    lc, lo = _num(row.get("Lambda_Casa")), _num(row.get("Lambda_Osp"))
    gol = _num(row.get("Gol_Attesi"))
    p1, px, p2 = (_num(row.get("P1")), _num(row.get("PX")), _num(row.get("P2")))
    mgol = _num(row.get("M_Gol_Attesi"))
    m1, mx, m2 = (_num(row.get("M_P1")), _num(row.get("M_PX")),
                  _num(row.get("M_P2")))
    ds, dg = _num(row.get("Scarto_Segno")), _num(row.get("Scarto_Gol"))
    mpc, mpo = _num(row.get("MP_Casa")), _num(row.get("MP_Osp"))

    def f(v, d=0):
        if v is None:
            return "-"
        return "{:.{}f}".format(v, d)

    label = "{} {} {} vs {}  {} - {}  ({} gol)".format(
        PRON_ICONS.get(segno, "[?]"), ora, casa, osp,
        f(lc, 2), f(lo, 2), f(gol, 2))

    righe = []
    if lega:
        righe.append(lega)
    righe.append("Modello:   1:{}%  X:{}%  2:{}%".format(f(p1), f(px), f(p2)))
    righe.append("Lambda: casa {}  ospite {}   (gol attesi {})".format(
        f(lc, 2), f(lo, 2), f(gol, 2)))
    righe.append("xG/90: {} - {}      xGA/90: {} - {}".format(
        f(_num(row.get("xG_Casa")), 2), f(_num(row.get("xG_Osp")), 2),
        f(_num(row.get("xGA_Casa")), 2), f(_num(row.get("xGA_Osp")), 2)))
    o25, gg = _num(row.get("P_O25")), _num(row.get("P_GG"))
    if o25 is not None or gg is not None:
        righe.append("Over 2.5 {}%     Gol/NoGol {}%".format(f(o25), f(gg)))
    if m1 is not None:
        righe.append("Mercato:   1:{}%  X:{}%  2:{}%   (gol attesi {})".format(
            f(m1), f(mx), f(m2), f(mgol, 2)))
        if ds is not None:
            verso = "piu'" if ds >= 0 else "meno"
            righe.append("Sul {}: il modello da' {} punti {} del mercato."
                         .format(segno, f(abs(ds), 1), verso))
        if dg is not None:
            righe.append("Gol attesi: {} rispetto alla linea.".format(
                "{:+.2f}".format(dg)))
    else:
        righe.append("Nessun prezzo su questa partita: resta solo il modello.")
    # LE PARTITE GIOCATE SI SCRIVONO SEMPRE. Una media su sei giornate e
    # una su venti non valgono uguale, e chi guarda la riga deve poterlo
    # sapere senza aprire l'archivio.
    if mpc is not None and mpo is not None:
        righe.append("Medie calcolate su {} e {} partite giocate."
                     .format(f(mpc), f(mpo)))
    righe.append("Calcolato dagli xG, senza guardare le quote. Nessuna "
                 "delle fonti misurate finora batte il book: questo e' da "
                 "misurare, non da dare per buono.")
    return label, "\n".join(righe)


def show_matches(source, date, tipo=""):
    if source not in SORGENTI or not date:
        notify_error("Parametri non validi")
        xbmcplugin.endOfDirectory(HANDLE)
        return

    data = github_request(data_name(source, tipo, date))
    if not data:
        xbmcplugin.endOfDirectory(HANDLE)
        return

    if isinstance(data, dict):
        for key in ("matches", "data", "results", "rows"):
            if isinstance(data.get(key), list):
                data = data[key]
                break

    if not isinstance(data, list):
        notify_error("Dati con formato non valido")
        xbmcplugin.endOfDirectory(HANDLE)
        return

    # Una richiesta sola per elenco, non una per riga: si carica prima del
    # ciclo. Se il file non c'e' (AsianOdds copre le prossime 24 ore, le
    # date piu' avanti non le ha) resta un dizionario vuoto e le righe non
    # mostrano la riga di mercato.
    mercato = (carica_mercato(date)
               if source in ("sportytrader", "soccersite", "consensus",
                             "ratingbet", "betimate", "footymetrics")
               else None)
    # Il ripiego: una richiesta in piu' per elenco, e solo dove serve
    # davvero. Nella sezione Ratingbet non si carica - confrontare una
    # fonte con se stessa non dice niente.
    stima = (carica_stima(date)
             if source in ("sportytrader", "soccersite", "consensus",
                           "betimate", "footymetrics")
             else None)

    count = 0
    scartate_filtro = 0
    for row in data:
        if not isinstance(row, dict):
            continue
        if source == "statarea":
            label, plot = row_statarea(row)
        elif source == "webpronostici":
            label, plot = row_webpronostici(row)
        elif source == "asianodds":
            # Filtro "Movimenti": si applica qui e non a monte perche' il
            # file su gh-data e' uno solo. Una partita senza 'Mov' (quote di
            # apertura mancanti) resta fuori: non si sa se si e' mossa.
            if tipo == "mov" and not _e_notevole(row):
                scartate_filtro += 1
                continue
            if tipo == "aff" and not _e_affidabile(row):
                scartate_filtro += 1
                continue
            label, plot = row_asianodds(row)
        elif source == "fpnet":
            label, plot = row_fpnet(row)
        elif source == "sportytrader":
            tipi = _st_tipi(tipo)
            if tipi and str(row.get("Tipo", "")) not in tipi:
                scartate_filtro += 1
                continue
            label, plot = row_sportytrader(row, mercato, stima)
        elif source == "soccersite":
            # Il filtro per mercato si applica qui e non a monte perche'
            # il file su gh-data e' uno solo, con tutte le righe del
            # giorno: la stessa partita compare una volta per mercato.
            mercati = _ss_mercati(tipo)
            if mercati and str(row.get("Mercato", "")) not in mercati:
                scartate_filtro += 1
                continue
            label, plot = row_soccersite(row, mercato, stima)
        elif source == "ratingbet":
            # Il filtro per sezione si applica qui e non a monte perche'
            # il file su gh-data e' uno solo: la stessa partita compare
            # una volta per mercato, piu' una nelle matematiche.
            sezioni = _rb_sezioni(tipo)
            if sezioni and str(row.get("Sezione", "")) not in sezioni:
                scartate_filtro += 1
                continue
            label, plot = row_ratingbet(row, mercato)
        elif source == "betimate":
            # Qui il filtro NON divide la stessa partita in piu' righe,
            # come fa per SoccerSite e Ratingbet: Betimate mette tutti i
            # mercati su una riga sola. Si scartano solo le partite su cui
            # quel mercato il sito non l'ha pubblicato, perche' una riga
            # con l'etichetta e nessun numero e' peggio che assente.
            campo = _bt_campo(tipo)
            if campo and _num(row.get(campo)) is None:
                scartate_filtro += 1
                continue
            # Il tipo viaggia dentro la riga invece che come parametro in
            # piu': row_betimate deve sapere quali numeri scrivere, e la
            # firma resta quella delle altre row_*.
            row = dict(row)
            row["_tipo"] = tipo
            label, plot = row_betimate(row, mercato, stima)
        elif source == "footymetrics":
            # Stesso principio di Betimate: una riga porta tutti i
            # mercati, quindi il filtro non spacchetta le partite, scarta
            # solo quelle su cui il mercato non c'e'.
            campo = _fm_campo(tipo)
            if campo and _num(row.get(campo)) is None:
                scartate_filtro += 1
                continue
            row = dict(row)
            row["_tipo"] = tipo
            label, plot = row_footymetrics(row, mercato, stima)
        elif source == "xgaura":
            # Il filtro per fascia si applica qui e non a monte perche' il
            # file su gh-data e' uno solo, con tutti i tip del giorno.
            mercati = _xg_mercati(tipo)
            if mercati and str(row.get("Mercato", "")) not in mercati:
                scartate_filtro += 1
                continue
            label, plot = row_xgaura(row)
        elif source == "poisson":
            label, plot = row_poisson(row)
        elif source == "prezzi":
            if not _pe_tiene(row, tipo):
                scartate_filtro += 1
                continue
            label, plot = row_prezzo(row)
        elif source == "consensusmedio":
            # Il filtro si applica qui e non a monte: su gh-data il file
            # del giorno e' uno solo, con tutte le partite dentro.
            if tipo == "mercato" and _num(row.get("Scarto")) is None:
                scartate_filtro += 1
                continue
            if tipo == "multi":
                try:
                    quante = int(row.get("Fonti") or 0)
                except Exception:
                    quante = 0
                if quante < 2:
                    scartate_filtro += 1
                    continue
            # Niente carica_mercato qui: i numeri del mercato sono gia'
            # dentro la riga, calcolati da chi ha scritto il file. Il
            # confronto per nome fra archivi diversi e' il punto dove si
            # sbaglia, e si sbaglia meglio una volta a monte che in Kodi a
            # ogni apertura.
            label, plot = row_consensus_medio(row)
        else:
            label, plot = row_consensus(row, mercato, stima)

        add_item(label, plot, get_url(action="noop"), False,
                 casa=row.get("Casa"), ospite=row.get("Ospite"),
                 dove=_campi_riga(row))
        count += 1

    if count == 0:
        if scartate_filtro:
            # Distinzione che conta: i dati ci sono, e' il filtro che e'
            # severo. Senza questo messaggio sembrerebbe un guasto.
            if source == "sportytrader":
                notify_error(
                    "Nessun pronostico di questo tipo fra i {} del {}. "
                    "Prova 'Tutti'.".format(scartate_filtro, date))
            elif source == "soccersite":
                notify_error(
                    "Nessuna riga su questo mercato fra le {} del {}. "
                    "Prova 'Tutti i mercati'.".format(scartate_filtro, date))
            elif source == "ratingbet":
                notify_error(
                    "Nessuna riga in questa sezione fra le {} del {}. "
                    "Prova 'Tutte'.".format(scartate_filtro, date))
            elif source == "betimate":
                notify_error(
                    "Il sito non pubblica questo mercato su nessuna delle {} "
                    "partite del {}. Prova 'Tutto insieme'.".format(
                        scartate_filtro, date))
            elif source == "footymetrics":
                notify_error(
                    "Il sito non pubblica questo mercato su nessuna delle {} "
                    "partite del {}. Prova 'Tutto insieme'.".format(
                        scartate_filtro, date))
            elif source == "xgaura":
                notify_error(
                    "Nessun tip su questo mercato fra i {} del {}. "
                    "Prova 'Tutti i mercati'.".format(scartate_filtro, date))
            elif source == "prezzi" and tipo == "schedina":
                notify_error(
                    "Nessuna delle {} selezioni del {} e' in un campionato "
                    "dei concessionari italiani dentro la fascia "
                    "giocabile.".format(scartate_filtro, date))
            elif source == "prezzi" and tipo == "schedina":
                notify_error(
                    "Nessuna delle {} selezioni del {} e' finita in "
                    "schedina: campionato, margine o quota fuori "
                    "fascia.".format(scartate_filtro, date))
            elif source == "prezzi" and tipo == "stretto":
                notify_error(
                    "Nessuna delle {} selezioni del {} ha il margine sotto "
                    "il 2%. Prova un'altra vista.".format(
                        scartate_filtro, date))
            elif source == "prezzi":
                notify_error(
                    "Nessuna selezione di questo tipo fra le {} del {}. "
                    "Prova 'Tutto'.".format(scartate_filtro, date))
            elif source == "consensusmedio" and tipo == "mercato":
                notify_error(
                    "Nessuna delle {} partite del {} ha la linea di "
                    "chiusura: AsianOdds copre le prossime 24 ore.".format(
                        scartate_filtro, date))
            elif source == "consensusmedio":
                notify_error(
                    "Su tutte e {} le partite del {} si esprime una fonte "
                    "sola. Prova 'Tutte'.".format(scartate_filtro, date))
            elif tipo == "aff":
                notify_error(
                    "Nessuna partita a margine basso fra le {} del {}. "
                    "Prova 'Tutte'.".format(scartate_filtro, date))
            else:
                notify_error(
                    "Nessun movimento oltre {:.0f} punti fra le {} partite del "
                    "{}. Prova 'Tutte'.".format(AO_SOGLIA_MOV, scartate_filtro,
                                                date))
        else:
            notify_error("Nessuna partita trovata per {}".format(date))

    xbmcplugin.endOfDirectory(HANDLE)


# ------------------------------------------------- come vanno le fonti

# Quante partite servono prima di mostrare una percentuale. Sotto questa
# soglia si scrive il conteggio e si dice che e' presto: una fonte con tre
# partite e il 100% in cima alla lista e' peggio che non avere la lista.
MINIMO_MOSTRA = 30


def _classifica():
    """Il consuntivo scritto dal giro notturno, o None."""
    return github_request("classifica_fonti.json", silent_404=True)


def _classifica_consensus():
    """Il consuntivo dei due consensus, o None.

    File separato da classifica_fonti.json perche' lo scrivono script
    diversi: misura_fonti.py misura i TIP delle fonti, questo misura le
    PROBABILITA' dei due consensus. Tenerli insieme vorrebbe dire che un
    errore in uno lascia l'addon senza l'altro."""
    return github_request("classifica_consensus.json", silent_404=True)


def _verdetto(m):
    """Una riga sul confronto col mercato, dal segno e dalla t.

    LA t E' L'UNICA COSA CHE DECIDE, non la differenza. Un mercato che
    vince di 0.03 su quaranta partite non ha vinto niente: sotto 2 lo
    scarto sta dentro il rumore e va detto, altrimenti il numero piu'
    grosso si prende la ragione per il solo fatto di essere piu' grosso.
    """
    if not m or m.get("poche"):
        return "Troppe poche partite col prezzo di chiusura: e' presto."
    t = _num(m.get("t")) or 0.0
    n = m.get("partite", 0)
    if abs(t) < 2.0:
        return ("Dentro il rumore su {} partite (t {:+.1f}): non si puo' "
                "ancora dire chi vince.".format(n, t))
    if t > 0:
        return ("Il mercato vince, e lo scarto regge: {} partite, t {:+.1f}."
                .format(n, t))
    return ("Batte il mercato, e lo scarto regge: {} partite, t {:+.1f}. "
            "Da rifare fra un mese su partite nuove prima di crederci."
            .format(n, t))


def _righe_mercato(m):
    """Le righe di dettaglio del confronto col mercato."""
    if not m or m.get("poche"):
        return ["Partite col prezzo di chiusura: {}. Sotto le 50 non si "
                "misura.".format((m or {}).get("partite", 0))]
    r = ["Sulle stesse {} partite, Brier (piu' basso e' meglio):"
         .format(m.get("partite", 0)),
         "   queste probabilita'      {}".format(m.get("brier", "?")),
         "   mercato de-viggato       {}".format(m.get("brier_mercato", "?")),
         "Differenza partita per partita: {:+} con errore standard {}, "
         "t = {:+}".format(m.get("diff", 0), m.get("es", "?"), m.get("t", 0))]
    ic = m.get("ic") or []
    if len(ic) == 2:
        r.append("Intervallo al 95%: da {:+} a {:+}".format(ic[0], ic[1]))
    return r


def show_classifica_consensus(quale):
    """Il consuntivo di uno dei due consensus.

    PERCHE' I DUE STANNO SEPARATI E NON SI SOMMANO. Misurano cose
    diverse su campioni diversi: l'accordo conta i SEGNI su cui Statarea
    e WebPronostici concordano, la media confronta le PROBABILITA' di
    cinque fonti su tutto il calendario. Metterli in classifica insieme
    farebbe pensare che il piu' alto sia il migliore, quando non stanno
    nemmeno guardando le stesse partite.
    """
    d = _classifica_consensus() or {}
    b = d.get(quale)
    if not b:
        notify_error("Questo consuntivo non e' ancora stato pubblicato: "
                     "arriva col primo giro notturno")
        xbmcplugin.endOfDirectory(HANDLE)
        return

    titolo = ("Consensus medio" if quale == "medio"
              else "Consensus per accordo")
    add_item("{}  -  aggiornato il {}".format(titolo, d.get("aggiornato", "?")),
             "Misurato solo su partite gia' finite, con i valori congelati "
             "prima del calcio d'inizio.",
             get_url(action="classifica_consensus", source=quale), False)

    if quale == "medio":
        cop = b.get("copertura") or {}
        tot = b.get("totale", 0)
        pezzi = ["{} fonti: {}".format(k, cop[k]) for k in sorted(cop)]
        add_item("Copertura   {} partite".format(tot),
                 "Su quante fonti si regge la media:  " + "   ".join(pezzi) +
                 "\nDove la fonte e' una sola la media non e' una media: e' "
                 "quella fonte.",
                 get_url(action="noop"), False)
        add_item("Brier   {}   (dire sempre le frequenze medie: {})"
                 .format(b.get("brier", "?"), b.get("brier_clima", "?")),
                 "Il secondo numero e' il previsore stupido, quello che "
                 "ignora le squadre e dice sempre le percentuali medie del "
                 "campione. Serve come pavimento: sotto quello non si "
                 "sta prevedendo niente.",
                 get_url(action="noop"), False)
        for f in b.get("fonti", []):
            add_item("{}   Brier {}   su {} partite".format(
                         f.get("nome", "?"), f.get("brier", "?"),
                         f.get("partite", 0)),
                     "Sulle stesse partite dove questa fonte si esprime, la "
                     "media di tutte fa {}. Se il numero della fonte e' piu' "
                     "basso, mediarla con le altre la peggiora."
                     .format(f.get("brier_media", "?")),
                     get_url(action="noop"), False,
                     icona=icona_sito(f.get("nome", "")))
    else:
        for chiave, nome in (("statarea", "Statarea da sola"),
                             ("webpronostici", "WebPronostici da sola"),
                             ("consensus", "Consensus (le due d'accordo)")):
            v = (b.get("prende") or {}).get(chiave)
            if not v:
                continue
            add_item("{}   {}%   su {} pronostici".format(
                         nome, v.get("pct", "?"), v.get("su", 0)),
                     "Quante ne prende, contate solo dove un pronostico c'e'.",
                     get_url(action="noop"), False,
                     icona=icona_sito(chiave))
        tt = b.get("testa_a_testa")
        if tt:
            add_item("Testa a testa col mercato   consensus {}%   "
                     "mercato {}%".format(tt.get("consensus", "?"),
                                          tt.get("mercato", "?")),
                     "Sulle {} partite dove il consensus ha un pronostico E "
                     "c'e' il prezzo di chiusura. Il mercato qui e' il suo "
                     "favorito.".format(tt.get("partite", 0)),
                     get_url(action="noop"), False)

    m = b.get("mercato")
    add_item("Contro il mercato:  " + _verdetto(m),
             "\n".join(_righe_mercato(m)),
             get_url(action="noop"), False)
    xbmcplugin.endOfDirectory(HANDLE)


def show_classifica():
    """
    Le fonti in ordine di QUANTE PARTITE sono state misurate, non di quante
    ne prendono. La percentuale piu' alta la fa sempre chi ha il campione
    piu' piccolo, e metterla in cima sarebbe il modo piu' rapido per
    convincersi di una cosa falsa.
    """
    d = _classifica()
    if not d or not d.get("fonti"):
        notify_error("Il consuntivo non e' ancora stato pubblicato: "
                     "arriva col primo giro notturno")
        xbmcplugin.endOfDirectory(HANDLE)
        return

    add_item("Aggiornato il {}  -  {} partite con risultato"
             .format(d.get("aggiornato", "?"), d.get("risultati", 0)),
             "L'archivio cresce ogni notte. Finche' una fonte non arriva a "
             "qualche centinaio di partite i numeri ballano: si guardano, "
             "non si usano per decidere.",
             get_url(action="classifica"), False)

    # I DUE CONSENSUS PRIMA DELLE FONTI. Sotto ci sono le fonti misurate
    # sui loro tip - quante ne prendono - mentre qui si misurano le
    # PROBABILITA' contro il prezzo del book, che e' la domanda piu'
    # vicina al "serve a qualcosa". Stanno in cima per questo, non
    # perche' vadano meglio.
    dc = _classifica_consensus() or {}
    for quale, etichetta in (("medio", "[~] Consensus medio"),
                             ("accordo", "[*] Consensus per accordo")):
        b = dc.get(quale)
        if not b:
            continue
        add_item("{}   {}".format(etichetta, _verdetto(b.get("mercato"))),
                 "Misurato sulle probabilita' e non sui segni: il metro e' "
                 "il Brier score contro il mercato de-viggato, partita per "
                 "partita. Apri per il dettaglio.",
                 get_url(action="classifica_consensus", source=quale), True)

    for f in d["fonti"]:
        nome = f.get("nome", f.get("chiave", "?"))
        mis = f.get("misurate", 0)
        if mis >= MINIMO_MOSTRA:
            etichetta = "{}   {}%   su {} pronostici".format(
                nome, f.get("pct", "?"), mis)
            righe = ["{}  {}%  ({}/{})".format(m["mercato"], m["pct"],
                                               m["prese"], m["su"])
                     for m in f.get("mercati", []) if m["su"] >= MINIMO_MOSTRA]
            plot = "   ".join(righe) if righe else "Nessun mercato con abbastanza partite."
        elif mis:
            etichetta = "{}   solo {} pronostici finiti".format(nome, mis)
            plot = ("Troppo pochi per una percentuale che voglia dire "
                    "qualcosa. Torna fra qualche settimana.")
        else:
            etichetta = "{}   nessuna partita finita".format(nome)
            plot = ("L'archivio di questa fonte e' partito da poco: ci sono "
                    "i pronostici ma le partite non sono ancora state "
                    "giocate, oppure il risultato non e' stato agganciato.")
        rotte = f.get("rotte") or 0
        if rotte:
            plot += "   [{} righe scartate perche' il pronostico non " \
                    "corrispondeva al mercato dichiarato]".format(rotte)
        add_item(etichetta, plot,
                 get_url(action="classifica_fonte", source=f.get("chiave", "")),
                 True, icona=icona_sito(f.get("chiave", "")))

    xbmcplugin.endOfDirectory(HANDLE)


def show_classifica_fonte(chiave):
    """Il dettaglio per mercato di una fonte, piu' il confronto col book."""
    d = _classifica()
    scheda = None
    for f in (d or {}).get("fonti", []):
        if f.get("chiave") == chiave:
            scheda = f
            break
    if scheda is None:
        notify_error("Nessun dato per questa fonte")
        xbmcplugin.endOfDirectory(HANDLE)
        return

    nome = scheda.get("nome", chiave)
    if not scheda.get("mercati"):
        add_item("{}: ancora niente da misurare".format(nome),
                 "Archiviati {} pronostici, nessuno su una partita gia' "
                 "finita e agganciata a un risultato."
                 .format(scheda.get("righe", 0)),
                 get_url(action="classifica"), False)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    for m in scheda["mercati"]:
        su = m["su"]
        if su >= MINIMO_MOSTRA:
            eti = "{}   {}%   {}/{}".format(m["mercato"], m["pct"],
                                            m["prese"], su)
        else:
            eti = "{}   solo {} partite".format(m["mercato"], su)
        plot = ""
        if m.get("rimborsi"):
            plot = ("{} partite finite esattamente sulla linea: non contano "
                    "ne' come prese ne' come sbagliate.".format(m["rimborsi"]))
        add_item(eti, plot, get_url(action="classifica_fonte", source=chiave),
                 False, icona=icona_sito(chiave))

    # IL CONFRONTO CHE CONTA DAVVERO, quando c'e'. Prendere tante non vuol
    # dire guadagnare: il favorito del bookmaker ne prende altrettante, e
    # lui il prezzo se lo fa da solo.
    conf = scheda.get("mercato")
    if conf and conf.get("n", 0) < MINIMO_MOSTRA:
        # Stessa regola del resto della schermata: sotto la soglia si dice
        # quante sono e basta. Un confronto col book su venti partite e'
        # proprio quello che non bisogna guardare.
        add_item("Contro il mercato: solo {} partite con la quota"
                 .format(conf["n"]),
                 "L'archivio delle quote di chiusura e' partito da poco e "
                 "cresce solo con le partite viste il giorno prima. E' il "
                 "numero che conta di piu' e sara' l'ultimo ad arrivare.",
                 get_url(action="classifica_fonte", source=chiave), False)
    elif conf:
        add_item("Contro il mercato:  fonte {}%   favorito del book {}%"
                 .format(conf["fonte"], conf["book"]),
                 "Sulle {} partite 1X2 di cui l'archivio ha anche la quota "
                 "di chiusura. Se la fonte non sta sopra il favorito del "
                 "book, seguirla al prezzo del book non conviene, per quante "
                 "ne prenda.".format(conf["n"]),
                 get_url(action="classifica_fonte", source=chiave), False)

    add_item("Totale {}   {}%   su {} pronostici"
             .format(nome, scheda.get("pct", "?"), scheda.get("misurate", 0)),
             "Mercati diversi non si sommano volentieri: una doppia chance "
             "si prende molto piu' spesso di un 1X2 e paga molto meno. "
             "Guarda i mercati uno per uno.",
             get_url(action="classifica_fonte", source=chiave), False)
    xbmcplugin.endOfDirectory(HANDLE)


# ---------------------------------------------------------------- router

params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
action = params.get("action", "")

# Prima di qualunque richiesta: chi arriva dalla 1.3.x ha ancora repo privato
# e token nelle impostazioni, e userebbe quelli.
migra_da_privato()

if not action:
    main_menu()
elif action == "wp_tipi":
    show_wp_tipi()
elif action == "xg_mercati":
    show_xg_mercati()
elif action == "st_tipi":
    show_st_tipi()
elif action == "ss_mercati":
    show_ss_mercati()
elif action == "rb_sezioni":
    show_rb_sezioni()
elif action == "bt_mercati":
    show_bt_mercati()
elif action == "fm_mercati":
    show_fm_mercati()
elif action == "ao_filtri":
    show_ao_filtri()
elif action == "pe_filtri":
    show_pe_filtri()
elif action == "cm_filtri":
    show_cm_filtri()
elif action == "classifica":
    show_classifica()
elif action == "classifica_fonte":
    show_classifica_fonte(params.get("source", ""))
elif action == "classifica_consensus":
    show_classifica_consensus(params.get("source", ""))
elif action == "dates":
    show_dates(params.get("source", ""), params.get("tipo", ""))
elif action == "matches":
    show_matches(params.get("source", ""), params.get("date", ""),
                 params.get("tipo", ""))
else:
    xbmcplugin.endOfDirectory(HANDLE)

# -*- coding: utf-8 -*-
import os
import re
import sys
import json
import base64
import difflib
import urllib.request
import urllib.parse
import urllib.error

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]

ADDON_PATH = ADDON.getAddonInfo("path")
ICON = os.path.join(ADDON_PATH, "resources", "icon.png")

# NESSUN NOME DI REPOSITORY PRECOMPILATO, come per il token.
#
# Fino alla 1.2.49 qui c'era il nome del repository privato dei dati. In un
# pacchetto distribuito a mano non era un problema; in uno pubblico lo e':
# chiunque lo aprisse saprebbe che quel repository esiste. Non potrebbe
# entrarci (e' privato, senza token risponde 404), ma il nome si legge.
#
# Va scritto una volta in Impostazioni -> GitHub, insieme al token, e resta
# in userdata anche dopo gli aggiornamenti. Il branch invece non identifica
# nessuno, quindi il suo default resta.
DEFAULT_REPO = ""
DEFAULT_BRANCH = "gh-data"

# NESSUN TOKEN NEL PACCHETTO, e non e' una dimenticanza.
#
# Fino alla 1.2.49 qui c'era FALLBACK_TOKEN, un token scritto in chiaro per
# non doverne digitare 93 caratteri col telecomando. Andava bene finche' lo
# ZIP girava solo a mano. Da questa versione l'addon si aggiorna da solo da
# un repository PUBBLICO: un token qui dentro sarebbe leggibile da chiunque,
# e darebbe accesso in lettura al repo privato dei dati.
#
# Il token ora sta solo nelle impostazioni dell'addon, che vivono in
# userdata/addon_data/ e NON vengono toccate dagli aggiornamenti: si
# inserisce una volta e resta.
_TOKEN_CACHE = None

PRON_ICONS = {
    "1": "[1]", "X": "[X]", "2": "[2]",
    "1X": "[1X]", "X2": "[X2]", "12": "[12]",
    "GG": "[GG]", "NG": "[NG]",
    "OVER": "[OV]", "UNDER": "[UN]",
}

# Tipi WebPronostici: slug -> etichetta menu
WP_TIPI = [
    ("1x2",   "1X2"),
    ("misti", "Misti"),
    ("ou",    "Under / Over"),
    ("ggng",  "Gol / NoGol"),
]

# Sorgenti valide. AsianOdds ha il suo JSON (asianodds_<data>.json), quindi
# la sezione funziona anche nei giorni in cui il consensus e' vuoto: prima
# i dati AsianOdds si vedevano solo dentro le righe del consensus, cioe'
# solo per le partite che Statarea e WebPronostici avevano in comune.
SORGENTI = ("consensus", "statarea", "webpronostici", "asianodds")

# Filtri della sezione AsianOdds: slug -> (etichetta, descrizione)
AO_FILTRI = [
    ("aff",   "Affidabili",
     "Margine basso e i due de-vig concordi: le probabilita' piu' attendibili"),
    ("mov",   "Movimenti",
     "Solo le partite dove il mercato si e' mosso davvero"),
    ("tutte", "Tutte",
     "Tutte le partite delle prossime 24h"),
]

# Il filtro "Movimenti" NON si ricalcola qui: asianodds_ci.py scrive nel JSON
# un campo "Notevole" gia' deciso, e l'addon si limita a leggerlo. Cosi' la
# regola vive in un posto solo e non puo' divergere - in 1.3.2-1.3.4 la
# soglia era scritta in due file e, quando le misure sul primo file vero
# hanno mostrato che 4 punti erano troppo pochi, correggerne uno solo avrebbe
# fatto mostrare a Kodi partite diverse da quelle dell'Excel.
#
# La soglia qui sotto serve solo a due cose: mostrare l'etichetta [mov N] in
# elenco, e filtrare i JSON prodotti prima che il campo esistesse.
AO_SOGLIA_MOV = 8.0


def get_setting(name, default=""):
    try:
        value = ADDON.getSetting(name)
        return value.strip() if value else default
    except Exception:
        return default


def get_url(**kwargs):
    return "{}?{}".format(BASE_URL, urllib.parse.urlencode(kwargs))


def prompt_for_token():
    """Chiede il token e lo salva nelle impostazioni. Restituisce '' se annullato."""
    dlg = xbmcgui.Dialog()
    ok = dlg.yesno(
        "Pronostici",
        "Token GitHub non configurato.\n"
        "Il repository dei dati e' privato: senza token i pronostici "
        "non possono essere scaricati.\n\n"
        "Va inserito una volta sola: resta salvato anche dopo gli "
        "aggiornamenti dell'addon.\n\n"
        "Vuoi inserirlo adesso?",
        nolabel="Piu' tardi", yeslabel="Inserisci"
    )
    if not ok:
        return ""

    token = dlg.input("Incolla il token GitHub", type=xbmcgui.INPUT_ALPHANUM)
    token = (token or "").strip()
    if not token:
        return ""

    try:
        ADDON.setSetting("gh_token", token)
    except Exception as e:
        notify_error("Impossibile salvare il token: {}".format(e))
    return token


def get_github_token():
    global _TOKEN_CACHE
    if _TOKEN_CACHE is not None:
        return _TOKEN_CACHE
    # 1) impostazioni utente  2) richiesta a schermo
    token = get_setting("gh_token", "")
    if not token:
        token = prompt_for_token()
    _TOKEN_CACHE = token
    return token


_REPO_CACHE = None


def prompt_for_repo():
    """Chiede il repository dei dati e lo salva. '' se annullato."""
    dlg = xbmcgui.Dialog()
    ok = dlg.yesno(
        "Pronostici",
        "Repository dei dati non configurato.\n\n"
        "Va indicato nella forma utente/nome-repo, una volta sola: "
        "resta salvato anche dopo gli aggiornamenti dell'addon.\n\n"
        "Vuoi inserirlo adesso?",
        nolabel="Piu' tardi", yeslabel="Inserisci"
    )
    if not ok:
        return ""

    repo = dlg.input("utente/nome-repo", type=xbmcgui.INPUT_ALPHANUM)
    repo = (repo or "").strip()
    if not repo:
        return ""

    try:
        ADDON.setSetting("gh_repo", repo)
    except Exception as e:
        notify_error("Impossibile salvare il repository: {}".format(e))
    return repo


def get_repo():
    global _REPO_CACHE
    if _REPO_CACHE is not None:
        return _REPO_CACHE
    repo = get_setting("gh_repo", DEFAULT_REPO)
    if not repo:
        repo = prompt_for_repo()
    _REPO_CACHE = repo
    return repo


def get_branch():
    return get_setting("gh_branch", DEFAULT_BRANCH)


def notify_error(message):
    xbmcgui.Dialog().notification(
        "Pronostici", str(message)[:180],
        xbmcgui.NOTIFICATION_ERROR, 5000
    )


def github_request(path, silent_404=False):
    repo = get_repo()
    branch = get_branch()
    if "/" not in repo:
        notify_error("Repository GitHub non valido")
        return None

    url = "https://api.github.com/repos/{}/contents/{}?ref={}".format(
        repo, path.lstrip("/"), urllib.parse.quote(branch, safe="")
    )

    headers = {
        "User-Agent": "Kodi-21-Pronostici/1.3.9",
        "Accept": "application/vnd.github+json",
    }
    token = get_github_token()
    if token:
        headers["Authorization"] = "Bearer {}".format(token)

    try:
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=20) as response:
            payload = json.loads(response.read().decode("utf-8-sig"))

        if not isinstance(payload, dict) or "content" not in payload:
            if not silent_404:
                notify_error("GitHub: contenuto file non disponibile")
            return None

        raw = base64.b64decode(payload["content"]).decode("utf-8-sig")
        return json.loads(raw)

    except urllib.error.HTTPError as e:
        if e.code == 404:
            if not silent_404:
                notify_error(
                    "GitHub: file non trovato (404). "
                    "Controlla repository e branch nelle impostazioni."
                )
        elif e.code == 401:
            notify_error(
                "GitHub: token non valido o scaduto (401). "
                "Aggiornalo in Impostazioni GitHub."
            )
        elif e.code == 403:
            notify_error("GitHub: accesso negato o limite API (403)")
        else:
            notify_error("GitHub: errore HTTP {}".format(e.code))
    except urllib.error.URLError as e:
        notify_error("Connessione GitHub: {}".format(e.reason))
    except ValueError:
        notify_error("GitHub: JSON non valido")
    except Exception as e:
        notify_error("Errore GitHub: {}".format(e))

    return None


# ---------------------------------------------------------------- loghi

# I loghi vivono in un addon separato, resource.images.pronostici: 877 PNG
# per 16 MB che cambiano raramente, mentre questo file cambia spesso. Tenerli
# qui dentro voleva dire riscaricare 16 MB per ogni correzione al codice.
ID_RISORSA_LOGHI = "resource.images.pronostici"

_MAPPA_LOGHI = None
_CACHE_LOGHI = {}
_BASE_LOGHI = None          # (cartella_png, file_json) risolta una volta


def _percorso_addon(addon_id):
    """Cartella di un altro addon installato, o None se assente.
    xbmcaddon.Addon() solleva se l'id non esiste: qui l'assenza e' un caso
    previsto, non un errore."""
    try:
        return xbmcaddon.Addon(addon_id).getAddonInfo("path")
    except Exception:
        return None


def _base_loghi():
    """Dove stanno i loghi: prima l'addon risorsa, poi la copia interna.

    Il ripiego sulla copia interna serve a chi arriva da una versione <= 1.2.49
    che aveva i PNG dentro il plugin: se per qualche motivo la risorsa non
    c'e', i loghi gia' presenti continuano a funzionare invece di sparire
    tutti insieme."""
    global _BASE_LOGHI
    if _BASE_LOGHI is not None:
        return _BASE_LOGHI

    candidati = []
    base_risorsa = _percorso_addon(ID_RISORSA_LOGHI)
    if base_risorsa:
        candidati.append((os.path.join(base_risorsa, "resources", "loghi"),
                          os.path.join(base_risorsa, "resources", "loghi.json")))
    candidati.append((os.path.join(ADDON_PATH, "resources", "loghi"),
                      os.path.join(ADDON_PATH, "resources", "loghi.json")))

    for dir_png, file_json in candidati:
        if os.path.exists(file_json):
            _BASE_LOGHI = (dir_png, file_json)
            return _BASE_LOGHI

    _BASE_LOGHI = (None, None)
    return _BASE_LOGHI

_RE_SPAZI = re.compile(r"\s+")
_SUFFISSI_SQ = ["fc", "ac", "as", "ss", "us", "cf", "sc", "afc", "fk", "sk",
                "bk", "if"]
_RE_SUFF_SQ = [re.compile(r"\b" + w + r"\b") for w in _SUFFISSI_SQ]


# Punteggiatura che separa parole ma che la normalizzazione base non tocca.
# "Le Puy-en-Velay" diventa 'le puy-en-velay', che non e' la chiave
# 'le puy en velay' e nemmeno le somiglia abbastanza (0.867, sotto la
# soglia 0.88): il logo non si trovava per un trattino.
_RE_PUNTEGGIATURA = re.compile(r"[-‐-―_.,'’/]+")


def normalizza_squadra(nome, separa_punteggiatura=False):
    """Stesso algoritmo di consensus.py e prepara_loghi.py.
    Se le tre divergono, i loghi smettono di essere trovati.

    separa_punteggiatura=True e' una variante usata SOLO come secondo
    tentativo in logo_per_squadra(): non cambia le chiavi della mappa, che
    restano quelle prodotte dalla normalizzazione base. Serve a far
    incontrare grafie che differiscono per soli trattini o punti."""
    n = str(nome).lower().strip()
    if separa_punteggiatura:
        n = _RE_PUNTEGGIATURA.sub(" ", n)
    n = _RE_SPAZI.sub(" ", n)
    for rx in _RE_SUFF_SQ:
        n = rx.sub("", n)
    return _RE_SPAZI.sub(" ", n).strip()


def _carica_mappa_loghi():
    global _MAPPA_LOGHI
    if _MAPPA_LOGHI is not None:
        return _MAPPA_LOGHI
    _, file_json = _base_loghi()
    if not file_json:
        _MAPPA_LOGHI = {}
        return _MAPPA_LOGHI
    try:
        with open(file_json, "r") as f:
            _MAPPA_LOGHI = json.load(f).get("mappa", {})
    except Exception:
        _MAPPA_LOGHI = {}
    return _MAPPA_LOGHI


# Suffissi che indicano una squadra riserve/giovanile: "Real Sociedad B"
# NON deve mai ereditare il logo di "Real Sociedad" (prima squadra), ma
# il punteggio fuzzy da solo non basta - "real sociedad b" vs "real
# sociedad" tocca 0.929, sopra la soglia 0.88 usata qui. Stesso bug e
# stessa correzione gia' applicata a xg_per_squadra() in consensus.py.
_SUFFISSI_RISERVE_LOGO = {"b", "ii", "2", "u21", "u23", "u19", "reserve",
                          "reserves", "riserve", "youth", "primavera"}


def _e_squadra_riserve_logo(nome_normalizzato):
    parole = nome_normalizzato.split()
    return bool(parole) and parole[-1] in _SUFFISSI_RISERVE_LOGO


def logo_per_squadra(nome):
    """Percorso del logo, o None. Prima esatto, poi fuzzy stretto."""
    if not nome:
        return None
    chiave = normalizza_squadra(nome)
    if chiave in _CACHE_LOGHI:
        return _CACHE_LOGHI[chiave]

    mappa = _carica_mappa_loghi()
    fname = mappa.get(chiave)

    if not fname and mappa and not _e_squadra_riserve_logo(chiave):
        # soglia alta: meglio nessun logo che il logo della squadra sbagliata
        candidati = [k for k in mappa.keys() if not _e_squadra_riserve_logo(k)]
        vicini = difflib.get_close_matches(chiave, candidati,
                                           n=1, cutoff=0.88)
        if vicini:
            fname = mappa[vicini[0]]

        # Secondo tentativo, con trattini e punti trattati come spazi da
        # entrambe le parti. La soglia resta 0.88: si allineano le grafie,
        # non si abbassa il livello di prudenza.
        if not fname:
            chiave2 = normalizza_squadra(nome, separa_punteggiatura=True)
            if chiave2 != chiave:
                equiv = {}
                for k in candidati:
                    equiv.setdefault(
                        normalizza_squadra(k, separa_punteggiatura=True), k)
                if chiave2 in equiv:
                    fname = mappa[equiv[chiave2]]
                else:
                    vicini = difflib.get_close_matches(chiave2, list(equiv),
                                                       n=1, cutoff=0.88)
                    if vicini:
                        fname = mappa[equiv[vicini[0]]]

    percorso = None
    dir_png, _ = _base_loghi()
    if fname and dir_png:
        cand = os.path.join(dir_png, fname)
        if os.path.exists(cand):
            percorso = cand

    _CACHE_LOGHI[chiave] = percorso
    return percorso


# ---------------------------------------------------------------- voci

def add_item(label, plot, url, is_folder, casa=None, ospite=None):
    li = xbmcgui.ListItem(label=label)
    li.setInfo("video", {"title": label, "plot": plot})

    # Una ListItem ha UNA sola thumb: due squadre non ci stanno.
    # thumb = casa, fanart = ospite (la fanart compare come sfondo alla
    # selezione, ma la resa dipende dallo skin).
    logo_casa = logo_per_squadra(casa) if casa else None
    logo_osp = logo_per_squadra(ospite) if ospite else None

    art = {"icon": logo_casa or ICON, "thumb": logo_casa or ICON}
    if logo_osp:
        art["fanart"] = logo_osp
    li.setArt(art)

    xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=is_folder)


# ---------------------------------------------------------------- menu

def main_menu():
    add_item("[*] Consensus", "Partite dove Statarea e WebPronostici concordano",
             get_url(action="dates", source="consensus"), True)
    add_item("[S] Statarea", "Pronostici Statarea con percentuali",
             get_url(action="dates", source="statarea"), True)
    add_item("[W] WebPronostici", "1X2, Misti, Under/Over, Gol/NoGol",
             get_url(action="wp_tipi"), True)
    add_item("[A] AsianOdds", "Quote 1xBet, movimenti ed Elo - solo informativo, "
                              "non e' un pronostico",
             get_url(action="ao_filtri"), True)
    add_item("[Impostazioni GitHub]", "Repository, branch e token",
             get_url(action="config"), True)
    xbmcplugin.endOfDirectory(HANDLE)


def _mascherato(valore):
    """Token accorciato per mostrarlo senza scriverlo per intero."""
    if not valore:
        return "non impostato"
    return "{}...{} ({} caratteri)".format(valore[:4], valore[-4:], len(valore))


def show_config():
    """Configurazione dai dialoghi, senza passare dal pannello di Kodi.

    Esiste perche' il pannello delle impostazioni e' fragile: basta un
    dettaglio sbagliato in settings.xml (un'etichetta non numerica, un tag
    <default> vuoto) e i campi spariscono o restano senza nome, lasciando
    l'addon inconfigurabile. Questi dialoghi invece dipendono solo dal
    codice e mostrano sempre il valore attuale."""
    repo = get_setting("gh_repo", "")
    token = get_setting("gh_token", "")
    branch = get_setting("gh_branch", DEFAULT_BRANCH)

    add_item("Repository dei dati: {}".format(repo or "non impostato"),
             "Forma utente/nome-repo. Tocca per modificarlo.",
             get_url(action="imposta", campo="gh_repo"), False)
    add_item("Token GitHub: {}".format(_mascherato(token)),
             "Serve perche' il repository dei dati e' privato.",
             get_url(action="imposta", campo="gh_token"), False)
    add_item("Branch: {}".format(branch or DEFAULT_BRANCH),
             "Di norma gh-data. Cambialo solo se sai perche'.",
             get_url(action="imposta", campo="gh_branch"), False)
    add_item("[Importa da file...]",
             "Legge repository e token da un file di testo: evita di "
             "digitare il token col telecomando",
             get_url(action="importa"), False)
    add_item("[Apri il pannello impostazioni]",
             "Le stesse voci nel pannello standard di Kodi",
             get_url(action="settings"), False)
    xbmcplugin.endOfDirectory(HANDLE)


# Chiavi accettate nel file di configurazione. Piu' di una per campo
# perche' il file lo si scrive a mano e non si deve indovinare il nome.
_CHIAVI_FILE = {
    "repo": "gh_repo", "repository": "gh_repo", "gh_repo": "gh_repo",
    "token": "gh_token", "gh_token": "gh_token", "pat": "gh_token",
    "branch": "gh_branch", "gh_branch": "gh_branch",
}


def leggi_configurazione(testo):
    """Interpreta il file: righe chiave=valore, oppure il solo token.

    Tollera spazi, maiuscole, righe di commento e virgolette: il file viene
    scritto a mano su un telefono, non si puo' pretendere precisione."""
    valori = {}
    righe = [r.strip() for r in testo.replace("\r", "\n").split("\n")]
    righe = [r for r in righe if r and not r.startswith("#")]

    for riga in righe:
        if "=" not in riga:
            continue
        chiave, _, valore = riga.partition("=")
        chiave = chiave.strip().lower()
        valore = valore.strip().strip('"').strip("'")
        if chiave in _CHIAVI_FILE and valore:
            valori[_CHIAVI_FILE[chiave]] = valore

    # File con una sola riga e nessun '=': e' il token e basta.
    if not valori and len(righe) == 1 and " " not in righe[0]:
        valori["gh_token"] = righe[0]
    return valori


def importa_da_file():
    """Sceglie un file e ne importa la configurazione."""
    percorso = xbmcgui.Dialog().browse(
        1, "Scegli il file con la configurazione", "files",
        ".txt|.conf|.cfg", False, False, "")
    if not percorso:
        xbmcplugin.endOfDirectory(HANDLE)
        return

    try:
        f = xbmcvfs.File(percorso)
        testo = f.read()
        f.close()
    except Exception as e:
        notify_error("Impossibile leggere il file: {}".format(e))
        xbmcplugin.endOfDirectory(HANDLE)
        return

    valori = leggi_configurazione(testo or "")
    if not valori:
        notify_error("Nel file non ho trovato repository ne' token")
        xbmcplugin.endOfDirectory(HANDLE)
        return

    salvati = []
    for campo, valore in valori.items():
        try:
            ADDON.setSetting(campo, valore)
            salvati.append(_ETICHETTE_CAMPI.get(campo, (campo,))[0])
        except Exception as e:
            notify_error("Impossibile salvare {}: {}".format(campo, e))

    if salvati:
        xbmcgui.Dialog().notification(
            "Pronostici", "Importati: {}".format(", ".join(salvati)),
            ICON, 4000)
    xbmc.executebuiltin("Container.Refresh")
    xbmcplugin.endOfDirectory(HANDLE)


_ETICHETTE_CAMPI = {
    "gh_repo":   ("Repository dei dati", "utente/nome-repo"),
    "gh_token":  ("Token GitHub", "Incolla il token"),
    "gh_branch": ("Branch", "Branch con i file JSON"),
}


def imposta_campo(campo):
    """Chiede un valore e lo salva. Il valore attuale e' precompilato, cosi'
    si corregge un refuso senza riscrivere tutto da capo."""
    if campo not in _ETICHETTE_CAMPI:
        notify_error("Campo non valido")
        xbmcplugin.endOfDirectory(HANDLE)
        return

    nome, invito = _ETICHETTE_CAMPI[campo]
    attuale = get_setting(campo, DEFAULT_BRANCH if campo == "gh_branch" else "")
    nuovo = xbmcgui.Dialog().input(invito, defaultt=attuale,
                                   type=xbmcgui.INPUT_ALPHANUM)
    nuovo = (nuovo or "").strip()

    if nuovo:
        try:
            ADDON.setSetting(campo, nuovo)
            xbmcgui.Dialog().notification("Pronostici",
                                          "{} salvato".format(nome),
                                          ICON, 3000)
        except Exception as e:
            notify_error("Impossibile salvare: {}".format(e))

    # Torna alla lista aggiornata invece di lasciare una schermata vuota.
    xbmc.executebuiltin("Container.Refresh")
    xbmcplugin.endOfDirectory(HANDLE)


def show_ao_filtri():
    """Due modi di entrare nella sezione AsianOdds.

    'Movimenti' per primo di proposito: il feed contiene ~600 partite delle
    prossime 24h, in gran parte di campionati minori, e scorrerle tutte col
    telecomando non serve a niente. Il filtro e' solo lato addon, il file
    scaricato e' lo stesso."""
    for slug, label, descr in AO_FILTRI:
        add_item(label, descr,
                 get_url(action="dates", source="asianodds", tipo=slug), True)
    xbmcplugin.endOfDirectory(HANDLE)


def show_settings():
    try:
        ADDON.openSettings()
    except Exception as e:
        notify_error("Impossibile aprire le impostazioni: {}".format(e))
    xbmcplugin.endOfDirectory(HANDLE)


def show_wp_tipi():
    """Sottocartelle WebPronostici per tipo di pronostico."""
    disponibili = github_request("webpronostici_tipi.json", silent_404=True)
    slug_ok = None
    if isinstance(disponibili, dict) and isinstance(disponibili.get("tipi"), list):
        slug_ok = set()
        for t in disponibili["tipi"]:
            if isinstance(t, dict) and t.get("slug"):
                slug_ok.add(str(t["slug"]))

    mostrati = 0
    for slug, label in WP_TIPI:
        if slug_ok is not None and slug not in slug_ok:
            continue
        add_item(label, "WebPronostici - {}".format(label),
                 get_url(action="dates", source="webpronostici", tipo=slug), True)
        mostrati += 1

    if mostrati == 0:
        for slug, label in WP_TIPI:
            add_item(label, "WebPronostici - {}".format(label),
                     get_url(action="dates", source="webpronostici", tipo=slug), True)

    xbmcplugin.endOfDirectory(HANDLE)


def index_name(source, tipo):
    if source == "webpronostici" and tipo:
        return "webpronostici_{}_index.json".format(tipo)
    return "{}_index.json".format(source)


def data_name(source, tipo, date):
    if source == "webpronostici" and tipo:
        return "webpronostici_{}_{}.json".format(tipo, date)
    return "{}_{}.json".format(source, date)


def show_dates(source, tipo=""):
    if source not in SORGENTI:
        notify_error("Sorgente non valida")
        xbmcplugin.endOfDirectory(HANDLE)
        return

    # Per AsianOdds il 404 e' il caso normale finche' il workflow non ha
    # pubblicato il primo indice: meglio dirlo che mandare l'utente a
    # controllare repository e token, che sono a posto.
    e_ao = source == "asianodds"
    data = github_request(index_name(source, tipo), silent_404=e_ao)
    if not data:
        if e_ao:
            notify_error("AsianOdds: nessun dato ancora pubblicato su gh-data")
        xbmcplugin.endOfDirectory(HANDLE)
        return

    if isinstance(data, dict):
        dates = data.get("date") or data.get("dates") or []
        updated = data.get("updated", "")
    elif isinstance(data, list):
        dates = data
        updated = ""
    else:
        notify_error("Indice con formato non valido")
        xbmcplugin.endOfDirectory(HANDLE)
        return

    if not dates:
        notify_error("Nessuna data disponibile")

    for d in sorted([str(x) for x in dates], reverse=True):
        add_item(d, "Aggiornato: {}".format(updated),
                 get_url(action="matches", source=source, tipo=tipo, date=d), True)

    xbmcplugin.endOfDirectory(HANDLE)


# ---------------------------------------------------------------- partite

def fmt_pct(v):
    """Restituisce la percentuale senza simbolo, stringa vuota se assente."""
    s = str(v).strip()
    if not s or s.lower() == "nan":
        return ""
    return s.replace("%", "")


def row_statarea(row):
    casa = str(row.get("Casa", ""))
    ospite = str(row.get("Ospite", ""))
    ora = str(row.get("Ora", ""))
    pron = str(row.get("TIP", "")).upper()
    p1 = fmt_pct(row.get("P_1", ""))
    px = fmt_pct(row.get("P_X", ""))
    p2 = fmt_pct(row.get("P_2", ""))
    o15 = fmt_pct(row.get("Over1.5", ""))
    o25 = fmt_pct(row.get("Over2.5", ""))
    o35 = fmt_pct(row.get("Over3.5", ""))
    btts = fmt_pct(row.get("BTTS_SI", ""))
    ht1 = fmt_pct(row.get("HT1", ""))
    htx = fmt_pct(row.get("HTX", ""))
    ht2 = fmt_pct(row.get("HT2", ""))
    comp = str(row.get("Competizione", ""))
    paese = str(row.get("Paese", ""))

    perc = ""
    if p1 and px and p2:
        perc = "  1:{} X:{} 2:{}".format(p1, px, p2)

    label = "{} {} {} vs {}{}".format(
        PRON_ICONS.get(pron, "[?]"), ora, casa, ospite, perc
    )
    plot = (
        "{} - {}\n"
        "Pronostico: {}\n"
        "1X2:  1:{}%  X:{}%  2:{}%\n"
        "HT:   1:{}%  X:{}%  2:{}%\n"
        "Over: 1.5:{}%  2.5:{}%  3.5:{}%\n"
        "BTTS: {}%"
    ).format(paese, comp, pron, p1, px, p2, ht1, htx, ht2, o15, o25, o35, btts)
    return label, plot


def row_webpronostici(row):
    casa = str(row.get("Casa", ""))
    ospite = str(row.get("Ospite", ""))
    ora = str(row.get("Ora", ""))
    pron = str(row.get("Pronostico", "")).upper()
    quota = str(row.get("Quota", ""))
    camp = str(row.get("Campionato", ""))
    tipo = str(row.get("Tipo", ""))

    quota_txt = "  @{}".format(quota) if quota and quota.lower() != "nan" else ""
    ora_txt = "{} ".format(ora) if ora and ora.lower() != "nan" else ""

    label = "{} {}{} vs {}{}".format(
        PRON_ICONS.get(pron, "[" + pron + "]"), ora_txt, casa, ospite, quota_txt
    )
    plot = "Campionato: {}\nTipo: {}\nPronostico: {}\nQuota: {}".format(
        camp, tipo, pron, quota
    )
    return label, plot


def row_consensus(row):
    casa = str(row.get("Casa", ""))
    ospite = str(row.get("Ospite", ""))
    ora = str(row.get("Ora", ""))
    pron = str(row.get("Pron Combinato", "")).upper()
    psa = str(row.get("Pron Statarea", ""))
    pwp = str(row.get("Pron WebPron", ""))
    p1 = fmt_pct(row.get("P_1 %", ""))
    px = fmt_pct(row.get("P_X %", ""))
    p2 = fmt_pct(row.get("P_2 %", ""))
    o15 = fmt_pct(row.get("Over1.5 %", ""))
    o25 = fmt_pct(row.get("Over2.5 %", ""))
    btts = fmt_pct(row.get("BTTS %", ""))
    quota = str(row.get("Quota WP", ""))
    xg_casa = row.get("xG Casa", "")
    xg_ospite = row.get("xG Ospite", "")

    perc = ""
    if p1 and px and p2:
        perc = "  1:{} X:{} 2:{}".format(p1, px, p2)

    # xG solo se ALMENO una delle due squadre ce l'ha (top-5 leghe europee
    # via Understat). Sulle altre leghe questo campo resta assente: non e'
    # un guasto, e' un limite della fonte - vedi consensus.py v4.
    xg_riga = ""
    if xg_casa != "" or xg_ospite != "":
        xg_riga = "\nxG:  {} - {}".format(
            xg_casa if xg_casa != "" else "-",
            xg_ospite if xg_ospite != "" else "-")

    label = "{} {} {} vs {}{}".format(
        PRON_ICONS.get(pron, "[?]"), ora, casa, ospite, perc
    )
    plot = (
        "Pronostico combinato: {}\n"
        "Statarea: {}   WebPronostici: {}\n"
        "1X2:  1:{}%  X:{}%  2:{}%\n"
        "Over: 1.5:{}%  2.5:{}%\n"
        "BTTS: {}%\n"
        "Quota WP: {}"
        "{}"
    ).format(pron, psa, pwp, p1, px, p2, o15, o25, btts, quota, xg_riga)
    return label, plot + righe_asianodds(row)


def _vuoto(v):
    return v is None or v == ""


def righe_asianodds(row):
    """Righe AsianOdds per il riquadro dettagli - solo informative.

    Quote 1xBet (soft book): NON sono un voto e non entrano nel pronostico.
    Il drift e' la variazione % della quota da apertura a ora:
    negativo = quota scesa = il mercato ci crede di piu' su quell'esito.
    Ogni riga compare solo se il dato c'e' (piano free: solo prossime 24h).
    Si usano solo caratteri ASCII per non dipendere dal font dello skin."""
    righe = []

    d1, dx, d2 = row.get("AO Drift 1"), row.get("AO Drift X"), row.get("AO Drift 2")
    if not (_vuoto(d1) and _vuoto(dx) and _vuoto(d2)):
        def fd(v):
            try:
                return "{:+.1f}%".format(float(v))
            except (TypeError, ValueError):
                return "-"
        righe.append("1xBet: 1 {}  X {}  2 {}".format(fd(d1), fd(dx), fd(d2)))

    parti = []
    ah_o, ah = row.get("AO AH Open"), row.get("AO AH")
    if not _vuoto(ah_o) and not _vuoto(ah):
        try:
            parti.append("AH {:+.2f}->{:+.2f}".format(float(ah_o), float(ah)))
        except (TypeError, ValueError):
            pass
    ou_o, ou = row.get("AO OU Open"), row.get("AO OU")
    if not _vuoto(ou_o) and not _vuoto(ou):
        try:
            parti.append("O/U {:.2f}->{:.2f}".format(float(ou_o), float(ou)))
        except (TypeError, ValueError):
            pass
    if parti:
        righe.append("  ".join(parti))

    ec, eo = row.get("AO Elo Casa"), row.get("AO Elo Osp")
    if not _vuoto(ec) and not _vuoto(eo):
        try:
            righe.append("Elo: {} - {}".format(int(float(ec)), int(float(eo))))
        except (TypeError, ValueError):
            pass

    return ("\n" + "\n".join(righe)) if righe else ""


def _num(v):
    """Valore numerico, o None se assente/non numerico."""
    if v is None or v == "":
        return None
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def _e_notevole(row):
    """Vale il filtro "Movimenti"? Decide asianodds_ci.py, qui si legge.

    Il campo "Notevole" tiene conto sia del movimento sia del margine del
    bookmaker: un movimento piccolo su un mercato quotato con cura (margine
    basso) conta piu' di uno grande su una lega minore, dove le quote di
    apertura sono approssimative e il movimento e' spesso solo la loro
    correzione.

    Se il campo manca - JSON prodotti prima della sua introduzione - si
    ripiega sulla sola soglia in punti, cosi' la sezione continua a
    funzionare invece di svuotarsi."""
    if "Notevole" in row:
        return bool(row.get("Notevole"))
    mov = _num(row.get("Mov"))
    return mov is not None and mov >= AO_SOGLIA_MOV


def _e_affidabile(row):
    """La probabilita' e' una stima attendibile? Decide asianodds_ci.py.

    Attendibile non vuol dire conveniente: sono le stime migliori del
    mercato, quindi il prezzo le incorpora gia'. Servono come metro, non
    come pronostico."""
    return bool(row.get("Affidabile"))


def row_asianodds(row):
    """Riga della sezione AsianOdds.

    RUOLO: informazione, non pronostico. Le quote sono 1xBet, un soft book
    con margine medio intorno all'8-9%, e le probabilita' mostrate sono il
    de-vig proporzionale di quelle stesse quote: non sono una fonte in piu'
    accanto a Statarea e WebPronostici, sono il mercato riscritto in
    percentuale. Per questo AsianOdds non entra nel consensus e qui non
    compare nessun simbolo di pronostico.

    Il dato con valore proprio e' 'Mov': di quanti PUNTI di probabilita' si
    e' spostato il mercato dall'apertura. In punti e non in percentuale di
    quota perche' la percentuale non e' confrontabile fra partite - un +50%
    su una quota da 12.00 vale meno di un punto, un -10% su un 1.50 ne vale
    cinque.

    Solo caratteri ASCII: le frecce unicode dipendono dal font dello skin.
    """
    casa = str(row.get("Casa", ""))
    ospite = str(row.get("Ospite", ""))
    ora = str(row.get("Ora", ""))
    lega = str(row.get("Lega", ""))

    p1, px, p2 = _num(row.get("P1")), _num(row.get("PX")), _num(row.get("P2"))
    mov = _num(row.get("Mov"))
    margine = _num(row.get("Margine"))

    perc = ""
    if p1 is not None and px is not None and p2 is not None:
        perc = "  1:{:.0f} X:{:.0f} 2:{:.0f}".format(p1, px, p2)

    # Il movimento in etichetta solo quando e' significativo: su centinaia
    # di righe un "mov 0.3" ripetuto e' rumore che allunga la lista. Il
    # criterio e' lo stesso del filtro, altrimenti in "Tutte" si vedrebbero
    # partite marcate che poi in "Movimenti" non compaiono.
    mov_txt = ""
    if mov is not None and _e_notevole(row):
        mov_txt = "  [mov {:.1f}]".format(mov)

    # Un marcatore per le affidabili, cosi' si riconoscono anche scorrendo
    # "Tutte" senza entrare nel dettaglio.
    aff_txt = "  *" if _e_affidabile(row) else ""
    label = "{} {} vs {}{}{}{}".format(ora, casa, ospite, perc, mov_txt, aff_txt)

    righe = [lega] if lega else []

    # Quote: apertura -> corrente, con il drift accanto.
    for esito, ka, kq, kd in (("1", "Q1 Apre", "Q1", "Drift 1"),
                              ("X", "QX Apre", "QX", "Drift X"),
                              ("2", "Q2 Apre", "Q2", "Drift 2")):
        qa, qc, dr = _num(row.get(ka)), _num(row.get(kq)), _num(row.get(kd))
        if qc is None:
            continue
        testo = "{}: {:.2f}".format(esito, qc)
        if qa is not None and qa != qc:
            testo = "{}: {:.2f} -> {:.2f}".format(esito, qa, qc)
        if dr is not None:
            testo += "  ({:+.1f}%)".format(dr)
        righe.append(testo)

    # Due metodi di de-vig. Il proporzionale toglie il margine in parti
    # uguali; Shin ne carica di piu' sugli esiti lunghi, come fanno i
    # bookmaker davvero, ed e' il metodo che il Sistema usa come default.
    #
    # La seconda riga compare SOLO quando i due divergono di almeno un
    # punto: su gran parte delle partite coincidono (sotto 0.6 punti quando
    # non c'e' un outsider lungo) e due righe identiche sarebbero rumore.
    # Dove divergono, invece, la differenza e' il dato: significa che c'e'
    # un favorito netto e un outsider lungo, e che la percentuale
    # proporzionale dell'outsider e' gonfiata.
    s1, sx, s2 = (_num(row.get("P1 Shin")), _num(row.get("PX Shin")),
                  _num(row.get("P2 Shin")))
    if p1 is not None:
        riga = "Prob. de-vig:  1 {:.1f}%  X {:.1f}%  2 {:.1f}%".format(p1, px, p2)
        if margine is not None:
            riga += "   margine {:.1f}%".format(margine)
        righe.append(riga)
        if s1 is not None:
            scarto = max(abs(s1 - p1), abs(sx - px), abs(s2 - p2))
            if scarto >= 1.0:
                righe.append("  con Shin:    1 {:.1f}%  X {:.1f}%  2 {:.1f}%"
                             "   (scarto {:.1f} pt)".format(s1, sx, s2, scarto))
    elif s1 is not None:
        righe.append("Prob. Shin:  1 {:.1f}%  X {:.1f}%  2 {:.1f}%".format(s1, sx, s2))

    if mov is not None:
        righe.append("Movimento dall'apertura: {:.1f} punti".format(mov))

    # Linee AH e O/U: informative anche da sole, e non dipendono dalla
    # mappatura h/a delle quote over/under, che nella fonte non e'
    # confermata - per questo le quote O/U non si mostrano affatto.
    parti = []
    for etichetta, ka, kc, fmt in (("AH", "AH Apre", "AH", "{:+.2f}"),
                                   ("O/U", "OU Apre", "OU", "{:.2f}")):
        a, c = _num(row.get(ka)), _num(row.get(kc))
        if c is None:
            continue
        if a is not None and a != c:
            parti.append("{} {} -> {}".format(etichetta, fmt.format(a), fmt.format(c)))
        else:
            parti.append("{} {}".format(etichetta, fmt.format(c)))
    if parti:
        righe.append("   ".join(parti))

    ec, eo = _num(row.get("Elo Casa")), _num(row.get("Elo Osp"))
    if ec is not None and eo is not None:
        righe.append("Elo: {:.0f} - {:.0f}  (diff {:+.0f})".format(ec, eo, ec - eo))

    righe.append("")
    righe.append("Quote 1xBet, solo informative: non entrano nel pronostico.")
    return label, "\n".join(righe)


def show_matches(source, date, tipo=""):
    if source not in SORGENTI or not date:
        notify_error("Parametri non validi")
        xbmcplugin.endOfDirectory(HANDLE)
        return

    data = github_request(data_name(source, tipo, date))
    if not data:
        xbmcplugin.endOfDirectory(HANDLE)
        return

    if isinstance(data, dict):
        for key in ("matches", "data", "results", "rows"):
            if isinstance(data.get(key), list):
                data = data[key]
                break

    if not isinstance(data, list):
        notify_error("Dati con formato non valido")
        xbmcplugin.endOfDirectory(HANDLE)
        return

    count = 0
    scartate_filtro = 0
    for row in data:
        if not isinstance(row, dict):
            continue
        if source == "statarea":
            label, plot = row_statarea(row)
        elif source == "webpronostici":
            label, plot = row_webpronostici(row)
        elif source == "asianodds":
            # Filtro "Movimenti": si applica qui e non a monte perche' il
            # file su gh-data e' uno solo. Una partita senza 'Mov' (quote di
            # apertura mancanti) resta fuori: non si sa se si e' mossa.
            if tipo == "mov" and not _e_notevole(row):
                scartate_filtro += 1
                continue
            if tipo == "aff" and not _e_affidabile(row):
                scartate_filtro += 1
                continue
            label, plot = row_asianodds(row)
        else:
            label, plot = row_consensus(row)

        add_item(label, plot, get_url(action="noop"), False,
                 casa=row.get("Casa"), ospite=row.get("Ospite"))
        count += 1

    if count == 0:
        if scartate_filtro:
            # Distinzione che conta: i dati ci sono, e' il filtro che e'
            # severo. Senza questo messaggio sembrerebbe un guasto.
            if tipo == "aff":
                notify_error(
                    "Nessuna partita a margine basso fra le {} del {}. "
                    "Prova 'Tutte'.".format(scartate_filtro, date))
            else:
                notify_error(
                    "Nessun movimento oltre {:.0f} punti fra le {} partite del "
                    "{}. Prova 'Tutte'.".format(AO_SOGLIA_MOV, scartate_filtro,
                                                date))
        else:
            notify_error("Nessuna partita trovata per {}".format(date))

    xbmcplugin.endOfDirectory(HANDLE)


# ---------------------------------------------------------------- router

params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
action = params.get("action", "")

if not action:
    main_menu()
elif action == "wp_tipi":
    show_wp_tipi()
elif action == "ao_filtri":
    show_ao_filtri()
elif action == "dates":
    show_dates(params.get("source", ""), params.get("tipo", ""))
elif action == "matches":
    show_matches(params.get("source", ""), params.get("date", ""),
                 params.get("tipo", ""))
elif action == "config":
    show_config()
elif action == "imposta":
    imposta_campo(params.get("campo", ""))
elif action == "importa":
    importa_da_file()
elif action == "settings":
    show_settings()
else:
    xbmcplugin.endOfDirectory(HANDLE)

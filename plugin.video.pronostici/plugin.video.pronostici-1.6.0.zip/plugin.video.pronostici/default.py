# -*- coding: utf-8 -*-
import os
import re
import sys
import json
import base64
import difflib
import time
import unicodedata
import urllib.request
import urllib.parse
import urllib.error

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]

ADDON_PATH = ADDON.getAddonInfo("path")
ICON = os.path.join(ADDON_PATH, "resources", "icon.png")

# I DATI STANNO IN UN REPOSITORY PUBBLICO: nessun token, nessuna
# configurazione. L'addon funziona appena installato, come qualunque altro
# addon di terze parti.
#
# Come ci siamo arrivati: fino alla 1.3.9 i JSON stavano nel repository
# privato degli scraper, e per leggerli serviva un token GitHub che andava
# distribuito a mano a ogni persona. Ora il workflow pubblica i soli JSON
# giornalieri su questo repository pubblico, mentre scraper e codice
# restano privati.
DEFAULT_REPO = "Caltiki/pronostici-repo"
DEFAULT_BRANCH = "gh-data"

# Un repository pubblico si legge da raw.githubusercontent.com senza
# autenticazione. L'API di GitHub servirebbe solo per quelli privati, ha un
# limite di 60 richieste l'ora agli anonimi e restituisce i file in base64:
# per il nostro caso e' solo peso in piu'.
RAW_BASE = "https://raw.githubusercontent.com/{repo}/{branch}/{path}"

# NESSUN TOKEN, NE' NEL PACCHETTO NE' DA DIGITARE.
#
# Tre tappe, per capire perche' il codice qui sotto ha questa forma:
#   - fino alla 1.2.49 il token stava scritto in chiaro nel file
#     (FALLBACK_TOKEN), per non doverne digitare 93 caratteri col
#     telecomando. Reggeva solo perche' lo ZIP girava a mano;
#   - dalla 1.3.0 l'addon si aggiorna da un repository pubblico: un token
#     scritto qui sarebbe stato leggibile da chiunque, quindi e' passato
#     nelle impostazioni, da inserire una volta per installazione;
#   - da questa 1.4.0 i dati stessi sono pubblici, e il token non serve
#     piu' a nessuno. Le impostazioni lo leggono ancora, ma solo per chi
#     punta l'addon a un repository privato suo.
_TOKEN_CACHE = None

PRON_ICONS = {
    "1": "[1]", "X": "[X]", "2": "[2]",
    "1X": "[1X]", "X2": "[X2]", "12": "[12]",
    "GG": "[GG]", "NG": "[NG]",
    "OVER": "[OV]", "UNDER": "[UN]",
}

# Tipi WebPronostici: slug -> etichetta menu
WP_TIPI = [
    ("1x2",   "1X2"),
    ("misti", "Misti"),
    ("ou",    "Under / Over"),
    ("ggng",  "Gol / NoGol"),
]

# Sorgenti valide. AsianOdds ha il suo JSON (asianodds_<data>.json), quindi
# la sezione funziona anche nei giorni in cui il consensus e' vuoto: prima
# i dati AsianOdds si vedevano solo dentro le righe del consensus, cioe'
# solo per le partite che Statarea e WebPronostici avevano in comune.
SORGENTI = ("consensus", "statarea", "webpronostici", "asianodds", "fpnet",
            "xgaura")

# Mercati della sezione xGaura: slug, etichetta, valori del campo Mercato.
#
# Il sottomenu divide per MERCATO e non per confidenza. La confidenza che
# il sito pubblica e' un numero che si da' da solo: non e' una probabilita'
# calibrata, non e' verificabile, e non risulta che il sito pubblichi mai
# lo storico delle chiusure. Usarla come filtro vorrebbe dire lasciare a
# loro la decisione su cosa vale la pena guardare. Resta scritta nella
# riga, accanto alla probabilita' implicita nella quota, che invece e' un
# numero che non si sono inventati: cosi' lo scarto fra le due si vede.
#
# Serve comunque un filtro, perche' i tip sono centinaia al giorno (233
# oggi e 435 domani, contati il 03/09) e scorrerli tutti col telecomando
# non ha senso. Dividere per mercato e' navigazione e basta, senza
# giudizio: e' lo stesso schema dei tipi di WebPronostici.
XG_MERCATI = [
    ("1x2",  "1X2",            ("1X2",),
     "Esito finale: 1, X o 2"),
    ("ou",   "Under / Over",   ("OU",),
     "Sopra o sotto la soglia di gol"),
    ("btts", "Gol / NoGol",    ("BTTS",),
     "Segnano entrambe le squadre, oppure no"),
    ("dc",   "Doppia chance",  ("DC",),
     "1X, X2, 12"),
    ("tutti", "Tutti i mercati", (),
     "Tutti i tip del giorno, compresi primo tempo e voci non classificate"),
]


# Filtri della sezione AsianOdds: slug -> (etichetta, descrizione)
AO_FILTRI = [
    ("aff",   "Affidabili",
     "Margine basso e i due de-vig concordi: le probabilita' piu' attendibili"),
    ("mov",   "Movimenti",
     "Solo le partite dove il mercato si e' mosso davvero"),
    ("tutte", "Tutte",
     "Tutte le partite delle prossime 24h"),
]

# Il filtro "Movimenti" NON si ricalcola qui: asianodds_ci.py scrive nel JSON
# un campo "Notevole" gia' deciso, e l'addon si limita a leggerlo. Cosi' la
# regola vive in un posto solo e non puo' divergere - in 1.3.2-1.3.4 la
# soglia era scritta in due file e, quando le misure sul primo file vero
# hanno mostrato che 4 punti erano troppo pochi, correggerne uno solo avrebbe
# fatto mostrare a Kodi partite diverse da quelle dell'Excel.
#
# La soglia qui sotto serve solo a due cose: mostrare l'etichetta [mov N] in
# elenco, e filtrare i JSON prodotti prima che il campo esistesse.
AO_SOGLIA_MOV = 8.0


def get_setting(name, default=""):
    try:
        value = ADDON.getSetting(name)
        return value.strip() if value else default
    except Exception:
        return default


def get_url(**kwargs):
    return "{}?{}".format(BASE_URL, urllib.parse.urlencode(kwargs))


def get_github_token():
    """Token GitHub: ORMAI FACOLTATIVO.

    Con il repository dei dati pubblico non serve a nulla, e infatti non
    viene piu' chiesto all'avvio. Resta letto dalle impostazioni per chi
    punta l'addon a un repository privato suo: in quel caso si passa
    dall'API di GitHub invece che da raw."""
    global _TOKEN_CACHE
    if _TOKEN_CACHE is not None:
        return _TOKEN_CACHE
    _TOKEN_CACHE = get_setting("gh_token", "")
    return _TOKEN_CACHE


_REPO_CACHE = None


def get_repo():
    """Repository dei dati. Il default e' quello pubblico: nessuno deve
    configurare niente. Resta modificabile per chi vuole puntare altrove."""
    global _REPO_CACHE
    if _REPO_CACHE is not None:
        return _REPO_CACHE
    _REPO_CACHE = get_setting("gh_repo", DEFAULT_REPO) or DEFAULT_REPO
    return _REPO_CACHE


def get_branch():
    return get_setting("gh_branch", DEFAULT_BRANCH) or DEFAULT_BRANCH


def migra_da_privato():
    """Migrazione 1.3.x -> 1.4.0, una volta sola.

    Il problema che risolve: le impostazioni vivono in userdata/addon_data/
    e un aggiornamento dell'addon NON le tocca. Quindi chi arriva dalla
    1.3.x si ritrova con il vecchio repository privato e il vecchio token
    ancora scritti, e il codice nuovo li rispetterebbe: continuerebbe a
    interrogare l'API di GitHub con un token che prima o poi scade, invece
    del repository pubblico che ora funziona da solo.

    Perche' svuotarle d'ufficio e' lecito: prima della 1.4.0 quei due campi
    non erano una scelta, erano l'unico modo di far funzionare l'addon. Un
    valore salvato la' dentro e' per forza il vecchio default, non una
    preferenza. Dalla 1.4.0 in poi lo sono, e il segnaposto impedisce alla
    migrazione di rigirare e cancellare una scelta vera."""
    if get_setting("migrato_140", "") == "true":
        return

    global _TOKEN_CACHE, _REPO_CACHE
    repo = get_setting("gh_repo", "")
    token = get_setting("gh_token", "")
    try:
        if repo and repo != DEFAULT_REPO:
            ADDON.setSetting("gh_repo", "")
            _REPO_CACHE = None
        if token:
            ADDON.setSetting("gh_token", "")
            _TOKEN_CACHE = None
        ADDON.setSetting("migrato_140", "true")
    except Exception:
        # Se la scrittura non riesce, il peggio e' ritentare al prossimo
        # avvio: non e' un motivo per non mostrare i pronostici.
        return

    if repo or token:
        xbmcgui.Dialog().notification(
            "Pronostici",
            "Dati ora su repository pubblico: token non piu' necessario",
            ICON, 6000)


def notify_error(message):
    xbmcgui.Dialog().notification(
        "Pronostici", str(message)[:180],
        xbmcgui.NOTIFICATION_ERROR, 5000
    )


def _scarica_json(url, headers, silent_404, da_api):
    """Scarica e interpreta un JSON. None su qualunque errore, dopo averlo
    riferito all'utente in modo leggibile."""
    try:
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=20) as response:
            grezzo = response.read().decode("utf-8-sig")

        if not da_api:
            return json.loads(grezzo)

        # L'API restituisce i metadati del file e il contenuto in base64.
        payload = json.loads(grezzo)
        if not isinstance(payload, dict) or "content" not in payload:
            if not silent_404:
                notify_error("GitHub: contenuto file non disponibile")
            return None
        return json.loads(base64.b64decode(payload["content"]).decode("utf-8-sig"))

    except urllib.error.HTTPError as e:
        if e.code == 404:
            if not silent_404:
                notify_error("Dati non trovati (404): il file per quella data "
                             "non e' ancora stato pubblicato.")
        elif e.code == 401:
            # Ci si arriva solo con un token salvato a mano nel pannello:
            # senza token si passa da raw, che non autentica niente. Quindi
            # il consiglio giusto e' tornare al pubblico svuotando i campi,
            # non correggere il token.
            notify_error("Token non valido o scaduto (401). Svuota i campi "
                         "in Impostazioni per tornare ai valori predefiniti.")
        elif e.code == 403:
            notify_error("Accesso negato o limite richieste (403)")
        else:
            notify_error("Errore HTTP {}".format(e.code))
    except urllib.error.URLError as e:
        notify_error("Connessione: {}".format(e.reason))
    except ValueError:
        notify_error("Il file scaricato non e' un JSON valido")
    except Exception as e:
        notify_error("Errore: {}".format(e))
    return None


def github_request(path, silent_404=False):
    """Scarica un JSON dei dati.

    DUE STRADE, scelte in base alla presenza del token:

      - senza token (il caso normale): raw.githubusercontent.com, che serve
        i file dei repository PUBBLICI senza autenticazione e senza limiti
        stretti. E' cio' che permette all'addon di funzionare appena
        installato, senza chiedere niente a chi lo usa.

      - con token: l'API di GitHub, l'unica che legge i repository privati.
        Serve solo a chi punta l'addon a un repository suo.
    """
    repo = get_repo()
    branch = get_branch()
    if "/" not in repo:
        notify_error("Repository non valido: serve la forma utente/nome-repo")
        return None

    path = path.lstrip("/")
    token = get_github_token()
    headers = {"User-Agent": "Kodi-21-Pronostici/1.6.0"}

    if token:
        url = "https://api.github.com/repos/{}/contents/{}?ref={}".format(
            repo, path, urllib.parse.quote(branch, safe=""))
        headers["Accept"] = "application/vnd.github+json"
        headers["Authorization"] = "Bearer {}".format(token)
        return _scarica_json(url, headers, silent_404, da_api=True)

    url = RAW_BASE.format(repo=repo, branch=urllib.parse.quote(branch, safe=""),
                          path=urllib.parse.quote(path))
    return _scarica_json(url, headers, silent_404, da_api=False)


# ---------------------------------------------------------------- loghi

# I loghi vivono in un addon separato, resource.images.pronostici: 877 PNG
# per 16 MB che cambiano raramente, mentre questo file cambia spesso. Tenerli
# qui dentro voleva dire riscaricare 16 MB per ogni correzione al codice.
ID_RISORSA_LOGHI = "resource.images.pronostici"

_MAPPA_LOGHI = None
_AMBIGUE = None
_SENZA_APPROSSIMARE = None
_CACHE_LOGHI = {}
_BASE_LOGHI = None          # (cartella_png, file_json) risolta una volta


def _percorso_addon(addon_id):
    """Cartella di un altro addon installato, o None se assente.
    xbmcaddon.Addon() solleva se l'id non esiste: qui l'assenza e' un caso
    previsto, non un errore."""
    try:
        return xbmcaddon.Addon(addon_id).getAddonInfo("path")
    except Exception:
        return None


def _base_loghi():
    """Dove stanno i loghi: prima l'addon risorsa, poi la copia interna.

    Il ripiego sulla copia interna serve a chi arriva da una versione <= 1.2.49
    che aveva i PNG dentro il plugin: se per qualche motivo la risorsa non
    c'e', i loghi gia' presenti continuano a funzionare invece di sparire
    tutti insieme."""
    global _BASE_LOGHI
    if _BASE_LOGHI is not None:
        return _BASE_LOGHI

    candidati = []
    base_risorsa = _percorso_addon(ID_RISORSA_LOGHI)
    if base_risorsa:
        candidati.append((os.path.join(base_risorsa, "resources", "loghi"),
                          os.path.join(base_risorsa, "resources", "loghi.json")))
    candidati.append((os.path.join(ADDON_PATH, "resources", "loghi"),
                      os.path.join(ADDON_PATH, "resources", "loghi.json")))

    for dir_png, file_json in candidati:
        if os.path.exists(file_json):
            _BASE_LOGHI = (dir_png, file_json)
            return _BASE_LOGHI

    _BASE_LOGHI = (None, None)
    return _BASE_LOGHI

_RE_SPAZI = re.compile(r"\s+")
_SUFFISSI_SQ = ["fc", "ac", "as", "ss", "us", "cf", "sc", "afc", "fk", "sk",
                "bk", "if"]
_RE_SUFF_SQ = [re.compile(r"\b" + w + r"\b") for w in _SUFFISSI_SQ]


# Punteggiatura che separa parole ma che la normalizzazione base non tocca.
# "Le Puy-en-Velay" diventa 'le puy-en-velay', che non e' la chiave
# 'le puy en velay' e nemmeno le somiglia abbastanza (0.867, sotto la
# soglia 0.88): il logo non si trovava per un trattino.
_RE_PUNTEGGIATURA = re.compile(r"[-‐-―_.,'’/]+")


def normalizza_squadra(nome, separa_punteggiatura=False):
    """Stesso algoritmo di consensus.py e prepara_loghi.py.
    Se le tre divergono, i loghi smettono di essere trovati.

    separa_punteggiatura=True e' una variante usata SOLO come secondo
    tentativo in logo_per_squadra(): non cambia le chiavi della mappa, che
    restano quelle prodotte dalla normalizzazione base. Serve a far
    incontrare grafie che differiscono per soli trattini o punti."""
    n = str(nome).lower().strip()
    if separa_punteggiatura:
        n = _RE_PUNTEGGIATURA.sub(" ", n)
    n = _RE_SPAZI.sub(" ", n)
    for rx in _RE_SUFF_SQ:
        n = rx.sub("", n)
    return _RE_SPAZI.sub(" ", n).strip()


# Lettere che NFKD non scompone, perche' non sono una base piu' un segno:
# sono caratteri a se'. Vanno tradotte a mano, o Bodo/Glimt e Stabaek non
# incontrano mai bodø-glimt e stabæk.
_TRADUZIONE_LETTERE = {
    "ø": "o", "æ": "ae", "å": "a", "ð": "d", "þ": "th", "ß": "ss",
    "đ": "d", "ł": "l", "ı": "i", "œ": "oe", "ħ": "h", "ż": "z", "ġ": "g",
}


def _senza_accenti(testo):
    """Versione ASCII di una stringa: 'tromsø' -> 'tromso'.

    Serve perche' i nomi dei file dei loghi arrivano quasi sempre senza
    accenti, mentre le fonti scrivono i nomi per esteso. Senza questo,
    'Hafnarfjörður' e 'hafnarfjordur' restano due cose diverse e lo stemma
    non si trova - a meno di curare a mano un alias per ogni squadra, che e'
    esattamente il lavoro che questa funzione toglie di mezzo.

    Si applica a ENTRAMBI i lati del confronto, quindi non puo' far
    incontrare squadre che gia' non si somigliavano."""
    testo = "".join(_TRADUZIONE_LETTERE.get(c, c) for c in testo)
    scomposto = unicodedata.normalize("NFKD", testo)
    return "".join(c for c in scomposto if not unicodedata.combining(c))


# LA MAPPA DEI NOMI E' UN DATO, NON CODICE.
#
# Fino alla 1.4.4 viveva solo dentro il pacchetto dei loghi: correggere un
# alias - "Valenzana" e' la "Valenzanese", "Club Leon" in Serie D non e' il
# messicano - voleva dire ricostruire un pacchetto da 11 MB, caricarlo, e
# poi convincere Kodi ad accorgersene, cosa che richiede fino a un giorno
# perche' Kodi tiene in cache l'elenco delle versioni di ogni repository.
#
# Le IMMAGINI restano nel pacchetto: sono binari, cambiano di rado. I NOMI
# no: si scaricano da un file solo, che l'addon tiene in copia locale e
# ricontrolla ogni mezz'ora con una richiesta condizionale - se il file non
# e' cambiato il server risponde 304 e non trasferisce nulla.
URL_MAPPA = "https://raw.githubusercontent.com/{repo}/main/loghi.json"
ETA_MAPPA = 1800          # mezz'ora, poi si ricontrolla (non si riscarica)

# Entrando nel menu principale la mappa si ricontrolla SEMPRE, scadenza o
# no. Costa una richiesta condizionale per sessione - qualche centinaio di
# byte se il file non e' cambiato - e in cambio una correzione pubblicata
# adesso si vede riaprendo l'addon, senza aspettare la scadenza. Dentro le
# liste invece vale la scadenza normale: navigare non deve costare rete.
_RICONTROLLA_SUBITO = False


def _cartella_dati():
    """userdata/addon_data/plugin.video.pronostici, creata se manca.
    Sopravvive agli aggiornamenti dell'addon."""
    try:
        base = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
    except Exception:
        return None
    try:
        if not os.path.isdir(base):
            os.makedirs(base)
    except Exception:
        return None
    return base


def _scarica_mappa(percorso_cache):
    """Scarica la mappa aggiornata, o conferma quella che c'e'.

    Restituisce True se la copia locale e' utilizzabile. Qualunque errore
    di rete non e' un problema: si continua con quello che si ha, e in
    ultima istanza con la copia dentro il pacchetto."""
    repo = get_repo()
    if "/" not in repo:
        return False
    url = URL_MAPPA.format(repo=repo)
    testa = {"User-Agent": "Kodi-21-Pronostici/1.6.0"}

    # Richiesta condizionale: se il file non e' cambiato dall'ultima volta,
    # GitHub risponde 304 e il trasferimento e' di poche centinaia di byte.
    marchio = None
    try:
        with open(percorso_cache + ".etag", "r") as f:
            marchio = f.read().strip()
    except Exception:
        pass
    if marchio and os.path.exists(percorso_cache):
        testa["If-None-Match"] = marchio

    try:
        req = urllib.request.Request(url, headers=testa)
        with urllib.request.urlopen(req, timeout=15) as risposta:
            grezzo = risposta.read().decode("utf-8-sig")
            nuovo_marchio = risposta.headers.get("ETag", "")
        dati = json.loads(grezzo)           # si scrive solo se e' JSON valido
        if not isinstance(dati.get("mappa"), dict) or not dati["mappa"]:
            return os.path.exists(percorso_cache)
        with open(percorso_cache, "w") as f:
            json.dump(dati, f, ensure_ascii=False)
        if nuovo_marchio:
            with open(percorso_cache + ".etag", "w") as f:
                f.write(nuovo_marchio)
        return True
    except urllib.error.HTTPError as e:
        if e.code == 304:                    # non e' cambiata: tocco la data
            try:
                os.utime(percorso_cache, None)
            except Exception:
                pass
            return True
        return os.path.exists(percorso_cache)
    except Exception:
        return os.path.exists(percorso_cache)


def _carica_mappa_loghi():
    global _MAPPA_LOGHI, _AMBIGUE, _SENZA_APPROSSIMARE
    if _MAPPA_LOGHI is not None:
        return _MAPPA_LOGHI

    candidati = []
    cartella = _cartella_dati()
    if cartella:
        cache = os.path.join(cartella, "loghi.json")
        eta = None
        try:
            eta = time.time() - os.path.getmtime(cache)
        except Exception:
            pass
        if eta is None or eta > ETA_MAPPA or _RICONTROLLA_SUBITO:
            _scarica_mappa(cache)
        if os.path.exists(cache):
            candidati.append(cache)

    # Ultima rete di sicurezza: la copia dentro il pacchetto dei loghi.
    _, file_json = _base_loghi()
    if file_json:
        candidati.append(file_json)

    for percorso in candidati:
        try:
            with open(percorso, "r") as f:
                dati = json.load(f)
            mappa = dati.get("mappa")
            if isinstance(mappa, dict) and mappa:
                _MAPPA_LOGHI = mappa
                _AMBIGUE = dati.get("ambigue", {})
                _SENZA_APPROSSIMARE = set(dati.get("senza", []))
                return _MAPPA_LOGHI
        except Exception:
            continue

    _MAPPA_LOGHI = {}
    _AMBIGUE = {}
    _SENZA_APPROSSIMARE = set()
    return _MAPPA_LOGHI


def _carica_ambigue():
    """Tabella delle omonimie, che vive nello stesso file della mappa.
    Formato: {"leon": [["italy", "leon-ssd.png"], ["mexic", "club-leon.png"]]}
    Il primo indizio che compare nel campionato vince, quindi l'ordine
    conta: il piu' specifico va messo per primo."""
    global _AMBIGUE
    if _AMBIGUE is None:
        _carica_mappa_loghi()          # riempie anche _AMBIGUE
        if _AMBIGUE is None:
            _AMBIGUE = {}
    return _AMBIGUE


def _carica_senza_approssimare():
    """Nomi ai quali e' VIETATO arrivare per somiglianza.

    Nascono da un controllo fatto a vista su tutte le squadre risolte non
    per via esatta. Ogni riga e' un caso in cui il fuzzy, sopra la sua
    soglia, aggancia un club diverso perche' in archivio manca lo stemma di
    quello giusto:
      'reggina'        -> reggiana.png     (Reggio Calabria contro Reggio Emilia, 0.93)
      'lara deportiva' -> lorca-deportiva.png (Venezuela contro Spagna)

    La lista si spegne da sola: il controllo scatta SOLO dopo che la
    ricerca esatta e' fallita, quindi il giorno che arriva reggina.png e
    la sua chiave entra in mappa, la riga qui dentro smette di contare
    senza che nessuno debba ricordarsi di toglierla."""
    global _SENZA_APPROSSIMARE
    if _SENZA_APPROSSIMARE is None:
        _carica_mappa_loghi()
        if _SENZA_APPROSSIMARE is None:
            _SENZA_APPROSSIMARE = set()
    return _SENZA_APPROSSIMARE


# Suffissi che indicano una squadra riserve/giovanile: "Real Sociedad B"
# NON deve mai ereditare il logo di "Real Sociedad" (prima squadra), ma
# il punteggio fuzzy da solo non basta - "real sociedad b" vs "real
# sociedad" tocca 0.929, sopra la soglia 0.88 usata qui. Stesso bug e
# stessa correzione gia' applicata a xg_per_squadra() in consensus.py.
# ATTENZIONE - "c" e "iii" sono qui per la stessa ragione di "b" e "ii": in
# Spagna le terze squadre giocano in Tercera Federacion e si chiamano
# "Villarreal C", "Real Sociedad C". Senza, il fuzzy le aggancerebbe alla
# prima squadra ('sevilla c' e 'sevilla' si somigliano al 93%) e mostrerebbe
# lo stemma sbagliato. Questo NON impedisce alle squadre C presenti in mappa
# di avere il loro logo: la ricerca esatta viene prima della guardia.
_SUFFISSI_RISERVE_LOGO = {"b", "c", "ii", "iii", "2", "u21", "u23", "u19",
                          "reserve", "reserves", "riserve", "youth",
                          "primavera"}


def _e_squadra_riserve_logo(nome_normalizzato):
    parole = nome_normalizzato.split()
    return bool(parole) and parole[-1] in _SUFFISSI_RISERVE_LOGO


# Marcatori di VARIANTE: pezzi di nome che non indicano un club diverso, ma
# un'altra squadra dello stesso club - la femminile, la seconda, l'under.
# Tutte usano lo stemma della prima squadra, e le nazionali giovanili usano
# la bandiera: "Arsenal (w)", "Osasuna B", "Francia U21", "Inter U23".
#
# La lista delle riserve e' la stessa della guardia qui sopra, piu' l'arco
# completo degli under: le due cose sono facce della stessa moneta, la
# guardia VIETA il fuzzy a questi nomi e questa regola concede loro lo
# stemma del club per via esatta.
_MARCATORI_FEMMINILE = {
    "w", "wom", "women", "womens", "ladies", "femminile", "femenino",
    "femenil", "feminino", "feminin", "feminina", "frauen", "damen",
    "dames", "kvinner", "naiset", "kobiet", "zeny",
}
_MARCATORI_VARIANTE = (_MARCATORI_FEMMINILE | _SUFFISSI_RISERVE_LOGO |
                       {"u16", "u17", "u18", "u20", "u22"})

# Le parentesi non sono punteggiatura "che separa parole" per la
# normalizzazione base, ma qui servono aperte: la fonte scrive "Arsenal (w)".
_RE_PARENTESI = re.compile(r"[()\[\]{}]+")


def _nome_senza_marcatori(chiave_punteggiata):
    """Toglie i marcatori di variante dalla CODA del nome, o None se non ce
    ne sono.

    Solo dalla coda, e solo finche' ce ne sono: "Atletico Madrid Femenino
    (w)" perde due pezzi e diventa 'atletico madrid'. Se non resta niente
    (un nome fatto di soli marcatori, tipo "Juniors") restituisce None,
    perche' un nome vuoto si aggancerebbe a qualunque cosa."""
    parole = _RE_PARENTESI.sub(" ", chiave_punteggiata).split()
    tolto = False
    while parole and parole[-1] in _MARCATORI_VARIANTE:
        parole.pop()
        tolto = True
    if not tolto or not parole:
        return None
    return " ".join(parole)


def _campi_riga(row):
    """Il campionato o il paese della partita, come lo scrive la fonte.

    Ogni sorgente lo chiama a modo suo: AsianOdds 'Lega', Statarea 'Paese' e
    'Competizione', WebPronostici 'Campionato'. Il consensus non lo porta
    affatto, ed e' il motivo per cui li' le squadre ambigue restano senza
    stemma."""
    pezzi = []
    for c in ("Lega", "Paese", "Competizione", "Campionato"):
        v = row.get(c)
        if v:
            pezzi.append(str(v))
    return " ".join(pezzi)


def _scioglie_omonimia(chiave, dove):
    """Sceglie fra due club che si chiamano allo stesso modo, guardando in
    che campionato si gioca la partita.

    Serve perche' esistono nomi che NESSUNA chiave puo' distinguere. Il caso
    che ha fatto nascere questa funzione: 'Leon'. AsianOdds lo usa per la
    Serie D italiana, Statarea per il Liga MX messicano, WebPronostici
    scrive 'Club Leon' intendendo di nuovo l'italiano. Stessa stringa, tre
    convenzioni, e l'unica cosa che li separa e' il campionato - che nel
    dato c'e' sempre stato, e finora buttavamo via.

    Senza contesto (il consensus non lo porta) restituisce None: meglio
    nessuno stemma che quello dell'altro club."""
    tabella = _carica_ambigue()
    voci = tabella.get(chiave)
    if not voci:
        return False, None            # non e' un nome ambiguo: prosegui
    contesto = _senza_accenti(str(dove or "").lower())
    for indizio, fname in voci:
        if indizio in contesto:
            return True, fname
    return True, None                 # ambiguo e senza indizi: nessun logo


def logo_per_squadra(nome, dove=""):
    """Percorso del logo, o None. Prima esatto, poi fuzzy stretto."""
    if not nome:
        return None
    chiave = normalizza_squadra(nome)

    # La cache tiene conto del contesto: la stessa squadra in due campionati
    # diversi puo' legittimamente dare due stemmi diversi.
    in_cache = (chiave, str(dove or "")[:40])
    if in_cache in _CACHE_LOGHI:
        return _CACHE_LOGHI[in_cache]

    mappa = _carica_mappa_loghi()

    ambiguo, scelto = _scioglie_omonimia(chiave, dove)
    if ambiguo:
        percorso = None
        dir_png, _ = _base_loghi()
        if scelto and dir_png:
            cand = os.path.join(dir_png, scelto)
            if os.path.exists(cand):
                percorso = cand
        _CACHE_LOGHI[in_cache] = percorso
        return percorso

    fname = mappa.get(chiave)

    # Trovata per via esatta: nessun dubbio. Altrimenti, se il nome e' in
    # lista nera, ci si ferma qui invece di tentare le approssimazioni.
    if not fname and chiave in _carica_senza_approssimare():
        _CACHE_LOGHI[in_cache] = None
        return None

    # Chiave sulla quale si e' andati a finire per somiglianza, che NON e'
    # quella di partenza: serve piu' sotto per ripassare dalla tabella delle
    # omonimie. Senza, il fuzzy la scavalca - "Fortaleza W" somiglia a
    # 'fortaleza' al 90%, prendeva il Fortaleza brasiliano e la decisione
    # per campionato non veniva nemmeno consultata.
    trovata = None

    if not fname and mappa and not _e_squadra_riserve_logo(chiave):
        # soglia alta: meglio nessun logo che il logo della squadra sbagliata
        candidati = [k for k in mappa.keys() if not _e_squadra_riserve_logo(k)]
        vicini = difflib.get_close_matches(chiave, candidati,
                                           n=1, cutoff=0.88)
        if vicini:
            trovata = vicini[0]
            fname = mappa[trovata]

        # Secondo tentativo, con trattini e punti trattati come spazi da
        # entrambe le parti. La soglia resta 0.88: si allineano le grafie,
        # non si abbassa il livello di prudenza.
        if not fname:
            chiave2 = normalizza_squadra(nome, separa_punteggiatura=True)
            if chiave2 != chiave:
                equiv = {}
                for k in candidati:
                    equiv.setdefault(
                        normalizza_squadra(k, separa_punteggiatura=True), k)
                if chiave2 in equiv:
                    trovata = equiv[chiave2]
                    fname = mappa[trovata]
                else:
                    vicini = difflib.get_close_matches(chiave2, list(equiv),
                                                       n=1, cutoff=0.88)
                    if vicini:
                        trovata = equiv[vicini[0]]
                        fname = mappa[trovata]

        # Terzo tentativo, senza accenti da entrambe le parti. I nomi dei
        # file dei loghi sono quasi sempre in ASCII ('bodo-glimt'), mentre le
        # fonti scrivono 'Bodø/Glimt': senza questo passaggio servirebbe un
        # alias curato a mano per ogni squadra nordica, slava o baltica.
        # La soglia resta 0.88 e il confronto e' simmetrico, quindi non
        # avvicina squadre che gia' non si somigliavano.
        if not fname:
            chiave3 = _senza_accenti(
                normalizza_squadra(nome, separa_punteggiatura=True))
            equiv = {}
            for k in candidati:
                equiv.setdefault(
                    _senza_accenti(normalizza_squadra(
                        k, separa_punteggiatura=True)), k)
            if chiave3 in equiv:
                trovata = equiv[chiave3]
                fname = mappa[trovata]
            else:
                vicini = difflib.get_close_matches(chiave3, list(equiv),
                                                   n=1, cutoff=0.88)
                if vicini:
                    trovata = equiv[vicini[0]]
                    fname = mappa[trovata]

    # Quarto tentativo: togliere i marcatori di variante e cercare il club.
    #
    # Sta FUORI dal blocco qui sopra perche' deve valere anche per le
    # riserve, che quel blocco esclude apposta. E non usa il fuzzy: cerca
    # SOLO in modo esatto. E' questa la differenza che lo rende sicuro.
    # Misurato sui nomi veri di gh-data: recupera 51 squadre (tutte le
    # femminili di WSL, Liga F e Serie A, le seconde squadre spagnole e
    # ceche, le nazionali giovanili) e non ne sbaglia nessuna, perche'
    # "Orlando Pride (w)" diventa 'orlando pride', che non e' una chiave, e
    # quindi resta senza stemma invece di prendersi quello dell'Orlando City.
    # Con il fuzzy al posto della ricerca esatta, invece, se lo prenderebbe.
    if not fname and mappa:
        base = _nome_senza_marcatori(
            normalizza_squadra(nome, separa_punteggiatura=True))
        if base:
            # Se la variante e' a sua volta ambigua (una "Rangers II"),
            # decide il campionato, esattamente come per il nome intero.
            ambiguo, scelto = _scioglie_omonimia(base, dove)
            if ambiguo:
                fname = scelto
            else:
                equiv = {}
                for k in mappa:
                    equiv.setdefault(
                        _senza_accenti(normalizza_squadra(
                            k, separa_punteggiatura=True)), k)
                k = equiv.get(_senza_accenti(base))
                if k:
                    fname = mappa[k]

    # Ultimo controllo: se ci si e' arrivati per somiglianza, la tabella
    # delle omonimie ha comunque l'ultima parola sulla chiave di ARRIVO.
    if trovata and trovata != chiave:
        ambiguo, scelto = _scioglie_omonimia(trovata, dove)
        if ambiguo:
            fname = scelto

    percorso = None
    dir_png, _ = _base_loghi()
    if fname and dir_png:
        cand = os.path.join(dir_png, fname)
        if os.path.exists(cand):
            percorso = cand

    _CACHE_LOGHI[in_cache] = percorso
    return percorso


# ---------------------------------------------------------------- voci

def add_item(label, plot, url, is_folder, casa=None, ospite=None, dove=""):
    li = xbmcgui.ListItem(label=label)
    li.setInfo("video", {"title": label, "plot": plot})

    # Una ListItem ha UNA sola thumb: due squadre non ci stanno.
    # thumb = casa, fanart = ospite (la fanart compare come sfondo alla
    # selezione, ma la resa dipende dallo skin).
    logo_casa = logo_per_squadra(casa, dove) if casa else None
    logo_osp = logo_per_squadra(ospite, dove) if ospite else None

    art = {"icon": logo_casa or ICON, "thumb": logo_casa or ICON}
    if logo_osp:
        art["fanart"] = logo_osp
    li.setArt(art)

    xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=is_folder)


# ---------------------------------------------------------------- menu

def main_menu():
    # Si entra da qui a ogni apertura dell'addon: e' il momento giusto per
    # verificare se la mappa dei nomi e' cambiata.
    global _RICONTROLLA_SUBITO
    _RICONTROLLA_SUBITO = True
    try:
        _carica_mappa_loghi()
    except Exception:
        pass

    add_item("[*] Consensus", "Partite dove Statarea e WebPronostici concordano",
             get_url(action="dates", source="consensus"), True)
    add_item("[S] Statarea", "Pronostici Statarea con percentuali",
             get_url(action="dates", source="statarea"), True)
    add_item("[W] WebPronostici", "1X2, Misti, Under/Over, Gol/NoGol",
             get_url(action="wp_tipi"), True)
    add_item("[A] AsianOdds", "Quote 1xBet, movimenti ed Elo - solo informativo, "
                              "non e' un pronostico",
             get_url(action="ao_filtri"), True)
    add_item("[F] FootballPredictions", "Le Sure Bets del giorno con il "
                                        "pronostico del sito",
             get_url(action="dates", source="fpnet"), True)
    add_item("[X] xGaura", "Tip divisi per mercato, con la quota migliore "
                           "fra i bookmaker e quanta probabilita' implica",
             get_url(action="xg_mercati"), True)
    xbmcplugin.endOfDirectory(HANDLE)


def show_xg_mercati():
    """I mercati della sezione xGaura."""
    for slug, label, _mercati, descr in XG_MERCATI:
        add_item(label, descr,
                 get_url(action="dates", source="xgaura", tipo=slug), True)
    xbmcplugin.endOfDirectory(HANDLE)


def show_ao_filtri():
    """Due modi di entrare nella sezione AsianOdds.

    'Movimenti' per primo di proposito: il feed contiene ~600 partite delle
    prossime 24h, in gran parte di campionati minori, e scorrerle tutte col
    telecomando non serve a niente. Il filtro e' solo lato addon, il file
    scaricato e' lo stesso."""
    for slug, label, descr in AO_FILTRI:
        add_item(label, descr,
                 get_url(action="dates", source="asianodds", tipo=slug), True)
    xbmcplugin.endOfDirectory(HANDLE)


def show_wp_tipi():
    """Sottocartelle WebPronostici per tipo di pronostico."""
    disponibili = github_request("webpronostici_tipi.json", silent_404=True)
    slug_ok = None
    if isinstance(disponibili, dict) and isinstance(disponibili.get("tipi"), list):
        slug_ok = set()
        for t in disponibili["tipi"]:
            if isinstance(t, dict) and t.get("slug"):
                slug_ok.add(str(t["slug"]))

    mostrati = 0
    for slug, label in WP_TIPI:
        if slug_ok is not None and slug not in slug_ok:
            continue
        add_item(label, "WebPronostici - {}".format(label),
                 get_url(action="dates", source="webpronostici", tipo=slug), True)
        mostrati += 1

    if mostrati == 0:
        for slug, label in WP_TIPI:
            add_item(label, "WebPronostici - {}".format(label),
                     get_url(action="dates", source="webpronostici", tipo=slug), True)

    xbmcplugin.endOfDirectory(HANDLE)


def index_name(source, tipo):
    if source == "webpronostici" and tipo:
        return "webpronostici_{}_index.json".format(tipo)
    return "{}_index.json".format(source)


def data_name(source, tipo, date):
    if source == "webpronostici" and tipo:
        return "webpronostici_{}_{}.json".format(tipo, date)
    return "{}_{}.json".format(source, date)


def show_dates(source, tipo=""):
    if source not in SORGENTI:
        notify_error("Sorgente non valida")
        xbmcplugin.endOfDirectory(HANDLE)
        return

    # Per AsianOdds il 404 e' il caso normale finche' il workflow non ha
    # pubblicato il primo indice: meglio dirlo che mandare l'utente a
    # controllare repository e token, che sono a posto.
    # Sezioni con un file proprio: finche' il workflow non ha pubblicato il
    # primo indice il 404 e' il caso NORMALE, non un guasto. Dirlo evita che
    # si vada a controllare repository e token, che sono a posto.
    e_nuova = source in ("asianodds", "fpnet", "xgaura")
    etichetta = {"asianodds": "AsianOdds",
                 "fpnet": "FootballPredictions",
                 "xgaura": "xGaura"}.get(source, source)
    data = github_request(index_name(source, tipo), silent_404=e_nuova)
    if not data:
        if e_nuova:
            notify_error("{}: nessun dato ancora pubblicato su "
                         "gh-data".format(etichetta))
        xbmcplugin.endOfDirectory(HANDLE)
        return

    if isinstance(data, dict):
        dates = data.get("date") or data.get("dates") or []
        updated = data.get("updated", "")
    elif isinstance(data, list):
        dates = data
        updated = ""
    else:
        notify_error("Indice con formato non valido")
        xbmcplugin.endOfDirectory(HANDLE)
        return

    if not dates:
        notify_error("Nessuna data disponibile")

    for d in sorted([str(x) for x in dates], reverse=True):
        add_item(d, "Aggiornato: {}".format(updated),
                 get_url(action="matches", source=source, tipo=tipo, date=d), True)

    xbmcplugin.endOfDirectory(HANDLE)


# ---------------------------------------------------------------- partite

def fmt_pct(v):
    """Restituisce la percentuale senza simbolo, stringa vuota se assente."""
    s = str(v).strip()
    if not s or s.lower() == "nan":
        return ""
    return s.replace("%", "")


def row_statarea(row):
    casa = str(row.get("Casa", ""))
    ospite = str(row.get("Ospite", ""))
    ora = str(row.get("Ora", ""))
    pron = str(row.get("TIP", "")).upper()
    p1 = fmt_pct(row.get("P_1", ""))
    px = fmt_pct(row.get("P_X", ""))
    p2 = fmt_pct(row.get("P_2", ""))
    o15 = fmt_pct(row.get("Over1.5", ""))
    o25 = fmt_pct(row.get("Over2.5", ""))
    o35 = fmt_pct(row.get("Over3.5", ""))
    btts = fmt_pct(row.get("BTTS_SI", ""))
    ht1 = fmt_pct(row.get("HT1", ""))
    htx = fmt_pct(row.get("HTX", ""))
    ht2 = fmt_pct(row.get("HT2", ""))
    comp = str(row.get("Competizione", ""))
    paese = str(row.get("Paese", ""))

    perc = ""
    if p1 and px and p2:
        perc = "  1:{} X:{} 2:{}".format(p1, px, p2)

    label = "{} {} {} vs {}{}".format(
        PRON_ICONS.get(pron, "[?]"), ora, casa, ospite, perc
    )
    plot = (
        "{} - {}\n"
        "Pronostico: {}\n"
        "1X2:  1:{}%  X:{}%  2:{}%\n"
        "HT:   1:{}%  X:{}%  2:{}%\n"
        "Over: 1.5:{}%  2.5:{}%  3.5:{}%\n"
        "BTTS: {}%"
    ).format(paese, comp, pron, p1, px, p2, ht1, htx, ht2, o15, o25, o35, btts)
    return label, plot


def row_webpronostici(row):
    casa = str(row.get("Casa", ""))
    ospite = str(row.get("Ospite", ""))
    ora = str(row.get("Ora", ""))
    pron = str(row.get("Pronostico", "")).upper()
    quota = str(row.get("Quota", ""))
    camp = str(row.get("Campionato", ""))
    tipo = str(row.get("Tipo", ""))

    quota_txt = "  @{}".format(quota) if quota and quota.lower() != "nan" else ""
    ora_txt = "{} ".format(ora) if ora and ora.lower() != "nan" else ""

    label = "{} {}{} vs {}{}".format(
        PRON_ICONS.get(pron, "[" + pron + "]"), ora_txt, casa, ospite, quota_txt
    )
    plot = "Campionato: {}\nTipo: {}\nPronostico: {}\nQuota: {}".format(
        camp, tipo, pron, quota
    )
    return label, plot


def row_consensus(row):
    casa = str(row.get("Casa", ""))
    ospite = str(row.get("Ospite", ""))
    ora = str(row.get("Ora", ""))
    pron = str(row.get("Pron Combinato", "")).upper()
    psa = str(row.get("Pron Statarea", ""))
    pwp = str(row.get("Pron WebPron", ""))
    p1 = fmt_pct(row.get("P_1 %", ""))
    px = fmt_pct(row.get("P_X %", ""))
    p2 = fmt_pct(row.get("P_2 %", ""))
    o15 = fmt_pct(row.get("Over1.5 %", ""))
    o25 = fmt_pct(row.get("Over2.5 %", ""))
    btts = fmt_pct(row.get("BTTS %", ""))
    quota = str(row.get("Quota WP", ""))
    xg_casa = row.get("xG Casa", "")
    xg_ospite = row.get("xG Ospite", "")

    perc = ""
    if p1 and px and p2:
        perc = "  1:{} X:{} 2:{}".format(p1, px, p2)

    # xG solo se ALMENO una delle due squadre ce l'ha (top-5 leghe europee
    # via Understat). Sulle altre leghe questo campo resta assente: non e'
    # un guasto, e' un limite della fonte - vedi consensus.py v4.
    xg_riga = ""
    if xg_casa != "" or xg_ospite != "":
        xg_riga = "\nxG:  {} - {}".format(
            xg_casa if xg_casa != "" else "-",
            xg_ospite if xg_ospite != "" else "-")

    label = "{} {} {} vs {}{}".format(
        PRON_ICONS.get(pron, "[?]"), ora, casa, ospite, perc
    )
    plot = (
        "Pronostico combinato: {}\n"
        "Statarea: {}   WebPronostici: {}\n"
        "1X2:  1:{}%  X:{}%  2:{}%\n"
        "Over: 1.5:{}%  2.5:{}%\n"
        "BTTS: {}%\n"
        "Quota WP: {}"
        "{}"
    ).format(pron, psa, pwp, p1, px, p2, o15, o25, btts, quota, xg_riga)
    return label, plot + righe_asianodds(row)


def _vuoto(v):
    return v is None or v == ""


def righe_asianodds(row):
    """Righe AsianOdds per il riquadro dettagli - solo informative.

    Quote 1xBet (soft book): NON sono un voto e non entrano nel pronostico.
    Il drift e' la variazione % della quota da apertura a ora:
    negativo = quota scesa = il mercato ci crede di piu' su quell'esito.
    Ogni riga compare solo se il dato c'e' (piano free: solo prossime 24h).
    Si usano solo caratteri ASCII per non dipendere dal font dello skin."""
    righe = []

    d1, dx, d2 = row.get("AO Drift 1"), row.get("AO Drift X"), row.get("AO Drift 2")
    if not (_vuoto(d1) and _vuoto(dx) and _vuoto(d2)):
        def fd(v):
            try:
                return "{:+.1f}%".format(float(v))
            except (TypeError, ValueError):
                return "-"
        righe.append("1xBet: 1 {}  X {}  2 {}".format(fd(d1), fd(dx), fd(d2)))

    parti = []
    ah_o, ah = row.get("AO AH Open"), row.get("AO AH")
    if not _vuoto(ah_o) and not _vuoto(ah):
        try:
            parti.append("AH {:+.2f}->{:+.2f}".format(float(ah_o), float(ah)))
        except (TypeError, ValueError):
            pass
    ou_o, ou = row.get("AO OU Open"), row.get("AO OU")
    if not _vuoto(ou_o) and not _vuoto(ou):
        try:
            parti.append("O/U {:.2f}->{:.2f}".format(float(ou_o), float(ou)))
        except (TypeError, ValueError):
            pass
    if parti:
        righe.append("  ".join(parti))

    ec, eo = row.get("AO Elo Casa"), row.get("AO Elo Osp")
    if not _vuoto(ec) and not _vuoto(eo):
        try:
            righe.append("Elo: {} - {}".format(int(float(ec)), int(float(eo))))
        except (TypeError, ValueError):
            pass

    return ("\n" + "\n".join(righe)) if righe else ""


def _num(v):
    """Valore numerico, o None se assente/non numerico."""
    if v is None or v == "":
        return None
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def _e_notevole(row):
    """Vale il filtro "Movimenti"? Decide asianodds_ci.py, qui si legge.

    Il campo "Notevole" tiene conto sia del movimento sia del margine del
    bookmaker: un movimento piccolo su un mercato quotato con cura (margine
    basso) conta piu' di uno grande su una lega minore, dove le quote di
    apertura sono approssimative e il movimento e' spesso solo la loro
    correzione.

    Se il campo manca - JSON prodotti prima della sua introduzione - si
    ripiega sulla sola soglia in punti, cosi' la sezione continua a
    funzionare invece di svuotarsi."""
    if "Notevole" in row:
        return bool(row.get("Notevole"))
    mov = _num(row.get("Mov"))
    return mov is not None and mov >= AO_SOGLIA_MOV


def _e_affidabile(row):
    """La probabilita' e' una stima attendibile? Decide asianodds_ci.py.

    Attendibile non vuol dire conveniente: sono le stime migliori del
    mercato, quindi il prezzo le incorpora gia'. Servono come metro, non
    come pronostico."""
    return bool(row.get("Affidabile"))


def _xg_mercati(tipo):
    """I valori del campo Mercato della voce scelta.

    Tupla vuota = nessun filtro, cioe' la voce "Tutti". None = slug non
    riconosciuto, e anche li' si mostra tutto invece di una lista vuota."""
    for slug, _label, mercati, _descr in XG_MERCATI:
        if slug == tipo:
            return mercati
    return ()


def _prob_implicita(quota):
    """Probabilita' implicita in una quota decimale, o None.

    ATTENZIONE a come va letta. La quota e' dichiarata dal sito come la
    MIGLIORE fra piu' bookmaker, non quella di un libro solo. La quota piu'
    alta e' anche quella con la probabilita' implicita piu' BASSA, quindi
    questo numero e' una stima per DIFETTO della probabilita' vera: il
    margine del bookmaker, che di solito la gonfia del 5-8%, qui e' in gran
    parte gia' tolto dalla concorrenza fra operatori. Serve come metro di
    paragone con quello che dichiara il sito, non come probabilita' esatta.
    """
    q = _num(quota)
    if q is None or q < 1.01:
        return None
    return 1.0 / q


def row_xgaura(row):
    """Riga della sezione xGaura.

    RUOLO: una fonte di tip fra le tante. Non entra nel consensus e non
    vota: sta qui come sezione a se', da guardare.

    LE QUOTE VANNO LETTE PER QUELLO CHE SONO. Il sito le dichiara "best
    available across major bookmakers", cioe' il meglio pescato fra piu'
    operatori: la somma delle tre probabilita' implicite puo' venire sotto
    il 100%, che per un singolo bookmaker sarebbe impossibile. Sono utili
    per sapere quanto paga il tip, NON sono un mercato coerente da cui
    ricavare probabilita'. Per questo l'etichetta dice "migliore".

    Solo caratteri ASCII: le frecce unicode dipendono dal font dello skin.
    """
    casa = str(row.get("Casa", ""))
    ospite = str(row.get("Ospite", ""))
    ora = str(row.get("Ora", ""))
    tip = str(row.get("Tip", "")).strip()
    conf = _num(row.get("Conf"))

    # In etichetta il tip e la QUOTA, non la confidenza: la quota e' il
    # numero che il sito non si e' inventato, ed e' quello che distingue
    # davvero due tip fra loro.
    # La quota del tip: sulla pagina di domani il sito la pubblica in una
    # colonna sua, su quella di oggi no - li' ci sono le tre colonne 1/X/2
    # e la quota del tip e' quella che corrisponde al segno scelto. Senza
    # questo recupero meta' delle righe resterebbe senza prezzo, che e'
    # proprio il numero su cui si vuole ragionare.
    q_tip = _num(row.get("Q tip"))
    if q_tip is None and str(row.get("Mercato", "")) == "1X2":
        q_tip = _num({"1": row.get("Q1"),
                      "X": row.get("QX"),
                      "2": row.get("Q2")}.get(str(row.get("Sel", "")).upper()))
    testa = "  {}".format(tip) if tip else ""
    coda = "  @ {:.2f}".format(q_tip) if q_tip is not None else ""
    label = "{} {} vs {}{}{}".format(ora, casa, ospite, testa, coda)

    paese = str(row.get("Paese", "")).strip()
    lega = str(row.get("Lega", "")).strip()
    dove = " - ".join(x for x in (paese, lega) if x)
    righe = [dove] if dove else []

    mercato = str(row.get("Mercato", "")).strip()
    sel = str(row.get("Sel", "")).strip()
    linea = _num(row.get("Linea"))
    if mercato:
        testo = "Mercato: {}".format(mercato)
        if sel:
            testo += "  {}".format(sel)
        if linea is not None:
            testo += " {:.1f}".format(linea)
        righe.append(testo)

    # Il confronto che conta: quanta probabilita' implica il prezzo, e
    # quanta ne dichiara il sito. Sono due numeri di natura diversa - uno
    # esce dal mercato, l'altro dal sito - e messi vicini si vede subito
    # quando il sito sta dicendo qualcosa che il prezzo non dice.
    implicita = _prob_implicita(q_tip)
    if q_tip is not None:
        testo = "Quota migliore: {:.2f}".format(q_tip)
        if implicita is not None:
            testo += "  ->  implica il {:.0f}%".format(implicita * 100)
        righe.append(testo)
    if conf is not None:
        testo = "Il sito dichiara {:.0f}%".format(conf * 100)
        if implicita is not None:
            scarto = (conf - implicita) * 100
            testo += "  ({:+.0f} punti rispetto al prezzo)".format(scarto)
        righe.append(testo)

    # La terna 1X2 c'e' solo sulla pagina di oggi: domani il sito pubblica
    # la sola quota del tip. Si mostra quello che c'e'.
    q1, qx, q2 = _num(row.get("Q1")), _num(row.get("QX")), _num(row.get("Q2"))
    if q1 is not None and qx is not None and q2 is not None:
        righe.append("Quote migliori 1X2: {:.2f} / {:.2f} / {:.2f}".format(
            q1, qx, q2))

    righe.append("Quota migliore fra piu' bookmaker, non di uno solo: la "
                 "percentuale implicita e' quindi una stima per difetto. La "
                 "confidenza la dichiara il sito e non e' verificabile.")

    return label, "\n".join(righe)


def row_fpnet(row):
    """Riga della sezione FootballPredictions.

    RUOLO: una fonte di pronostici fra le tante, con accanto la quota
    migliore che il sito ha trovato per quel mercato. Non entra nel
    consensus e non vota: sta qui come sezione a se', da guardare, esattamente
    come AsianOdds.

    Quattro mercati sulla stessa riga (1X2, Under/Over 2.5, Gol/NoGol e il
    Sure Bet) perche' il sito li da' tutti insieme nella pagina di
    dettaglio: separarli in quattro sezioni vorrebbe dire quattro liste
    quasi identiche da scorrere col telecomando.

    ATTENZIONE - queste righe non portano il campionato, perche' il sito
    nella lista non lo scrive, e senza campionato la tabella delle omonimie
    non ha indizi. Conseguenza pratica, verificata: i nomi contesi senza un
    predefinito (Leon, Barcelona, Rangers, Tigres) restano SENZA stemma,
    mentre quelli con un predefinito prendono quello - 'Inter' l'Inter,
    'Zamora' lo Zamora CF. E' il comportamento voluto: meglio nessuno
    stemma che quello dell'altro club.

    Solo caratteri ASCII: le frecce unicode dipendono dal font dello skin.
    """
    casa = str(row.get("Casa", ""))
    ospite = str(row.get("Ospite", ""))
    ora = str(row.get("Ora", ""))

    # L'asterisco marca le Sure Bets, cosi' si riconoscono scorrendo la
    # lista senza entrare nel dettaglio.
    sure = "  *" if row.get("SureBet") else ""

    # In etichetta solo il pronostico 1X2, che e' quello che si cerca
    # scorrendo; il resto sta nel riquadro dei dettagli.
    p1x2 = str(row.get("1X2", "")).strip() or str(row.get("Lista", "")).strip()
    testa = "  {}".format(p1x2) if p1x2 else ""
    label = "{} {} vs {}{}{}".format(ora, casa, ospite, testa, sure)

    righe = []

    # Il pronostico che il sito mette gia' nella pagina-lista, senza quota.
    # Vale poco accanto ai quattro mercati veri, ma quando la pagina di
    # dettaglio non si lascia leggere e' l'unica cosa che resta - meglio di
    # una riga che dice solo "nessun mercato".
    lista = str(row.get("Lista", "")).strip()
    if lista:
        righe.append("Dalla lista: {}".format(lista))

    for etichetta, kp, kq, kb in (("1X2", "1X2", "Q 1X2", "Book 1X2"),
                                  ("U/O 2.5", "OU", "Q OU", "Book OU"),
                                  ("Gol/NoGol", "BTTS", "Q BTTS", "Book BTTS"),
                                  ("Sure Bet", "Sure", "Q Sure", "Book Sure")):
        pred = str(row.get(kp, "")).strip()
        if not pred:
            continue
        testo = "{}: {}".format(etichetta, pred)
        quota = _num(row.get(kq))
        if quota is not None:
            testo += "  @ {:.2f}".format(quota)
            book = str(row.get(kb, "")).strip()
            if book:
                testo += " ({})".format(book)
        righe.append(testo)

    if not righe:
        righe.append("Nessun mercato: la pagina di dettaglio non e' stata "
                     "letta.")

    return label, "\n".join(righe)


def row_asianodds(row):
    """Riga della sezione AsianOdds.

    RUOLO: informazione, non pronostico. Le quote sono 1xBet, un soft book
    con margine medio intorno all'8-9%, e le probabilita' mostrate sono il
    de-vig proporzionale di quelle stesse quote: non sono una fonte in piu'
    accanto a Statarea e WebPronostici, sono il mercato riscritto in
    percentuale. Per questo AsianOdds non entra nel consensus e qui non
    compare nessun simbolo di pronostico.

    Il dato con valore proprio e' 'Mov': di quanti PUNTI di probabilita' si
    e' spostato il mercato dall'apertura. In punti e non in percentuale di
    quota perche' la percentuale non e' confrontabile fra partite - un +50%
    su una quota da 12.00 vale meno di un punto, un -10% su un 1.50 ne vale
    cinque.

    Solo caratteri ASCII: le frecce unicode dipendono dal font dello skin.
    """
    casa = str(row.get("Casa", ""))
    ospite = str(row.get("Ospite", ""))
    ora = str(row.get("Ora", ""))
    lega = str(row.get("Lega", ""))

    p1, px, p2 = _num(row.get("P1")), _num(row.get("PX")), _num(row.get("P2"))
    mov = _num(row.get("Mov"))
    margine = _num(row.get("Margine"))

    perc = ""
    if p1 is not None and px is not None and p2 is not None:
        perc = "  1:{:.0f} X:{:.0f} 2:{:.0f}".format(p1, px, p2)

    # Il movimento in etichetta solo quando e' significativo: su centinaia
    # di righe un "mov 0.3" ripetuto e' rumore che allunga la lista. Il
    # criterio e' lo stesso del filtro, altrimenti in "Tutte" si vedrebbero
    # partite marcate che poi in "Movimenti" non compaiono.
    mov_txt = ""
    if mov is not None and _e_notevole(row):
        mov_txt = "  [mov {:.1f}]".format(mov)

    # Un marcatore per le affidabili, cosi' si riconoscono anche scorrendo
    # "Tutte" senza entrare nel dettaglio.
    aff_txt = "  *" if _e_affidabile(row) else ""
    label = "{} {} vs {}{}{}{}".format(ora, casa, ospite, perc, mov_txt, aff_txt)

    righe = [lega] if lega else []

    # Quote: apertura -> corrente, con il drift accanto.
    for esito, ka, kq, kd in (("1", "Q1 Apre", "Q1", "Drift 1"),
                              ("X", "QX Apre", "QX", "Drift X"),
                              ("2", "Q2 Apre", "Q2", "Drift 2")):
        qa, qc, dr = _num(row.get(ka)), _num(row.get(kq)), _num(row.get(kd))
        if qc is None:
            continue
        testo = "{}: {:.2f}".format(esito, qc)
        if qa is not None and qa != qc:
            testo = "{}: {:.2f} -> {:.2f}".format(esito, qa, qc)
        if dr is not None:
            testo += "  ({:+.1f}%)".format(dr)
        righe.append(testo)

    # Due metodi di de-vig. Il proporzionale toglie il margine in parti
    # uguali; Shin ne carica di piu' sugli esiti lunghi, come fanno i
    # bookmaker davvero, ed e' il metodo che il Sistema usa come default.
    #
    # La seconda riga compare SOLO quando i due divergono di almeno un
    # punto: su gran parte delle partite coincidono (sotto 0.6 punti quando
    # non c'e' un outsider lungo) e due righe identiche sarebbero rumore.
    # Dove divergono, invece, la differenza e' il dato: significa che c'e'
    # un favorito netto e un outsider lungo, e che la percentuale
    # proporzionale dell'outsider e' gonfiata.
    s1, sx, s2 = (_num(row.get("P1 Shin")), _num(row.get("PX Shin")),
                  _num(row.get("P2 Shin")))
    if p1 is not None:
        riga = "Prob. de-vig:  1 {:.1f}%  X {:.1f}%  2 {:.1f}%".format(p1, px, p2)
        if margine is not None:
            riga += "   margine {:.1f}%".format(margine)
        righe.append(riga)
        if s1 is not None:
            scarto = max(abs(s1 - p1), abs(sx - px), abs(s2 - p2))
            if scarto >= 1.0:
                righe.append("  con Shin:    1 {:.1f}%  X {:.1f}%  2 {:.1f}%"
                             "   (scarto {:.1f} pt)".format(s1, sx, s2, scarto))
    elif s1 is not None:
        righe.append("Prob. Shin:  1 {:.1f}%  X {:.1f}%  2 {:.1f}%".format(s1, sx, s2))

    if mov is not None:
        righe.append("Movimento dall'apertura: {:.1f} punti".format(mov))

    # Linee AH e O/U: informative anche da sole, e non dipendono dalla
    # mappatura h/a delle quote over/under, che nella fonte non e'
    # confermata - per questo le quote O/U non si mostrano affatto.
    parti = []
    for etichetta, ka, kc, fmt in (("AH", "AH Apre", "AH", "{:+.2f}"),
                                   ("O/U", "OU Apre", "OU", "{:.2f}")):
        a, c = _num(row.get(ka)), _num(row.get(kc))
        if c is None:
            continue
        if a is not None and a != c:
            parti.append("{} {} -> {}".format(etichetta, fmt.format(a), fmt.format(c)))
        else:
            parti.append("{} {}".format(etichetta, fmt.format(c)))
    if parti:
        righe.append("   ".join(parti))

    ec, eo = _num(row.get("Elo Casa")), _num(row.get("Elo Osp"))
    if ec is not None and eo is not None:
        righe.append("Elo: {:.0f} - {:.0f}  (diff {:+.0f})".format(ec, eo, ec - eo))

    righe.append("")
    righe.append("Quote 1xBet, solo informative: non entrano nel pronostico.")
    return label, "\n".join(righe)


def show_matches(source, date, tipo=""):
    if source not in SORGENTI or not date:
        notify_error("Parametri non validi")
        xbmcplugin.endOfDirectory(HANDLE)
        return

    data = github_request(data_name(source, tipo, date))
    if not data:
        xbmcplugin.endOfDirectory(HANDLE)
        return

    if isinstance(data, dict):
        for key in ("matches", "data", "results", "rows"):
            if isinstance(data.get(key), list):
                data = data[key]
                break

    if not isinstance(data, list):
        notify_error("Dati con formato non valido")
        xbmcplugin.endOfDirectory(HANDLE)
        return

    count = 0
    scartate_filtro = 0
    for row in data:
        if not isinstance(row, dict):
            continue
        if source == "statarea":
            label, plot = row_statarea(row)
        elif source == "webpronostici":
            label, plot = row_webpronostici(row)
        elif source == "asianodds":
            # Filtro "Movimenti": si applica qui e non a monte perche' il
            # file su gh-data e' uno solo. Una partita senza 'Mov' (quote di
            # apertura mancanti) resta fuori: non si sa se si e' mossa.
            if tipo == "mov" and not _e_notevole(row):
                scartate_filtro += 1
                continue
            if tipo == "aff" and not _e_affidabile(row):
                scartate_filtro += 1
                continue
            label, plot = row_asianodds(row)
        elif source == "fpnet":
            label, plot = row_fpnet(row)
        elif source == "xgaura":
            # Il filtro per fascia si applica qui e non a monte perche' il
            # file su gh-data e' uno solo, con tutti i tip del giorno.
            mercati = _xg_mercati(tipo)
            if mercati and str(row.get("Mercato", "")) not in mercati:
                scartate_filtro += 1
                continue
            label, plot = row_xgaura(row)
        else:
            label, plot = row_consensus(row)

        add_item(label, plot, get_url(action="noop"), False,
                 casa=row.get("Casa"), ospite=row.get("Ospite"),
                 dove=_campi_riga(row))
        count += 1

    if count == 0:
        if scartate_filtro:
            # Distinzione che conta: i dati ci sono, e' il filtro che e'
            # severo. Senza questo messaggio sembrerebbe un guasto.
            if source == "xgaura":
                notify_error(
                    "Nessun tip su questo mercato fra i {} del {}. "
                    "Prova 'Tutti i mercati'.".format(scartate_filtro, date))
            elif tipo == "aff":
                notify_error(
                    "Nessuna partita a margine basso fra le {} del {}. "
                    "Prova 'Tutte'.".format(scartate_filtro, date))
            else:
                notify_error(
                    "Nessun movimento oltre {:.0f} punti fra le {} partite del "
                    "{}. Prova 'Tutte'.".format(AO_SOGLIA_MOV, scartate_filtro,
                                                date))
        else:
            notify_error("Nessuna partita trovata per {}".format(date))

    xbmcplugin.endOfDirectory(HANDLE)


# ---------------------------------------------------------------- router

params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
action = params.get("action", "")

# Prima di qualunque richiesta: chi arriva dalla 1.3.x ha ancora repo privato
# e token nelle impostazioni, e userebbe quelli.
migra_da_privato()

if not action:
    main_menu()
elif action == "wp_tipi":
    show_wp_tipi()
elif action == "xg_mercati":
    show_xg_mercati()
elif action == "ao_filtri":
    show_ao_filtri()
elif action == "dates":
    show_dates(params.get("source", ""), params.get("tipo", ""))
elif action == "matches":
    show_matches(params.get("source", ""), params.get("date", ""),
                 params.get("tipo", ""))
else:
    xbmcplugin.endOfDirectory(HANDLE)
